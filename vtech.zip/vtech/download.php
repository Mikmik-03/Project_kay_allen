<?php
// Delivers an uploaded file only to a signed-in user who is allowed to see the record it is attached to.
// admin: any file | customer: files on their own records | technician: files on jobs assigned to them.
require_once __DIR__ . '/lib.php';

function deny($code, $msg) { http_response_code($code); header('Content-Type: text/plain; charset=utf-8'); echo $msg; exit; }

$f = (string)($_GET['f'] ?? '');
if (!preg_match('/^[a-f0-9]{20}\.(jpg|jpeg|png|webp|pdf)$/', $f, $m)) deny(400, 'Bad file name.');
$path = __DIR__ . '/uploads/' . $f;
if (!is_file($path)) deny(404, 'File not found.');

// The links open in a new tab, so no X-Portal header is available: use whichever portal session is signed in.
$user = null;
foreach (PORTALS as $p) {
    if (empty($_COOKIE['vtech_' . $p])) continue;
    if (session_status() === PHP_SESSION_ACTIVE) session_write_close();
    session_name('vtech_' . $p);
    session_id($_COOKIE['vtech_' . $p]);
    session_start(['use_strict_mode' => 1, 'use_cookies' => 0]);
    $uid = $_SESSION['uid'] ?? null;
    session_write_close();
    if (!$uid) continue;
    $st = $pdo->prepare('SELECT id, role, customer_id, tech_name FROM users WHERE id = ?');
    $st->execute([$uid]);
    $row = $st->fetch();
    if ($row && $row['role'] === $p) {
        $user = $row;
        // Prefer a role that is allowed; keep looking only if this one is not.
        $ok = false;
        if ($row['role'] === 'admin') {
            $ok = true;
        } else {
            $like = '%::' . $f . '%';
            if ($row['role'] === 'customer') {
                $q = $pdo->prepare('SELECT 1 FROM records WHERE customer_id = ? AND documents_uploaded LIKE ? LIMIT 1');
                $q->execute([$row['customer_id'], $like]);
            } else {
                $q = $pdo->prepare('SELECT 1 FROM records WHERE assigned_technician = ? AND documents_uploaded LIKE ? LIMIT 1');
                $q->execute([$row['tech_name'], $like]);
            }
            $ok = (bool)$q->fetchColumn();
        }
        if ($ok) {
            $types = ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp', 'pdf' => 'application/pdf'];
            header('Content-Type: ' . $types[$m[1]]);
            header('Content-Length: ' . filesize($path));
            header('Content-Disposition: inline; filename="' . $f . '"');
            header('X-Content-Type-Options: nosniff');
            header('Cache-Control: private, max-age=3600');
            readfile($path);
            exit;
        }
    }
}
deny($user ? 403 : 401, $user ? 'You do not have access to this file.' : 'Please sign in.');
