// Shared client layer for the three portals: data access (api.php) and sign-in (auth.php).
// Each portal sets window.PORTAL = "admin" | "technician" | "customer" before loading this file.
(function () {
  const portal = () => window.PORTAL || "";
  const headers = (extra) => Object.assign({ "X-Portal": portal() }, extra || {});

  /* ---------------- authentication ---------------- */
  async function authCall(action, body) {
    try {
      const res = await fetch("auth.php?action=" + action, {
        method: body === undefined ? "GET" : "POST",
        headers: headers({ "Content-Type": "application/json" }),
        body: body === undefined ? undefined : JSON.stringify(body),
        cache: "no-store"
      });
      let data = {};
      try { data = await res.json(); } catch (e) {}
      return Object.assign({}, data, { isOk: res.ok && data.isOk !== false, status: res.status });
    } catch (e) {
      return { isOk: false, status: 0, error: "Could not reach the server. Check your connection and try again." };
    }
  }
  window.auth = {
    me: () => authCall("me"),
    login: (username, password) => authCall("login", { username, password }),
    logout: () => authCall("logout", {}),
    register: (data) => authCall("register", data),
    googleLogin: (credential) => authCall("google_login", { credential }),
    googleRegister: (data) => authCall("google_register", data),
    createCustomer: (data) => authCall("create_customer", data),
    createTechnician: (data) => authCall("create_technician", data),
    users: () => authCall("users"),
    resetPassword: (user_id, password) => authCall("reset_password", { user_id, password }),
    changePassword: (current, password) => authCall("change_password", { current, password })
  };

  /* ---------------- data ---------------- */
  let lastJson = "";
  let timer = null;
  let visHandler = null;   // refresh straight away when the tab becomes visible again

  let unauth = false;
  function unauthorized() {
    unauth = true;
    clearInterval(timer); timer = null;
    if (typeof window.dataSdk.onUnauthorized === "function") window.dataSdk.onUnauthorized();
  }

  async function request(method, record) {
    try {
      const res = await fetch("api.php", {
        method,
        headers: headers({ "Content-Type": "application/json" }),
        body: JSON.stringify(record)
      });
      let body = {};
      try { body = await res.json(); } catch (e) {}
      if (res.status === 401) unauthorized();
      return { isOk: res.ok && body.isOk !== false, id: body.id, error: body.error };
    } catch (e) {
      return { isOk: false, error: String(e) };
    }
  }

  window.dataSdk = {
    onUnauthorized: null,
    init: async (handler) => {
      lastJson = ""; unauth = false;
      let etag = "";   // version of the data we already have; the server answers 304 if nothing changed
      const loadData = async (force) => {
        try {
          const h = headers();
          if (!force && etag) h["If-None-Match"] = etag;
          const res = await fetch("api.php", { cache: "no-store", headers: h });
          if (res.status === 401) { unauthorized(); return false; }
          if (res.status === 304) return true;
          if (!res.ok) throw new Error("HTTP " + res.status);
          etag = res.headers.get("ETag") || "";
          const text = await res.text();
          if (force || text !== lastJson) {      // only re-render when something changed
            lastJson = text;
            handler.onDataChanged(JSON.parse(text));
          }
          return true;
        } catch (error) {
          console.error("Fetch error:", error);
          return false;
        }
      };
      window.dataSdk.refresh = () => loadData(true);
      const ok = await loadData(true);
      clearInterval(timer);
      // Poll every 3s, but not while the tab is in the background (saves server load and battery).
      if (!unauth) timer = setInterval(() => { if (!document.hidden) loadData(false); }, 3000);
      if (visHandler) document.removeEventListener("visibilitychange", visHandler);
      visHandler = () => { if (!document.hidden && !unauth) loadData(false); };
      document.addEventListener("visibilitychange", visHandler);
      return { isOk: ok };
    },
    stop: () => { clearInterval(timer); timer = null; if (visHandler) { document.removeEventListener("visibilitychange", visHandler); visHandler = null; } },
    create: (record) => request("POST", record),
    update: (record) => request("PUT", record),
    delete: (record) => request("DELETE", { __backendId: record.__backendId || record }),
    upload: async (file) => {
      try {
        const fd = new FormData(); fd.append("file", file);
        const res = await fetch("upload.php", { method: "POST", headers: headers(), body: fd });
        const body = await res.json().catch(() => ({}));
        if (res.status === 401) unauthorized();
        return { isOk: res.ok && body.isOk, stored: body.stored, name: body.name, error: body.error };
      } catch (e) { return { isOk: false, error: String(e) }; }
    }
  };
})();
