<?php
require_once __DIR__ . '/lib.php';
$portal = request_portal();
ensure_schema();
start_session($portal);

$action = $_GET['action'] ?? '';
$in = json_decode(file_get_contents('php://input'), true);
if (!is_array($in)) { $in = []; }
$method = $_SERVER['REQUEST_METHOD'];

function str_field($arr, $key, $max = 255) {
    $v = trim((string)($arr[$key] ?? ''));
    return mb_substr($v, 0, $max);
}
function valid_username($u) { return (bool)preg_match('/^[A-Za-z0-9._-]{3,40}$/', $u); }
function password_problem($p) {
    if (strlen($p) < 8) return 'Password must be at least 8 characters.';
    if (strlen($p) > 72) return 'Password must be 72 characters or fewer.';
    return null;
}
function username_taken($name) {
    global $pdo;
    $st = $pdo->prepare('SELECT 1 FROM users WHERE username = ?');
    $st->execute([$name]);
    return (bool)$st->fetchColumn();
}
function log_in($row) {
    session_regenerate_id(true);
    $_SESSION['uid'] = (int)$row['id'];
}

// Verifies a Google ID token with Google and checks it was issued for OUR client ID.
// Returns [claims, null] on success or [null, "error message"].
function verify_google_token($idToken) {
    if (strpos(GOOGLE_CLIENT_ID, 'PASTE') !== false) return [null, 'Google sign-in is not configured yet.'];
    if ($idToken === '' || strlen($idToken) > 4096) return [null, 'Missing Google credential.'];
    $url = 'https://oauth2.googleapis.com/tokeninfo?id_token=' . urlencode($idToken);
    $body = false; $code = 0;
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8, CURLOPT_SSL_VERIFYPEER => true]);
        $body = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($body === false) error_log('Google tokeninfo curl error: ' . curl_error($ch));
        curl_close($ch);
    } else {
        $body = @file_get_contents($url, false, stream_context_create(['http' => ['timeout' => 8, 'ignore_errors' => true]]));
        $code = $body === false ? 0 : 200;
    }
    if ($body === false) return [null, 'Could not reach Google to verify your sign-in. Please try again.'];
    $c = json_decode($body, true);
    if ($code !== 200 || !is_array($c)) return [null, 'Google sign-in could not be verified.'];
    if (($c['aud'] ?? '') !== GOOGLE_CLIENT_ID) return [null, 'Google sign-in could not be verified.'];
    if (!in_array($c['iss'] ?? '', ['accounts.google.com', 'https://accounts.google.com'], true)) return [null, 'Google sign-in could not be verified.'];
    if ((int)($c['exp'] ?? 0) < time()) return [null, 'Google sign-in expired. Please try again.'];
    if (($c['email_verified'] ?? '') !== 'true' && ($c['email_verified'] ?? false) !== true) return [null, 'Your Google email address is not verified.'];
    if (empty($c['sub'])) return [null, 'Google sign-in could not be verified.'];
    return [$c, null];
}

try {
    if ($action === 'me') {
        if (empty($_SESSION['uid'])) json_out(['isOk' => true, 'user' => null, 'google_client_id' => GOOGLE_CLIENT_ID]);
        $st = $pdo->prepare('SELECT id, username, role, display_name, customer_id, tech_name, must_change FROM users WHERE id = ?');
        $st->execute([$_SESSION['uid']]);
        $row = $st->fetch();
        if (!$row || $row['role'] !== $portal) { $_SESSION = []; json_out(['isOk' => true, 'user' => null, 'google_client_id' => GOOGLE_CLIENT_ID]); }
        json_out(['isOk' => true, 'user' => user_payload($row)]);
    }

    if ($method !== 'POST' && $action !== 'users') json_out(['isOk' => false, 'error' => 'POST required'], 405);

    if ($action === 'login') {
        $username = str_field($in, 'username', 60);
        $password = (string)($in['password'] ?? '');
        if ($username === '' || $password === '') json_out(['isOk' => false, 'error' => 'Enter your username and password.'], 400);
        $ip = substr($_SERVER['REMOTE_ADDR'] ?? '', 0, 45);
        $st = $pdo->prepare('SELECT COUNT(*) FROM login_attempts WHERE attempted_at > (NOW() - INTERVAL 10 MINUTE) AND username = ?');
        $st->execute([$username]);
        $byUser = (int)$st->fetchColumn();
        $st = $pdo->prepare('SELECT COUNT(*) FROM login_attempts WHERE attempted_at > (NOW() - INTERVAL 10 MINUTE) AND ip = ?');
        $st->execute([$ip]);
        $byIp = (int)$st->fetchColumn();
        if ($byUser >= 8 || $byIp >= 40) json_out(['isOk' => false, 'error' => 'Too many failed attempts. Try again in 10 minutes.'], 429);

        $st = $pdo->prepare('SELECT * FROM users WHERE username = ?');
        $st->execute([$username]);
        $row = $st->fetch();
        $good = $row ? password_verify($password, $row['password_hash']) : (password_hash($password, PASSWORD_DEFAULT) && false);
        if (!$good) {
            $pdo->prepare('INSERT INTO login_attempts (username, ip) VALUES (?, ?)')->execute([$username, $ip]);
            $pdo->exec('DELETE FROM login_attempts WHERE attempted_at < (NOW() - INTERVAL 1 DAY)');
            json_out(['isOk' => false, 'error' => 'Incorrect username or password.'], 401);
        }
        if ($row['role'] !== $portal) json_out(['isOk' => false, 'error' => 'This account does not have access to this portal.'], 403);
        $pdo->prepare('DELETE FROM login_attempts WHERE username = ?')->execute([$username]);
        if (password_needs_rehash($row['password_hash'], PASSWORD_DEFAULT)) {
            $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([password_hash($password, PASSWORD_DEFAULT), $row['id']]);
        }
        log_in($row);
        json_out(['isOk' => true, 'user' => user_payload($row)]);
    }

    // ---- Google Sign-In (customer portal only) ----
    if ($action === 'google_login') {
        if ($portal !== 'customer') json_out(['isOk' => false, 'error' => 'Not allowed.'], 403);
        list($g, $err) = verify_google_token((string)($in['credential'] ?? ''));
        if ($err) json_out(['isOk' => false, 'error' => $err], 401);
        $st = $pdo->prepare('SELECT * FROM users WHERE google_sub = ?');
        $st->execute([$g['sub']]);
        $row = $st->fetch();
        if ($row) {
            if ($row['role'] !== 'customer') json_out(['isOk' => false, 'error' => 'This account does not have access to this portal.'], 403);
            log_in($row);
            json_out(['isOk' => true, 'user' => user_payload($row)]);
        }
        // First time with Google: remember who they are, then ask for company/site details.
        $_SESSION['g_pending'] = ['sub' => (string)$g['sub'], 'email' => (string)($g['email'] ?? ''), 'name' => (string)($g['name'] ?? ''), 'at' => time()];
        json_out(['isOk' => true, 'needs_profile' => true, 'email' => $g['email'] ?? '', 'name' => $g['name'] ?? '']);
    }

    if ($action === 'google_register') {
        if ($portal !== 'customer') json_out(['isOk' => false, 'error' => 'Not allowed.'], 403);
        $gp = $_SESSION['g_pending'] ?? null;
        if (!$gp || time() - (int)$gp['at'] > 1800) json_out(['isOk' => false, 'error' => 'Your Google sign-in expired. Please click the Google button again.'], 401);
        $contact  = str_field($in, 'contact_name', 120);
        if ($contact === '') $contact = mb_substr($gp['name'], 0, 120);
        $company  = str_field($in, 'company', 255);
        $phone    = str_field($in, 'phone', 60);
        $siteName = str_field($in, 'site_name', 255);
        $siteAddr = str_field($in, 'site_address', 500);
        $email    = mb_substr($gp['email'], 0, 255);
        if ($company === '') $company = $contact; // company/site are optional; sites can be added later in the portal
        if ($contact === '' || $phone === '') json_out(['isOk' => false, 'error' => 'Please fill in all required fields.'], 400);

        $username = '';
        for ($i = 0; $i < 10; $i++) { $username = 'g_' . strtolower(random_code(10)); if (!username_taken($username)) break; }
        $customerId = '';
        for ($i = 0; $i < 10; $i++) {
            $customerId = 'C-' . random_code(6);
            $st = $pdo->prepare("SELECT 1 FROM records WHERE record_type = 'customer' AND customer_id = ?");
            $st->execute([$customerId]);
            if (!$st->fetchColumn()) break;
        }
        $pdo->beginTransaction();
        try {
            // Random unusable password: this account signs in with Google only.
            $pdo->prepare("INSERT INTO users (username, password_hash, role, display_name, customer_id, google_sub) VALUES (?, ?, 'customer', ?, ?, ?)")
                ->execute([$username, password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT), $contact, $customerId, $gp['sub']]);
            $newId = (int)$pdo->lastInsertId();
            $base = ['customer_id' => $customerId, 'customer_name' => $company, 'contact_name' => $contact, 'phone' => $phone, 'email' => $email, 'role' => 'customer'];
            insert_record($base + ['record_type' => 'customer', 'title' => $company, 'status' => 'Active', 'site_address' => $siteAddr]);
            if ($siteName !== '' && $siteAddr !== '') insert_record($base + ['record_type' => 'site', 'title' => $siteName, 'status' => 'Active', 'site_address' => $siteAddr]);
            $pdo->commit();
        } catch (Exception $e) {
            $pdo->rollBack();
            if ($e instanceof PDOException && $e->getCode() === '23000') json_out(['isOk' => false, 'error' => 'This Google account is already registered. Click the Google button to sign in.'], 409);
            throw $e;
        }
        unset($_SESSION['g_pending']);
        log_in(['id' => $newId]);
        $st = $pdo->prepare('SELECT id, username, role, display_name, customer_id, tech_name, must_change FROM users WHERE id = ?');
        $st->execute([$newId]);
        json_out(['isOk' => true, 'user' => user_payload($st->fetch())]);
    }

    if ($action === 'logout') {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 3600, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
        }
        session_destroy();
        json_out(['isOk' => true]);
    }

    // Customer self-registration (customer portal) or admin-created customer.
    if ($action === 'register' || $action === 'create_customer') {
        if ($action === 'register' && $portal !== 'customer') json_out(['isOk' => false, 'error' => 'Not allowed.'], 403);
        if ($action === 'create_customer') require_user($portal, ['admin']);
        $username = str_field($in, 'username', 40);
        $password = (string)($in['password'] ?? '');
        $contact  = str_field($in, 'contact_name', 120);
        $company  = str_field($in, 'company', 255);
        $phone    = str_field($in, 'phone', 60);
        $email    = str_field($in, 'email', 255);
        $siteName = str_field($in, 'site_name', 255);
        $siteAddr = str_field($in, 'site_address', 500);
        if (!valid_username($username)) json_out(['isOk' => false, 'error' => 'Username must be 3-40 characters: letters, numbers, dot, dash or underscore.'], 400);
        if ($p = password_problem($password)) json_out(['isOk' => false, 'error' => $p], 400);
        if ($company === '') $company = $contact; // company/site are optional; sites can be added later in the portal
        if ($contact === '' || $phone === '') json_out(['isOk' => false, 'error' => 'Please fill in all required fields.'], 400);
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) json_out(['isOk' => false, 'error' => 'That email address does not look right.'], 400);
        if (username_taken($username)) json_out(['isOk' => false, 'error' => 'That username is already taken.'], 409);

        $customerId = '';
        for ($i = 0; $i < 10; $i++) {
            $customerId = 'C-' . random_code(6);
            $st = $pdo->prepare("SELECT 1 FROM records WHERE record_type = 'customer' AND customer_id = ?");
            $st->execute([$customerId]);
            if (!$st->fetchColumn()) break;
        }
        $pdo->beginTransaction();
        try {
            $pdo->prepare("INSERT INTO users (username, password_hash, role, display_name, customer_id) VALUES (?, ?, 'customer', ?, ?)")
                ->execute([$username, password_hash($password, PASSWORD_DEFAULT), $contact, $customerId]);
            $newId = (int)$pdo->lastInsertId();
            $base = ['customer_id' => $customerId, 'customer_name' => $company, 'contact_name' => $contact, 'phone' => $phone, 'email' => $email, 'role' => 'customer'];
            insert_record($base + ['record_type' => 'customer', 'title' => $company, 'status' => 'Active', 'site_address' => $siteAddr]);
            if ($siteName !== '' && $siteAddr !== '') insert_record($base + ['record_type' => 'site', 'title' => $siteName, 'status' => 'Active', 'site_address' => $siteAddr]);
            $pdo->commit();
        } catch (Exception $e) {
            $pdo->rollBack();
            if ($e instanceof PDOException && $e->getCode() === '23000') json_out(['isOk' => false, 'error' => 'That username is already taken.'], 409);
            throw $e;
        }
        if ($action === 'register') {
            log_in(['id' => $newId]);
            $st = $pdo->prepare('SELECT id, username, role, display_name, customer_id, tech_name, must_change FROM users WHERE id = ?');
            $st->execute([$newId]);
            json_out(['isOk' => true, 'user' => user_payload($st->fetch())]);
        }
        json_out(['isOk' => true, 'customer_id' => $customerId]);
    }

    if ($action === 'create_technician') {
        require_user($portal, ['admin']);
        $username = str_field($in, 'username', 40);
        $password = (string)($in['password'] ?? '');
        $name     = str_field($in, 'name', 120);
        $phone    = str_field($in, 'phone', 60);
        $email    = str_field($in, 'email', 255);
        if (!valid_username($username)) json_out(['isOk' => false, 'error' => 'Username must be 3-40 characters: letters, numbers, dot, dash or underscore.'], 400);
        if ($p = password_problem($password)) json_out(['isOk' => false, 'error' => $p], 400);
        if ($name === '' || $phone === '') json_out(['isOk' => false, 'error' => 'Name and phone are required.'], 400);
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) json_out(['isOk' => false, 'error' => 'That email address does not look right.'], 400);
        if (username_taken($username)) json_out(['isOk' => false, 'error' => 'That username is already taken.'], 409);
        $st = $pdo->prepare('SELECT 1 FROM users WHERE tech_name = ?');
        $st->execute([$name]);
        if ($st->fetchColumn()) json_out(['isOk' => false, 'error' => 'A technician with that name already exists.'], 409);
        $pdo->beginTransaction();
        try {
            $pdo->prepare("INSERT INTO users (username, password_hash, role, display_name, tech_name) VALUES (?, ?, 'technician', ?, ?)")
                ->execute([$username, password_hash($password, PASSWORD_DEFAULT), $name, $name]);
            insert_record(['record_type' => 'technician', 'title' => $name, 'contact_name' => $name, 'phone' => $phone, 'email' => $email, 'status' => 'Available', 'role' => 'technician']);
            $pdo->commit();
        } catch (Exception $e) {
            $pdo->rollBack();
            if ($e instanceof PDOException && $e->getCode() === '23000') json_out(['isOk' => false, 'error' => 'That username or technician name is already in use.'], 409);
            throw $e;
        }
        json_out(['isOk' => true]);
    }

    if ($action === 'users') {
        require_user($portal, ['admin']);
        $rows = $pdo->query('SELECT id, username, role, display_name, customer_id, tech_name, must_change FROM users ORDER BY id')->fetchAll();
        foreach ($rows as &$r) { $r['id'] = (int)$r['id']; $r['must_change'] = !empty($r['must_change']); }
        json_out(['isOk' => true, 'users' => $rows]);
    }

    if ($action === 'reset_password') {
        require_user($portal, ['admin']);
        $target = (int)($in['user_id'] ?? 0);
        $password = (string)($in['password'] ?? '');
        if ($p = password_problem($password)) json_out(['isOk' => false, 'error' => $p], 400);
        $st = $pdo->prepare('SELECT role FROM users WHERE id = ?');
        $st->execute([$target]);
        $role = $st->fetchColumn();
        if (!$role) json_out(['isOk' => false, 'error' => 'User not found.'], 404);
        if ($role === 'admin') json_out(['isOk' => false, 'error' => 'Change the admin password from Settings.'], 403);
        $pdo->prepare('UPDATE users SET password_hash = ?, must_change = 0 WHERE id = ?')->execute([password_hash($password, PASSWORD_DEFAULT), $target]);
        json_out(['isOk' => true]);
    }

    if ($action === 'change_password') {
        $me = require_user($portal);
        $current = (string)($in['current'] ?? '');
        $new = (string)($in['password'] ?? '');
        $st = $pdo->prepare('SELECT password_hash FROM users WHERE id = ?');
        $st->execute([$me['id']]);
        if (!password_verify($current, (string)$st->fetchColumn())) json_out(['isOk' => false, 'error' => 'Your current password is incorrect.'], 403);
        if ($p = password_problem($new)) json_out(['isOk' => false, 'error' => $p], 400);
        $pdo->prepare('UPDATE users SET password_hash = ?, must_change = 0 WHERE id = ?')->execute([password_hash($new, PASSWORD_DEFAULT), $me['id']]);
        json_out(['isOk' => true]);
    }

    json_out(['isOk' => false, 'error' => 'Unknown action'], 400);
} catch (Exception $e) {
    log_error($e, 'auth.php');
    json_out(['isOk' => false, 'error' => 'Server error. Check that MySQL is running and schema.sql has been run (details are in the Apache error log).'], 500);
}
?>
