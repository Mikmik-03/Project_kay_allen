// Registers the service worker and offers an "Install app" button (shared by all pages).
(function () {
  "use strict";
  const standalone = () => window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true;
  const store = {
    get: (k) => { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set: (k, v) => { try { localStorage.setItem(k, v); } catch (e) {} }
  };

  // --- Manifest -------------------------------------------------------------------------------
  // InfinityFree's anti-bot check answers requests for static .webmanifest files with an HTML
  // challenge page (browsers fetch manifests without the cookie), so the app would never be
  // installable. Instead each page builds its own manifest here and hands it to the browser as a blob.
  const APPS = {
    "index.php":                   { name: "VTech I.T. Solution",          short: "VTech",       desc: "VTech I.T. Solution CCTV service hub.",                  bg: "#071526", theme: "#071526" },
    "customer-portal.php":         { name: "VTech Customer Portal",        short: "VTech",       desc: "Book CCTV service, track jobs, message us and pay invoices.", bg: "#f4f7fa", theme: "#10253f" },
    "technician-pportal.php":      { name: "VTech Technician Portal",      short: "VTech Tech",  desc: "Your assigned jobs, schedule and messages.",             bg: "#071b35", theme: "#071b35" },
    "admin-dispatcher-portal.php": { name: "VTech Admin & Dispatch",       short: "VTech Admin", desc: "Dispatch jobs, manage customers, technicians and billing.", bg: "#071526", theme: "#071526" }
  };
  try {
    const base = new URL(".", location.href).href;                         // folder this page lives in, with trailing slash
    const file = decodeURIComponent(location.pathname.split("/").pop() || "") || "index.php";
    const app = APPS[file] || APPS["index.php"];
    const startFile = APPS[file] ? file : "index.php";
    const icon = (src, size, purpose) => ({ src: base + src, sizes: size + "x" + size, type: "image/png", purpose: purpose });
    const manifest = {
      id: base + startFile, name: app.name, short_name: app.short, description: app.desc,
      start_url: base + startFile, scope: base, display: "standalone", orientation: "any",
      background_color: app.bg, theme_color: app.theme, lang: "en",
      icons: [icon("icons/icon-192.png", 192, "any"), icon("icons/icon-512.png", 512, "any"),
              icon("icons/icon-maskable-192.png", 192, "maskable"), icon("icons/icon-maskable-512.png", 512, "maskable")]
    };
    const link = document.createElement("link");
    link.rel = "manifest";
    link.href = URL.createObjectURL(new Blob([JSON.stringify(manifest)], { type: "application/manifest+json" }));
    document.head.appendChild(link);
  } catch (e) { console.warn("Could not build the app manifest:", e); }

  if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("sw.js").catch((e) => console.warn("Service worker not registered:", e));
    });
  }
  if (standalone()) return;   // already running as an installed app

  const css = document.createElement("style");
  css.textContent =
    ".pwa-pill{position:fixed;left:12px;bottom:calc(12px + env(safe-area-inset-bottom,0px));z-index:2147483000;display:flex;align-items:center;gap:6px;" +
    "background:#10253f;color:#fff;border:1px solid #284766;border-radius:999px;padding:6px 6px 6px 14px;font:600 14px system-ui,-apple-system,'Segoe UI',sans-serif;box-shadow:0 6px 20px rgba(0,0,0,.3);max-width:calc(100vw - 24px)}" +
    ".pwa-pill button{font:inherit;cursor:pointer;border:0;color:inherit;background:transparent}" +
    ".pwa-pill .pwa-go{background:#3294e8;border-radius:999px;padding:8px 14px}" +
    ".pwa-pill .pwa-x{width:30px;height:30px;border-radius:50%;font-size:18px;line-height:1;opacity:.8}";
  document.head.appendChild(css);

  function pill(text, actionLabel, onAction, dismissKey) {
    const el = document.createElement("div");
    el.className = "pwa-pill"; el.setAttribute("role", "region"); el.setAttribute("aria-label", "Install app");
    const span = document.createElement("span"); span.textContent = text; el.appendChild(span);
    if (actionLabel) {
      const go = document.createElement("button"); go.type = "button"; go.className = "pwa-go"; go.textContent = actionLabel;
      go.addEventListener("click", () => onAction(el)); el.appendChild(go);
    }
    const x = document.createElement("button"); x.type = "button"; x.className = "pwa-x"; x.setAttribute("aria-label", "Dismiss"); x.textContent = "×";
    x.addEventListener("click", () => { store.set(dismissKey, String(Date.now())); el.remove(); }); el.appendChild(x);
    if (document.body) document.body.appendChild(el);
    else document.addEventListener("DOMContentLoaded", () => document.body.appendChild(el));
    return el;
  }
  // Re-offer a week after being dismissed.
  const dismissed = (k) => { const t = Number(store.get(k) || 0); return t && Date.now() - t < 7 * 24 * 3600 * 1000; };

  // Android / desktop Chrome and Edge
  let deferred = null;
  window.addEventListener("beforeinstallprompt", (e) => {
    e.preventDefault();
    if (dismissed("vtech-pwa-dismissed")) return;
    deferred = e;
    pill("Install the VTech app", "Install", async (el) => {
      el.remove();
      if (!deferred) return;
      deferred.prompt();
      try { await deferred.userChoice; } catch (err) {}
      deferred = null;
    }, "vtech-pwa-dismissed");
  });
  window.addEventListener("appinstalled", () => { document.querySelectorAll(".pwa-pill").forEach((n) => n.remove()); });

  // iPhone / iPad Safari has no install prompt: show how to add it manually.
  const ua = navigator.userAgent || "";
  const ios = /iphone|ipad|ipod/i.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
  const safari = /safari/i.test(ua) && !/crios|fxios|edgios|chrome/i.test(ua);
  if (ios && safari && !dismissed("vtech-pwa-ios-dismissed")) {
    window.addEventListener("load", () => setTimeout(() => {
      pill("To install: tap Share, then “Add to Home Screen”", null, null, "vtech-pwa-ios-dismissed");
    }, 1500));
  }
})();
