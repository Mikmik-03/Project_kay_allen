// Registers the service worker and offers an "Install app" button (shared by all pages).
(function () {
  "use strict";
  const standalone = () => window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true;
  const store = {
    get: (k) => { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set: (k, v) => { try { localStorage.setItem(k, v); } catch (e) {} }
  };

  if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("sw.js").catch((e) => console.warn("Service worker not registered:", e));
    });
  }
  if (standalone()) return;   // already running as an installed app

  const css = document.createElement("style");
  css.textContent =
    ".pwa-pill{position:fixed;left:12px;bottom:calc(12px + env(safe-area-inset-bottom,0px));z-index:2147483000;display:flex;align-items:center;gap:6px;" +
    "background:#10253f;color:#fff;border:1px solid #284766;border-radius:999px;padding:6px 6px 6px 14px;font:600 14px system-ui,-apple-system,'Segoe UI',sans-serif;box-shadow:0 6px 20px rgba(0,0,0,.3);max-width:calc(100vw - 24px)}" +
    ".pwa-pill button{font:inherit;cursor:pointer;border:0;color:inherit;background:transparent}" +
    ".pwa-pill .pwa-go{background:#3294e8;border-radius:999px;padding:8px 14px}" +
    ".pwa-pill .pwa-x{width:30px;height:30px;border-radius:50%;font-size:18px;line-height:1;opacity:.8}";
  document.head.appendChild(css);

  function pill(text, actionLabel, onAction, dismissKey) {
    const el = document.createElement("div");
    el.className = "pwa-pill"; el.setAttribute("role", "region"); el.setAttribute("aria-label", "Install app");
    const span = document.createElement("span"); span.textContent = text; el.appendChild(span);
    if (actionLabel) {
      const go = document.createElement("button"); go.type = "button"; go.className = "pwa-go"; go.textContent = actionLabel;
      go.addEventListener("click", () => onAction(el)); el.appendChild(go);
    }
    const x = document.createElement("button"); x.type = "button"; x.className = "pwa-x"; x.setAttribute("aria-label", "Dismiss"); x.textContent = "×";
    x.addEventListener("click", () => { store.set(dismissKey, String(Date.now())); el.remove(); }); el.appendChild(x);
    document.body.appendChild(el);
    return el;
  }
  // Re-offer a week after being dismissed.
  const dismissed = (k) => { const t = Number(store.get(k) || 0); return t && Date.now() - t < 7 * 24 * 3600 * 1000; };

  // Android / desktop Chrome and Edge
  let deferred = null;
  window.addEventListener("beforeinstallprompt", (e) => {
    e.preventDefault();
    if (dismissed("vtech-pwa-dismissed")) return;
    deferred = e;
    pill("Install the VTech app", "Install", async (el) => {
      el.remove();
      if (!deferred) return;
      deferred.prompt();
      try { await deferred.userChoice; } catch (err) {}
      deferred = null;
    }, "vtech-pwa-dismissed");
  });
  window.addEventListener("appinstalled", () => { document.querySelectorAll(".pwa-pill").forEach((n) => n.remove()); });

  // iPhone / iPad Safari has no install prompt: show how to add it manually.
  const ua = navigator.userAgent || "";
  const ios = /iphone|ipad|ipod/i.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
  const safari = /safari/i.test(ua) && !/crios|fxios|edgios|chrome/i.test(ua);
  if (ios && safari && !dismissed("vtech-pwa-ios-dismissed")) {
    window.addEventListener("load", () => setTimeout(() => {
      pill("To install: tap Share, then “Add to Home Screen”", null, null, "vtech-pwa-ios-dismissed");
    }, 1500));
  }
})();
