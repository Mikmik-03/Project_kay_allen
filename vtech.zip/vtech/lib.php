<?php
// Shared helpers: JSON output, per-portal sessions, schema bootstrap, record helpers.
date_default_timezone_set('UTC');
require_once __DIR__ . '/db.php';

const PORTALS = ['admin', 'technician', 'customer'];
const JOB_TYPES = ['appointment', 'maintenance_request', 'work_order'];
const SCHEMA_VERSION = '4';
const DISPLAY_TZ = 'Asia/Manila'; // dates shown to people (e.g. sign-off date). Storage stays in UTC. // bump to make every portal re-check the database structure once

// Google Sign-In (customer portal). Paste your OAuth Web client ID here.
const GOOGLE_CLIENT_ID = '539292539799-s2u9k5g2isvnj1fcu9svpfqh486iafs9.apps.googleusercontent.com';

// Writes the real error to the PHP/Apache error log (XAMPP: xampp/apache/logs/error.log).
function log_error($e, $where = '') {
    error_log('VTech' . ($where !== '' ? ' ' . $where : '') . ': ' . get_class($e) . ': ' . $e->getMessage() . ' @ ' . basename($e->getFile()) . ':' . $e->getLine());
}

// Today's date (or any format) in the business's local time zone, not UTC.
function local_date($fmt = 'd/m/Y') {
    return (new DateTime('now', new DateTimeZone(DISPLAY_TZ)))->format($fmt);
}

function json_out($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($data);
    exit;
}

function request_portal() {
    $p = $_SERVER['HTTP_X_PORTAL'] ?? '';
    if (!in_array($p, PORTALS, true)) {
        json_out(['isOk' => false, 'error' => 'Unknown portal'], 400);
    }
    return $p;
}

// Each portal has its own session cookie, so one browser can stay signed in to
// the admin, technician and customer portals at the same time (handy for testing).
function start_session($portal) {
    if (session_status() === PHP_SESSION_ACTIVE) return;
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    $path = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/') . '/';
    session_name('vtech_' . $portal);
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => $path,
        'secure'   => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

function ensure_schema() {
    global $pdo, $db;
    static $done = false;
    if ($done) return;
    // The structure only needs checking once, not on every request. A small marker file records that.
    // (If you ever recreate the database, delete the file ".schema-ready" so this runs again.)
    $marker = __DIR__ . '/.schema-ready';
    $stamp  = SCHEMA_VERSION . '|' . $db;
    if (is_file($marker) && trim((string)@file_get_contents($marker)) === $stamp) { $done = true; return; }
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(60) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        role VARCHAR(20) NOT NULL,
        display_name VARCHAR(255) NOT NULL DEFAULT '',
        customer_id VARCHAR(64) NULL,
        tech_name VARCHAR(120) NULL,
        must_change TINYINT(1) NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS login_attempts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(60) NOT NULL,
        ip VARCHAR(45) NOT NULL,
        attempted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX (username), INDEX (attempted_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    // Column that links a user to their Google account (added once, automatically).
    if (!$pdo->query("SHOW COLUMNS FROM users LIKE 'google_sub'")->fetch()) {
        $pdo->exec('ALTER TABLE users ADD COLUMN google_sub VARCHAR(40) NULL, ADD UNIQUE INDEX uq_google_sub (google_sub)');
    }
    // Payment columns on records (added once, automatically, if schema.sql wasn't re-run).
    $have = [];
    foreach ($pdo->query('SHOW COLUMNS FROM records') as $c) { $have[$c['Field']] = true; }
    foreach (['pay_method' => 'VARCHAR(40)', 'pay_account_no' => 'VARCHAR(120)', 'pay_reference' => 'VARCHAR(120)', 'pay_invoice_id' => 'VARCHAR(64)', 'site_lat' => 'DECIMAL(10,7)', 'site_lng' => 'DECIMAL(10,7)', 'rev' => 'INT'] as $col => $type) {
        if (!isset($have[$col])) $pdo->exec("ALTER TABLE records ADD COLUMN `$col` $type NULL");
    }
    // Indexes so the portals' frequent reads stay fast as records grow (added once, automatically).
    $haveIdx = [];
    foreach ($pdo->query('SHOW INDEX FROM records') as $ix) { $haveIdx[$ix['Key_name']] = true; }
    foreach (['idx_type' => 'record_type', 'idx_customer' => 'customer_id', 'idx_tech' => 'assigned_technician', 'idx_thread' => 'thread_id', 'idx_job' => 'job_id', 'idx_updated' => 'updated_at', 'idx_invoice' => 'pay_invoice_id', 'idx_status' => 'status'] as $name => $col) {
        if (isset($haveIdx[$name]) || !isset($have[$col])) continue;
        try { $pdo->exec("ALTER TABLE records ADD INDEX `$name` (`$col`)"); } catch (PDOException $e) { error_log('VTech index ' . $name . ': ' . $e->getMessage()); }
    }
    if (!isset($haveIdx['idx_type_created'])) {
        try { $pdo->exec('ALTER TABLE records ADD INDEX `idx_type_created` (`record_type`, `created_at`)'); } catch (PDOException $e) { error_log('VTech index idx_type_created: ' . $e->getMessage()); }
    }
    $admins = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn();
    if ($admins === 0) {
        // Default administrator account with a RANDOM first password (no well-known default).
        // It is written once to first-admin-password.txt in this folder (blocked from the web by .htaccess).
        // Sign in as "admin" with it, change it when prompted, then delete the file.
        $first = random_code(14);
        $st = $pdo->prepare("INSERT INTO users (username, password_hash, role, display_name, must_change) VALUES (?, ?, 'admin', 'Administrator', 1)");
        $st->execute(['admin', password_hash($first, PASSWORD_DEFAULT)]);
        @file_put_contents(__DIR__ . '/first-admin-password.txt',
            "VTech first admin sign-in\r\nUsername: admin\r\nPassword: $first\r\n\r\nChange the password after signing in, then delete this file.\r\n");
    }
    @file_put_contents($marker, $stamp);
    $done = true;
}

// Validates the session against the users table on every request.
function require_user($portal, $roles = null) {
    global $pdo;
    $sess = $_SESSION['uid'] ?? null;
    if (!$sess) json_out(['isOk' => false, 'error' => 'Please sign in.'], 401);
    $st = $pdo->prepare('SELECT id, username, role, display_name, customer_id, tech_name, must_change FROM users WHERE id = ?');
    $st->execute([$sess]);
    $row = $st->fetch();
    if (!$row || $row['role'] !== $portal) {
        $_SESSION = [];
        json_out(['isOk' => false, 'error' => 'Please sign in.'], 401);
    }
    if ($roles !== null && !in_array($row['role'], $roles, true)) {
        json_out(['isOk' => false, 'error' => 'Not allowed.'], 403);
    }
    return $row;
}

function user_payload($row) {
    global $pdo;
    $out = [
        'id'           => (int)$row['id'],
        'username'     => $row['username'],
        'role'         => $row['role'],
        'display_name' => $row['display_name'],
        'customer_id'  => $row['customer_id'],
        'tech_name'    => $row['tech_name'],
        'must_change'  => !empty($row['must_change']),
    ];
    if ($row['role'] === 'customer' && $row['customer_id']) {
        $st = $pdo->prepare("SELECT customer_name, contact_name, phone, email FROM records WHERE record_type = 'customer' AND customer_id = ? LIMIT 1");
        $st->execute([$row['customer_id']]);
        $c = $st->fetch() ?: [];
        $out['customer_name'] = $c['customer_name'] ?? $row['display_name'];
        $out['contact_name']  = $c['contact_name'] ?? $row['display_name'];
        $out['phone']         = $c['phone'] ?? '';
        $out['email']         = $c['email'] ?? '';
    }
    return $out;
}

/* ---------- records table helpers ---------- */
function record_columns() {
    global $pdo;
    static $cols = null;
    if ($cols === null) {
        $cols = [];
        foreach ($pdo->query('SHOW COLUMNS FROM records') as $c) { $cols[$c['Field']] = $c['Type']; }
    }
    return $cols;
}
function to_db_time($v) {
    if ($v === null || $v === '') return null;
    $t = strtotime((string)$v);
    return $t ? gmdate('Y-m-d H:i:s', $t) : null;
}
function to_iso_time($v) {
    if ($v === null || $v === '') return $v;
    if (preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $v)) return str_replace(' ', 'T', $v) . 'Z';
    return $v;
}
function clean_record($input) {
    $colInfo  = record_columns();
    $timeCols = ['created_at', 'updated_at', 'msg_timestamp'];
    $intCols  = ['quantity', 'reorder_level', 'report_submitted'];
    $numCols  = ['amount'];
    $out = [];
    foreach ($input as $k => $v) {
        if (!isset($colInfo[$k])) continue;
        if (is_array($v) || is_object($v)) continue;
        if (in_array($k, $timeCols, true)) {
            $isDt = stripos($colInfo[$k], 'datetime') !== false || stripos($colInfo[$k], 'timestamp') !== false;
            $v = $isDt ? to_db_time($v) : ($v === '' ? null : (string)$v);
        } elseif (in_array($k, $intCols, true)) {
            $v = ($v === '' || $v === null) ? 0 : (int)(is_bool($v) ? ($v ? 1 : 0) : $v);
        } elseif ($k === 'site_lat' || $k === 'site_lng') {
            // Exact map-pin coordinates; blank or out-of-range values are stored as NULL.
            $lim = $k === 'site_lat' ? 90 : 180;
            $v = (is_numeric($v) && abs((float)$v) <= $lim && $v !== '') ? round((float)$v, 7) : null;
        } elseif (in_array($k, $numCols, true)) {
            $v = ($v === '' || $v === null) ? 0 : (float)$v;
        } else {
            $v = is_bool($v) ? (int)$v : (string)$v;
        }
        $out[$k] = $v;
    }
    return $out;
}
function insert_record($input) {
    global $pdo;
    $data = clean_record($input);
    $id = 'vtech_' . bin2hex(random_bytes(8)); // collision-proof (uniqid() can repeat under load)
    $data['__backendId'] = $id;
    if (empty($data['created_at'])) $data['created_at'] = gmdate('Y-m-d H:i:s');
    $data = clean_record($data);
    $cols = array_keys($data);
    $sql = 'INSERT INTO records (`' . implode('`, `', $cols) . '`) VALUES (:' . implode(', :', $cols) . ')';
    $pdo->prepare($sql)->execute($data);
    return $id;
}
function update_record($id, $changes) {
    global $pdo;
    $data = clean_record($changes);
    unset($data['__backendId'], $data['created_at'], $data['rev']);
    $data['updated_at'] = gmdate('Y-m-d H:i:s');
    $data = clean_record($data);
    $set = [];
    foreach (array_keys($data) as $k) { $set[] = "`$k` = :$k"; }
    if (isset(record_columns()['rev'])) $set[] = '`rev` = IFNULL(`rev`, 0) + 1'; // lets pollers detect any edit exactly
    $data['__id'] = $id;
    $pdo->prepare('UPDATE records SET ' . implode(', ', $set) . ' WHERE `__backendId` = :__id')->execute($data);
}
function random_code($n) {
    $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $s = '';
    for ($i = 0; $i < $n; $i++) { $s .= $alphabet[random_int(0, strlen($alphabet) - 1)]; }
    return $s;
}
?>
