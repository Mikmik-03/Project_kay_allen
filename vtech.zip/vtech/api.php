<?php
require_once __DIR__ . '/lib.php';
$portal = request_portal();
ensure_schema();
start_session($portal);
$user = require_user($portal);
session_write_close(); // don't hold the session lock while we work (the portals poll every 3s)

// A signed-in user who still has a temporary password may read, but not change anything,
// until they set their own password (auth.php?action=change_password).
if ($_SERVER['REQUEST_METHOD'] !== 'GET' && !empty($user['must_change'])) {
    json_out(['isOk' => false, 'error' => 'Please change your temporary password first (use the password warning at the top of the page).'], 403);
}

$role   = $user['role'];
$method = $_SERVER['REQUEST_METHOD'];
$input  = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) { $input = []; }

function starts_with($s, $prefix) { return strncmp((string)$s, $prefix, strlen($prefix)) === 0; }
function pick($arr, $keys) { $o = []; foreach ($keys as $k) { if (array_key_exists($k, $arr)) $o[$k] = $arr[$k]; } return $o; }
function fail($code, $msg) { json_out(['isOk' => false, 'error' => $msg], $code); }

// Trim user-supplied text to the column sizes so an over-long entry can't cause a database error.
function cap_lengths($data) {
    $max = ['title' => 255, 'job_title' => 255, 'site_address' => 500, 'service_type' => 120, 'notes' => 2000,
            'msg_text' => 4000, 'job_id' => 40, 'scheduled_date' => 20, 'scheduled_time' => 40, 'msg_type' => 20,
            'equipment_used' => 4000, 'checklist_progress' => 4000, 'workflow_stage' => 60];
    foreach ($max as $k => $n) {
        if (isset($data[$k]) && is_string($data[$k])) $data[$k] = mb_substr($data[$k], 0, $n);
    }
    return $data;
}

// Technician file list: "name::stored|name::stored" where every stored file really came from upload.php.
function valid_upload_list($list) {
    foreach (explode('|', (string)$list) as $entry) {
        if ($entry === '') continue;
        if (strpos($entry, '::') === false) {
            if (!preg_match('/^[A-Za-z0-9._ \-()]{1,120}$/', $entry)) return false;
            continue;
        }
        if (!preg_match('/^[A-Za-z0-9._ \-()]{1,120}::([a-f0-9]{20}\.(?:jpg|jpeg|png|webp|pdf))$/', $entry, $m)) return false;
        if (!is_file(__DIR__ . '/uploads/' . $m[1])) return false;
    }
    return true;
}

// Uploaded file names ("name::stored") found in a documents_uploaded value.
function stored_names($list) {
    preg_match_all('/::([a-f0-9]{20}\.(?:jpg|jpeg|png|webp|pdf))/', (string)$list, $m);
    return $m[1];
}
// Deletes uploaded files that no remaining record points to (call after the rows are gone).
function remove_unreferenced_files($names) {
    global $pdo;
    foreach (array_unique($names) as $n) {
        $st = $pdo->prepare('SELECT 1 FROM records WHERE documents_uploaded LIKE ? LIMIT 1');
        $st->execute(['%::' . $n . '%']);
        if (!$st->fetchColumn()) { $p = __DIR__ . '/uploads/' . $n; if (is_file($p)) @unlink($p); }
    }
}

// Keeps invoices and payments consistent. Runs inside the caller's transaction.
function sync_payment_and_invoice($existing, $changes) {
    global $pdo;
    $type = $existing['record_type'];
    $new  = $changes['status'] ?? null;
    if ($type === 'payment' && $new === 'Confirmed' && !empty($existing['pay_invoice_id'])) {
        $inv = find_record($existing['pay_invoice_id']);
        if ($inv && $inv['record_type'] === 'invoice' && $inv['status'] !== 'Paid') update_record($inv['__backendId'], ['status' => 'Paid']);
    } elseif ($type === 'invoice' && $new === 'Paid') {
        $st = $pdo->prepare("SELECT `__backendId` FROM records WHERE record_type = 'payment' AND pay_invoice_id = ? AND status = 'Submitted'");
        $st->execute([$existing['__backendId']]);
        foreach ($st->fetchAll() as $p) update_record($p['__backendId'], ['status' => 'Confirmed']);
    }
}

function visible_to($user, $rec) {
    $type = $rec['record_type'] ?? '';
    switch ($user['role']) {
        case 'admin':
            return true;
        case 'customer':
            if ($type === 'admin_profile' || $type === 'payment_method') return true;
            return !empty($rec['customer_id']) && $rec['customer_id'] === $user['customer_id'];
        case 'technician':
            $name = $user['tech_name'];
            if ($type === 'admin_profile') return true;
            if (in_array($type, JOB_TYPES, true)) return ($rec['assigned_technician'] ?? '') === $name;
            if ($type === 'technician') return ($rec['contact_name'] ?? '') === $name;
            if ($type === 'message' || $type === 'call') return ($rec['thread_id'] ?? '') === 'tech:' . $name;
            return false;
    }
    return false;
}

function customer_profile($customerId) {
    global $pdo;
    $st = $pdo->prepare("SELECT customer_name, contact_name, phone, email FROM records WHERE record_type = 'customer' AND customer_id = ? LIMIT 1");
    $st->execute([$customerId]);
    return $st->fetch() ?: ['customer_name' => '', 'contact_name' => '', 'phone' => '', 'email' => ''];
}
function find_record($id) {
    global $pdo;
    $st = $pdo->prepare('SELECT * FROM records WHERE `__backendId` = ?');
    $st->execute([$id]);
    return $st->fetch();
}

try {
    /* ------------------------------ READ ------------------------------ */
    if ($method === 'GET') {
        // Narrow the query in SQL so each portal only loads its own rows (the portals poll often).
        // visible_to() below still makes the final, exact decision for every row.
        $where = '';
        $args  = [];
        if ($role === 'customer') {
            $where = " WHERE record_type IN ('admin_profile', 'payment_method') OR customer_id = ?";
            $args  = [(string)$user['customer_id']];
        } elseif ($role === 'technician') {
            $jobTypes = "'" . implode("','", JOB_TYPES) . "'";
            $where = " WHERE record_type = 'admin_profile'"
                   . " OR (record_type IN ($jobTypes) AND assigned_technician = ?)"
                   . " OR (record_type = 'technician' AND contact_name = ?)"
                   . " OR (record_type IN ('message', 'call') AND thread_id = ?)";
            $args  = [(string)$user['tech_name'], (string)$user['tech_name'], 'tech:' . $user['tech_name']];
        }
        // Cheap change check: a fingerprint of the rows this user can see. If the browser already has
        // this exact version, answer 304 with no body instead of loading and sending everything again.
        $fp = $pdo->prepare('SELECT COUNT(*) AS c, SUM(CRC32(CONCAT_WS(\'|\', `__backendId`, IFNULL(`rev`, 0), IFNULL(`updated_at`, \'\'), IFNULL(`status`, \'\')))) AS s FROM records' . $where);
        $fp->execute($args);
        $f = $fp->fetch();
        $etag = '"' . md5($portal . '|' . $user['id'] . '|' . $f['c'] . '|' . $f['s']) . '"';
        header('ETag: ' . $etag);
        header('Cache-Control: no-store');
        if (($_SERVER['HTTP_IF_NONE_MATCH'] ?? '') === $etag) { http_response_code(304); exit; }
        $st = $pdo->prepare('SELECT * FROM records' . $where . ' ORDER BY created_at DESC');
        $st->execute($args);
        $rows = $st->fetchAll();
        $out = [];
        foreach ($rows as $rec) {
            if (!visible_to($user, $rec)) continue;
            if ($role !== 'admin' && $rec['record_type'] === 'admin_profile') {
                $rec = pick($rec, ['__backendId', 'record_type', 'title', 'contact_name', 'notes', 'phone', 'email', 'status', 'created_at']);
            }
            if (array_key_exists('report_submitted', $rec)) $rec['report_submitted'] = !empty($rec['report_submitted']);
            foreach (['site_lat', 'site_lng'] as $f) { if (array_key_exists($f, $rec)) $rec[$f] = ($rec[$f] === null || $rec[$f] === '') ? null : (float)$rec[$f]; }
            foreach (['amount'] as $f) { if (array_key_exists($f, $rec)) $rec[$f] = (float)$rec[$f]; }
            foreach (['quantity', 'reorder_level'] as $f) { if (array_key_exists($f, $rec)) $rec[$f] = (int)$rec[$f]; }
            foreach (['created_at', 'updated_at', 'msg_timestamp'] as $f) { if (array_key_exists($f, $rec)) $rec[$f] = to_iso_time($rec[$f]); }
            $out[] = $rec;
        }
        json_out($out);
    }

    /* ----------------------------- CREATE ----------------------------- */
    if ($method === 'POST') {
        $type = (string)($input['record_type'] ?? '');
        if ($type === '' || in_array($type, ['customer', 'technician'], true)) {
            fail(403, 'Accounts must be created through the sign-up / admin account screens.');
        }
        if ($role === 'admin') {
            $id = insert_record($input);
            json_out(['isOk' => true, 'id' => $id]);
        }

        if ($role === 'customer') {
            $allowedTypes = ['appointment', 'maintenance_request', 'site', 'message', 'callback_request', 'sign_off', 'payment'];
            if (!in_array($type, $allowedTypes, true)) fail(403, 'Not allowed.');
            $cid = $user['customer_id'];
            $p = customer_profile($cid);
            $data = pick($input, ['title', 'notes', 'site_address', 'job_title', 'service_type', 'job_id', 'scheduled_date', 'scheduled_time', 'priority', 'msg_text', 'msg_timestamp', 'msg_type', 'site_lat', 'site_lng']);
            $data = cap_lengths($data);
            $data['record_type']   = $type;
            $data['customer_id']   = $cid;
            $data['customer_name'] = $p['customer_name'];
            $data['contact_name']  = $p['contact_name'];
            $data['phone']         = $p['phone'];
            $data['email']         = $p['email'];
            $data['role']          = 'customer';
            if (!in_array($data['priority'] ?? 'Normal', ['Normal', 'High', 'Urgent'], true)) $data['priority'] = 'Normal';
            if ($type === 'appointment') { $data['status'] = 'Booked'; $data['assigned_technician'] = ''; $data['priority'] = 'Normal'; }
            elseif ($type === 'maintenance_request') { $data['status'] = 'Requested'; $data['assigned_technician'] = ''; }
            elseif ($type === 'site') { $data['status'] = 'Active'; }
            elseif ($type === 'message') {
                $data['thread_id'] = 'customer:' . $cid; $data['status'] = 'Unread'; $data['msg_sender'] = $p['contact_name'];
            } elseif ($type === 'callback_request') {
                $data['thread_id'] = 'customer:' . $cid; $data['status'] = 'Requested';
            } elseif ($type === 'sign_off') {
                $jobId = (string)($data['job_id'] ?? '');
                $st = $pdo->prepare('SELECT 1 FROM records WHERE job_id = ? AND customer_id = ? AND report_submitted = 1 LIMIT 1');
                $st->execute([$jobId, $cid]);
                if ($jobId === '' || !$st->fetchColumn()) fail(403, 'There is no completed report to sign off.');
                $data['status'] = 'Signed Off';
            }
            if ($type === 'payment') {
                // Customers can only report a payment against their own unpaid invoice,
                // using a method the admin offers. The amount always comes from the invoice.
                $pdo->beginTransaction(); // committed together with insert_record() below; any fail() path rolls back via json_out exit -> connection close
                $lk = $pdo->prepare('SELECT `__backendId` FROM records WHERE `__backendId` = ? FOR UPDATE'); // serialises double-clicks on the same invoice
                $lk->execute([(string)($input['pay_invoice_id'] ?? '')]);
                $inv = find_record((string)($input['pay_invoice_id'] ?? ''));
                if (!$inv || $inv['record_type'] !== 'invoice' || $inv['customer_id'] !== $cid) fail(404, 'Invoice not found.');
                if ($inv['status'] === 'Paid') fail(409, 'This invoice is already paid.');
                $st = $pdo->prepare("SELECT 1 FROM records WHERE record_type = 'payment' AND pay_invoice_id = ? AND status = 'Submitted' LIMIT 1");
                $st->execute([$inv['__backendId']]);
                if ($st->fetchColumn()) fail(409, 'A payment for this invoice is already waiting for confirmation.');
                $method = find_record((string)($input['pay_account_id'] ?? ''));
                if (!$method || $method['record_type'] !== 'payment_method' || $method['status'] !== 'Active') fail(400, 'Choose one of the listed payment methods.');
                $ref = trim((string)($input['pay_reference'] ?? ''));
                if (strlen($ref) < 4 || strlen($ref) > 60) fail(400, 'Enter the reference number from your payment (4 to 60 characters).');
                // The same payment reference must not be claimed by another customer.
                $st = $pdo->prepare("SELECT 1 FROM records WHERE record_type = 'payment' AND pay_reference = ? AND customer_id <> ? AND status IN ('Submitted', 'Confirmed') LIMIT 1");
                $st->execute([$ref, $cid]);
                if ($st->fetchColumn()) fail(409, 'That reference number has already been used. Please check it or contact us.');
                // Receipt screenshot/photo: "display name::stored file name" as returned by upload.php. Required except for cash.
                $receipt = trim((string)($input['documents_uploaded'] ?? ''));
                if ($receipt !== '') {
                    if (!preg_match('/^[A-Za-z0-9._ \-()]{1,120}::([a-f0-9]{20}\.(?:jpg|jpeg|png|webp|pdf))$/', $receipt, $mm) || !is_file(__DIR__ . '/uploads/' . $mm[1])) {
                        fail(400, 'The receipt upload could not be verified. Please attach it again.');
                    }
                } elseif (($method['pay_method'] ?? '') !== 'Cash') {
                    fail(400, 'Attach a screenshot or photo of your payment receipt.');
                }
                $data = [
                    'record_type' => 'payment', 'status' => 'Submitted', 'role' => 'customer',
                    'customer_id' => $cid, 'customer_name' => $p['customer_name'], 'contact_name' => $p['contact_name'],
                    'phone' => $p['phone'], 'email' => $p['email'],
                    'title' => 'Payment · ' . $inv['title'], 'amount' => (float)$inv['amount'],
                    'pay_invoice_id' => $inv['__backendId'], 'pay_method' => $method['pay_method'] ?: $method['title'],
                    'pay_reference' => $ref, 'documents_uploaded' => $receipt, 'notes' => mb_substr(trim((string)($input['notes'] ?? '')), 0, 500),
                ];
            }
            $id = insert_record($data);
            if ($pdo->inTransaction()) $pdo->commit();
            json_out(['isOk' => true, 'id' => $id]);
        }

        if ($role === 'technician') {
            if (!in_array($type, ['message', 'call'], true)) fail(403, 'Not allowed.');
            $name = $user['tech_name'];
            $data = cap_lengths(pick($input, ['title', 'msg_text', 'msg_timestamp', 'msg_type']));
            $data['record_type'] = $type;
            $data['thread_id'] = 'tech:' . $name;
            $data['role'] = 'technician';
            $data['msg_sender'] = $name;
            $data['assigned_technician'] = $name;
            $data['status'] = $type === 'call' ? 'Active' : 'Unread';
            $id = insert_record($data);
            json_out(['isOk' => true, 'id' => $id]);
        }
        fail(403, 'Not allowed.');
    }

    /* ----------------------------- UPDATE ----------------------------- */
    if ($method === 'PUT') {
        $id = (string)($input['__backendId'] ?? '');
        if ($id === '') fail(400, 'Missing __backendId');
        $existing = find_record($id);
        if (!$existing || !visible_to($user, $existing)) fail(404, 'Record not found.');
        $type = $existing['record_type'];

        if ($role === 'admin') {
            $changes = $input;
            unset($changes['__backendId'], $changes['created_at'], $changes['record_type']);
            $pdo->beginTransaction();
            update_record($id, $changes);
            sync_payment_and_invoice($existing, $changes); // confirming a payment marks its invoice paid (and vice versa) in one step
            $pdo->commit();
            json_out(['isOk' => true]);
        }

        $changes = [];
        if ($role === 'customer') {
            if (in_array($type, JOB_TYPES, true)) {
                if (($input['status'] ?? '') === 'Cancelled' && in_array($existing['status'], ['Booked', 'Requested', 'Assigned'], true)) {
                    $changes = ['status' => 'Cancelled'];
                } elseif (starts_with($input['signature_status'] ?? '', 'Customer signed off') && !empty($existing['report_submitted']) && !starts_with($existing['signature_status'], 'Customer signed off')) {
                    $changes = ['signature_status' => 'Customer signed off on ' . local_date('d/m/Y'), 'workflow_stage' => 'Customer Sign-off'];
                }
            } elseif ($type === 'message' && $existing['role'] === 'admin' && ($input['status'] ?? '') === 'Read') {
                $changes = ['status' => 'Read'];
            }
        } elseif ($role === 'technician') {
            if (in_array($type, JOB_TYPES, true)) {
                $changes = cap_lengths(pick($input, ['workflow_stage', 'checklist_progress', 'equipment_used', 'documents_uploaded', 'notes', 'report_submitted']));
                if (isset($changes['documents_uploaded']) && !valid_upload_list($changes['documents_uploaded'])) fail(400, 'One of the attached files could not be verified. Please upload it again.');
                if (isset($input['status']) && in_array($input['status'], ['Assigned', 'In progress', 'Paused', 'Completed'], true)) $changes['status'] = $input['status'];
                $sig = (string)($input['signature_status'] ?? '');
                if ($sig !== '' && $sig !== $existing['signature_status'] && starts_with($sig, 'On-site acknowledgement') && !starts_with($existing['signature_status'], 'Customer signed off')) {
                    $changes['signature_status'] = $sig;
                }
            } elseif ($type === 'technician') {
                if (in_array($input['status'] ?? '', ['Available', 'Unavailable'], true)) $changes = ['status' => $input['status']];
            } elseif ($type === 'message' && $existing['role'] === 'admin' && ($input['status'] ?? '') === 'Read') {
                $changes = ['status' => 'Read'];
            } elseif ($type === 'call') {
                $changes = pick($input, ['call_duration']);
                if (in_array($input['status'] ?? '', ['Active', 'Ended'], true)) $changes['status'] = $input['status'];
            }
        }
        if (!$changes) fail(403, 'That change is not allowed.');
        update_record($id, $changes);
        json_out(['isOk' => true]);
    }

    /* ----------------------------- DELETE ----------------------------- */
    if ($method === 'DELETE') {
        if ($role !== 'admin') fail(403, 'Only the admin can delete records.');
        $id = (string)($input['__backendId'] ?? ($_GET['id'] ?? ''));
        if ($id === '') fail(400, 'Missing id');
        $rec = find_record($id);
        if (!$rec) json_out(['isOk' => true]);
        $files = stored_names($rec['documents_uploaded'] ?? '');
        $pdo->beginTransaction();
        $pdo->prepare('DELETE FROM records WHERE `__backendId` = ?')->execute([$id]);
        if ($rec['record_type'] === 'customer' && $rec['customer_id']) {
            // Removing a customer also removes their jobs, sites, messages and files.
            // Invoices and payments are KEPT (they still carry the customer's name) for your accounting records.
            $cid = $rec['customer_id'];
            $st = $pdo->prepare("SELECT documents_uploaded FROM records WHERE (customer_id = ? OR thread_id = ?) AND record_type NOT IN ('invoice', 'payment') AND documents_uploaded IS NOT NULL AND documents_uploaded <> ''");
            $st->execute([$cid, 'customer:' . $cid]);
            foreach ($st->fetchAll() as $r) { $files = array_merge($files, stored_names($r['documents_uploaded'])); }
            $pdo->prepare("DELETE FROM records WHERE (customer_id = ? OR thread_id = ?) AND record_type NOT IN ('invoice', 'payment')")->execute([$cid, 'customer:' . $cid]);
            $pdo->prepare("DELETE FROM users WHERE role = 'customer' AND customer_id = ?")->execute([$cid]);
        } elseif ($rec['record_type'] === 'technician' && $rec['contact_name']) {
            $pdo->prepare("DELETE FROM users WHERE role = 'technician' AND tech_name = ?")->execute([$rec['contact_name']]);
        }
        $pdo->commit();
        remove_unreferenced_files($files);
        json_out(['isOk' => true]);
    }

    fail(405, 'Method not allowed');
} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    log_error($e, 'api.php');
    json_out(['isOk' => false, 'error' => 'Server error. If this keeps happening, check the Apache error log (and that schema.sql has been run).'], 500);
}
?>
