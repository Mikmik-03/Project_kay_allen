-- VTech CCTV: run once in phpMyAdmin (SQL tab) on database `vtech_cctv`.
-- Safe to re-run: creates the table if missing and adds any missing columns (MariaDB / XAMPP).

CREATE DATABASE IF NOT EXISTS vtech_cctv CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE vtech_cctv;

CREATE TABLE IF NOT EXISTS records (
  __backendId VARCHAR(64) NOT NULL PRIMARY KEY,
  record_type VARCHAR(40) NOT NULL DEFAULT '',
  created_at  VARCHAR(40) NULL,
  updated_at  VARCHAR(40) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE records
  ADD COLUMN IF NOT EXISTS title VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS status VARCHAR(40) NULL,
  ADD COLUMN IF NOT EXISTS priority VARCHAR(20) NULL,
  ADD COLUMN IF NOT EXISTS notes TEXT NULL,
  ADD COLUMN IF NOT EXISTS role VARCHAR(20) NULL,
  ADD COLUMN IF NOT EXISTS customer_id VARCHAR(64) NULL,
  ADD COLUMN IF NOT EXISTS customer_name VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS contact_name VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS phone VARCHAR(60) NULL,
  ADD COLUMN IF NOT EXISTS email VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS site_address VARCHAR(500) NULL,
  ADD COLUMN IF NOT EXISTS scheduled_date VARCHAR(20) NULL,
  ADD COLUMN IF NOT EXISTS scheduled_time VARCHAR(40) NULL,
  ADD COLUMN IF NOT EXISTS service_type VARCHAR(120) NULL,
  ADD COLUMN IF NOT EXISTS assigned_technician VARCHAR(120) NULL,
  ADD COLUMN IF NOT EXISTS amount DECIMAL(12,2) NULL,
  ADD COLUMN IF NOT EXISTS due_date VARCHAR(20) NULL,
  ADD COLUMN IF NOT EXISTS equipment_name VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS quantity INT NULL,
  ADD COLUMN IF NOT EXISTS reorder_level INT NULL,
  ADD COLUMN IF NOT EXISTS thread_id VARCHAR(120) NULL,
  ADD COLUMN IF NOT EXISTS msg_sender VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS msg_text TEXT NULL,
  ADD COLUMN IF NOT EXISTS msg_timestamp VARCHAR(40) NULL,
  ADD COLUMN IF NOT EXISTS msg_type VARCHAR(20) NULL,
  ADD COLUMN IF NOT EXISTS call_duration VARCHAR(30) NULL,
  ADD COLUMN IF NOT EXISTS job_id VARCHAR(40) NULL,
  ADD COLUMN IF NOT EXISTS job_title VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS workflow_stage VARCHAR(60) NULL,
  ADD COLUMN IF NOT EXISTS checklist_progress TEXT NULL,
  ADD COLUMN IF NOT EXISTS equipment_used TEXT NULL,
  ADD COLUMN IF NOT EXISTS documents_uploaded TEXT NULL,
  ADD COLUMN IF NOT EXISTS signature_status VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS report_submitted TINYINT(1) NOT NULL DEFAULT 0,
  -- Payments: payment_method records (admin) and payment records (customer submissions)
  ADD COLUMN IF NOT EXISTS pay_method VARCHAR(40) NULL,
  ADD COLUMN IF NOT EXISTS pay_account_no VARCHAR(120) NULL,
  ADD COLUMN IF NOT EXISTS pay_reference VARCHAR(120) NULL,
  ADD COLUMN IF NOT EXISTS pay_invoice_id VARCHAR(64) NULL,
  -- Exact map-pin location of the customer's site (set from the customer's map pin)
  ADD COLUMN IF NOT EXISTS site_lat DECIMAL(10,7) NULL,
  ADD COLUMN IF NOT EXISTS site_lng DECIMAL(10,7) NULL;

-- Login tables. (The portals also create these automatically on first use, and create
-- the default administrator account: username "admin". Change its password after first sign-in.)
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(60) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(20) NOT NULL,
  display_name VARCHAR(255) NOT NULL DEFAULT '',
  customer_id VARCHAR(64) NULL,
  tech_name VARCHAR(120) NULL,
  must_change TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Google sign-in link (also added automatically by the portals on first use).
ALTER TABLE users ADD COLUMN IF NOT EXISTS google_sub VARCHAR(40) NULL;
ALTER TABLE users ADD UNIQUE INDEX IF NOT EXISTS uq_google_sub (google_sub);

CREATE TABLE IF NOT EXISTS login_attempts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(60) NOT NULL,
  ip VARCHAR(45) NOT NULL,
  attempted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX (username), INDEX (attempted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------------
-- To REMOVE ALL existing sample/test rows and start clean, run this
-- (it cannot be undone):
--
--   TRUNCATE TABLE records;   -- jobs, messages, invoices, etc.
--   (also run: DELETE FROM users WHERE role <> 'admin';  to remove old customer/technician logins)
-- ------------------------------------------------------------------
