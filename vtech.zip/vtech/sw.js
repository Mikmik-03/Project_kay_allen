// VTech service worker: makes the portals installable and keeps the app shell available offline.
// It NEVER stores private data: api.php, auth.php, upload.php and download.php always go to the network.
const VERSION = 'v1';                       // bump when you change this file's caching rules
const SHELL = 'vtech-shell-' + VERSION;
const PAGES = 'vtech-pages-' + VERSION;
const CDN = 'vtech-cdn-' + VERSION;
const PRECACHE = ['offline.html', 'vtech-ui.css', 'vtech-ui.js', 'sdk-override.js', 'pwa.js', 'logo.png', 'favicon.png',
                  'icons/icon-192.png', 'icons/icon-512.png'];
const CDN_HOSTS = ['cdn.tailwindcss.com', 'cdn.jsdelivr.net', 'fonts.googleapis.com', 'fonts.gstatic.com'];
const PRIVATE = /\/(api|auth|upload|download)\.php$/;

self.addEventListener('install', (e) => {
  e.waitUntil((async () => {
    const cache = await caches.open(SHELL);
    await Promise.all(PRECACHE.map((u) => cache.add(u).catch(() => {})));   // one missing file must not block install
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', (e) => {
  e.waitUntil((async () => {
    const keep = [SHELL, PAGES, CDN];
    for (const k of await caches.keys()) { if (k.startsWith('vtech-') && !keep.includes(k)) await caches.delete(k); }
    await self.clients.claim();
  })());
});

async function networkFirst(req, cacheName, fallbackPage) {
  const cache = await caches.open(cacheName);
  try {
    const res = await fetch(req);
    if (res.ok && !res.redirected) cache.put(req, res.clone());
    return res;
  } catch (err) {
    const hit = await cache.match(req, { ignoreSearch: false });
    if (hit) return hit;
    if (fallbackPage) { const off = await caches.match(fallbackPage); if (off) return off; }
    throw err;
  }
}

async function cacheFirst(req, cacheName) {
  const cache = await caches.open(cacheName);
  const hit = await cache.match(req);
  if (hit) return hit;
  const res = await fetch(req);
  if (res.ok || res.type === 'opaque') cache.put(req, res.clone());
  return res;
}

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  if (url.origin === self.location.origin) {
    if (PRIVATE.test(url.pathname)) return;                       // always live, never cached
    if (req.mode === 'navigate') { e.respondWith(networkFirst(req, PAGES, 'offline.html')); return; }
    e.respondWith(networkFirst(req, SHELL));                      // css/js/images: fresh when online, cached when offline
    return;
  }
  if (CDN_HOSTS.includes(url.hostname)) { e.respondWith(cacheFirst(req, CDN)); return; }   // pinned, versioned library URLs
  // everything else (Google sign-in, map tiles, etc.) goes straight to the network
});
