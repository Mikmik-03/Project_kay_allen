// Shared UX layer for all VTech pages (loaded after each page's own scripts).
// - VUI.ask(): styled confirm / prompt dialog (replaces the browser's confirm() and prompt())
// - Drawers: Esc to close, focus moves in and returns, Tab stays inside, page scroll locks
// - Offline banner, aria-current on navigation, Esc closes the notification panel
(function () {
  "use strict";
  const FOCUSABLE = 'a[href],button:not([disabled]),input:not([disabled]):not([type=hidden]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';
  const dark = ["admin", "technician"].includes(window.PORTAL);
  document.documentElement.classList.add(dark ? "vui-dark" : "vui-light");

  const visible = (el) => el.offsetParent !== null || el === document.activeElement;
  const focusables = (root) => Array.from(root.querySelectorAll(FOCUSABLE)).filter(visible);

  /* ---------- scroll lock shared by every open layer ---------- */
  let locks = 0;
  function lockScroll(on) {
    locks = Math.max(0, locks + (on ? 1 : -1));
    document.body.classList.toggle("vui-locked", locks > 0);
  }

  /* ---------- confirm / prompt dialog ---------- */
  // VUI.ask({ title, message, confirmLabel, cancelLabel, danger, field: {label, placeholder, required} })
  // resolves { ok: boolean, value: string }
  function ask(opts) {
    opts = opts || {};
    return new Promise((resolve) => {
      const opener = document.activeElement;
      const wrap = document.createElement("div");
      wrap.className = "vui-dialog-bg";
      const uid = "vui" + Math.random().toString(36).slice(2, 7);
      const f = opts.field;
      wrap.innerHTML =
        '<div class="vui-dialog" role="alertdialog" aria-modal="true" aria-labelledby="' + uid + 't" aria-describedby="' + uid + 'm">' +
        '<h2 id="' + uid + 't"></h2><p id="' + uid + 'm"></p>' +
        (f ? '<label for="' + uid + 'f"></label><textarea id="' + uid + 'f" rows="3" maxlength="300"></textarea>' : "") +
        '<div class="vui-dialog-actions"><button type="button" class="vui-btn vui-btn-ghost" data-no></button>' +
        '<button type="button" class="vui-btn ' + (opts.danger ? "vui-btn-danger" : "vui-btn-primary") + '" data-yes></button></div></div>';
      const box = wrap.firstChild;
      box.querySelector("h2").textContent = opts.title || "Are you sure?";
      box.querySelector("p").textContent = opts.message || "";
      box.querySelector("[data-no]").textContent = opts.cancelLabel || "Cancel";
      box.querySelector("[data-yes]").textContent = opts.confirmLabel || "Confirm";
      if (f) {
        box.querySelector("label").textContent = f.label || "";
        const ta = box.querySelector("textarea");
        ta.placeholder = f.placeholder || "";
      }
      document.body.appendChild(wrap);
      lockScroll(true);
      requestAnimationFrame(() => wrap.classList.add("open"));

      const field = f ? box.querySelector("textarea") : null;
      const done = (ok) => {
        document.removeEventListener("keydown", onKey, true);
        lockScroll(false);
        wrap.classList.remove("open");
        setTimeout(() => wrap.remove(), 160);
        if (opener && opener.focus) opener.focus();
        resolve({ ok, value: field ? field.value.trim() : "" });
      };
      const onKey = (e) => {
        if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); done(false); }
        else if (e.key === "Tab") {
          const els = focusables(box); if (!els.length) return;
          const first = els[0], last = els[els.length - 1];
          if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
          else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
        }
      };
      document.addEventListener("keydown", onKey, true);
      box.querySelector("[data-no]").addEventListener("click", () => done(false));
      box.querySelector("[data-yes]").addEventListener("click", () => {
        if (f && f.required && !field.value.trim()) { field.focus(); field.classList.add("vui-invalid"); return; }
        done(true);
      });
      wrap.addEventListener("mousedown", (e) => { if (e.target === wrap) done(false); });
      // Safer default focus: the cancel button for destructive actions, the field for prompts.
      (field || box.querySelector(opts.danger ? "[data-no]" : "[data-yes]")).focus();
    });
  }

  /* ---------- drawers (customer portal) and the technician account modal ---------- */
  function initLayer(layer, closeFn) {
    let opener = null, wasOpen = false;
    const panel = layer.querySelector(".drawer-panel") || layer;
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-modal", "true");
    const sync = () => {
      const open = layer.classList.contains("open") || (layer.id === "account-modal" && !layer.classList.contains("hidden"));
      if (open === wasOpen) return;
      wasOpen = open;
      lockScroll(open);
      if (open) {
        opener = document.activeElement;
        setTimeout(() => {
          const t = panel.querySelector("[autofocus]") || panel.querySelector("input:not([type=hidden]),select,textarea") || focusables(panel)[0];
          if (t) t.focus({ preventScroll: true });
        }, 60);
      } else if (opener && document.contains(opener) && opener.focus) {
        opener.focus({ preventScroll: true });
      }
    };
    new MutationObserver(sync).observe(layer, { attributes: true, attributeFilter: ["class"] });
    layer.addEventListener("keydown", (e) => {
      if (!wasOpen) return;
      if (e.key === "Escape") { e.stopPropagation(); closeFn(); }
      else if (e.key === "Tab") {
        const els = focusables(panel); if (!els.length) return;
        const first = els[0], last = els[els.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    });
  }


  /* ---------- app shell: replace the permanent sidebar with a top bar + floating dock ---------- */
  function initShell() {
    const aside = document.querySelector(".side-rail, .side-nav");
    if (!aside) return;
    const items = Array.from(aside.querySelectorAll("[data-view]"));
    if (!items.length) return;

    const dock = document.createElement("nav");
    dock.className = "vt-dock";
    dock.setAttribute("aria-label", "Main navigation");
    const track = document.createElement("div");
    track.className = "vt-dock-track";
    items.forEach((el) => {
      // Keep the elements (and their click handlers); only normalise their look.
      const label = Array.from(el.querySelectorAll("span")).find((s) => s.id !== "nav-unread" && s.textContent.trim());
      const text = label ? label.textContent.trim() : (el.getAttribute("aria-label") || "");
      if (label) { label.className = "vt-label"; label.removeAttribute("style"); }
      el.className = Array.from(el.classList).filter((c) => /^(nav-item|nav-link|rail-btn|active)$/.test(c)).join(" ");
      el.removeAttribute("style");
      el.setAttribute("data-tip", text);
      if (!el.getAttribute("aria-label")) el.setAttribute("aria-label", text);
      track.appendChild(el);
    });
    dock.appendChild(track);
    document.body.appendChild(dock);

    const reveal = () => {
      const a = track.querySelector(".active");
      if (a) track.scrollTo({ left: a.offsetLeft - (track.clientWidth - a.offsetWidth) / 2, behavior: "smooth" });
    };
    const obs = new MutationObserver(reveal);
    items.forEach((el) => obs.observe(el, { attributes: true, attributeFilter: ["class"] }));
    setTimeout(reveal, 80);

    // Top bar: brand on the left, page context beside it, actions on the right.
    const top = document.querySelector(".topbar, .main-area > header, .content-pad > header");
    if (top) {
      top.classList.add("vt-top");
      const names = { admin: "Admin & Dispatch", technician: "Field technician", customer: "Customer portal" };
      const brand = document.createElement("div");
      brand.className = "vt-brand";
      brand.innerHTML = '<img src="logo.png" alt="VTech logo" width="38" height="38"><div><b>VTech</b><small></small></div>';
      brand.querySelector("small").textContent = names[window.PORTAL] || "";
      top.prepend(brand);

      const actions = top.lastElementChild;
      const profile = aside.querySelector(".mt-auto");          // technician: avatar, name, Account button
      if (profile && profile.querySelector("#tech-avatar")) { profile.classList.add("vt-profile"); actions.appendChild(profile); }
      const sync = aside.querySelector(".side-footer");         // admin: operations sync status
      if (sync) { sync.classList.add("vt-sync"); actions.prepend(sync); }
    }
  }

  /* ---------- offline banner ---------- */
  function initOffline() {
    const bar = document.createElement("div");
    bar.className = "vui-offline"; bar.setAttribute("role", "status");
    bar.textContent = "You're offline. Changes can't be saved until your connection returns.";
    document.body.appendChild(bar);
    const upd = () => bar.classList.toggle("show", !navigator.onLine);
    window.addEventListener("online", upd); window.addEventListener("offline", upd); upd();
  }

  /* ---------- navigation state for screen readers ---------- */
  function initNav() {
    const mark = () => document.querySelectorAll("[data-view]").forEach((el) => {
      if (el.matches(".rail-btn,.portal-tab,.nav-item,.nav-link")) {
        if (el.classList.contains("active")) el.setAttribute("aria-current", "page"); else el.removeAttribute("aria-current");
      }
    });
    mark();
    const obs = new MutationObserver(mark);
    document.querySelectorAll("[data-view]").forEach((el) => obs.observe(el, { attributes: true, attributeFilter: ["class"] }));
  }

  /* ---------- keep the toast announcements polite and long enough to read ---------- */
  function initToast() {
    const t = document.getElementById("toast");
    if (t) { t.setAttribute("role", "status"); t.setAttribute("aria-live", "polite"); }
  }

  function init() {
    initShell(); initOffline(); initNav(); initToast();
    document.querySelectorAll(".drawer").forEach((d) => {
      initLayer(d, () => { const c = d.querySelector("[data-close-account],[data-close-booking],[data-close-maintenance],[data-close-signoff],[data-close-payment],[data-close-call]"); if (c) c.click(); });
    });
    const am = document.getElementById("account-modal");
    if (am) initLayer(am, () => { const c = am.querySelector("#account-close"); if (c) c.click(); });
    const np = document.getElementById("notification-panel");
    if (np) np.addEventListener("keydown", (e) => { if (e.key === "Escape") { const b = document.getElementById("close-notifications"); if (b) b.click(); const nb = document.getElementById("notification-button"); if (nb) nb.focus(); } });
    // Admin modal root: close on Escape via its own close button, and lock scroll while open.
    const mr = document.getElementById("modal-root");
    if (mr) {
      let was = false;
      new MutationObserver(() => {
        const open = mr.style.display !== "none"; if (open === was) return; was = open; lockScroll(open);
        if (open) { const t = mr.querySelector("input,select,textarea,button"); if (t) t.focus({ preventScroll: true }); }
      }).observe(mr, { attributes: true, attributeFilter: ["style"] });
      mr.addEventListener("keydown", (e) => { if (e.key === "Escape") { const c = mr.querySelector("#modal-x"); if (c) c.click(); else mr.style.display = "none"; } });
    }
  }

  window.VUI = { ask, lockScroll };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
