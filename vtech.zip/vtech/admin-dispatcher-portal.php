<!doctype html>
<html lang="en"><head><script>window["__codeletBootstrap__"]=JSON.parse('{"A":"A","B":"20261009-04-61a833b","C":{"Abril Fatface":"YACgEZbkUVE,0","Albert Sans":"YAHO2HRfeh4,0","Alfa Slab One":"YACgEYS9sJU,0","Anton":"YACgEcYqQ-A,0","Archivo Black":"YACgEZulLoA,0","Archivo":"YAHO2-t-jNE,0","Arial":"YAGyDvJ_4Ts,0","Baloo 2":"YAHO2IcQUcM,0","Barlow Condensed":"YAFdJljEuFc,0","Barlow":"YAFdJsyuOPM,1","Bebas Neue":"YACgESME5ew,0","Bricolage Grotesque":"YAFyMcdwzpc,0","Canva Sans":"YAFdJjTk5UU,1","Caveat":"YALBs2ploWQ,0","Cinzel":"YACgEeV8bIQ,0","Cormorant Garamond":"YAFdJhX-538,0","Courier New":"YAGzXiGs0_8,0","Courier Prime":"YAD1aFjegN8,0","DM Sans":"YAD1aU3sLnI,0","DM Serif Display":"YAD1aYG82rc,0","Figtree":"YAHO2b-mV7A,0","Forum":"YACgEcnnqB4,0","Fraunces":"YAFdJpU7Kkk,0","Fredoka":"YACgEZml080,0","Georgia":"YAGzXkO0pEM,0","Hanken Grotesk":"YAHO2VB9G0I,0","Helvetica":"YAFcf7zkXN0,0","IBM Plex Mono":"YAFdJkmvhGI,0","IBM Plex Sans":"YAFdJgT0SHI,0","Impact":"YAFcfnjI7Vk,0","Instrument Sans":"YAHO2bKyaSQ,0","Instrument Serif":"YAHFeOnZNEk,0","Inter":"YAFdJvSyp_k,3","Italiana":"YAHO2Toik_w,0","Jacques Francois":"YAHO2a5g66Q,0","JetBrains Mono":"YAFdJksXcAk,0","Josefin Sans":"YAFdJjvw9Ps,0","Karla":"YAHO2V2NSXM,0","Lato":"YAFdJuFCnaw,0","Libre Baskerville":"YACgEUFdPdA,0","Libre Caslon Display":"YAHO2XhLmt0,0","Lobster":"YAD8SnSjSFI,0","Lora":"YACgEXvxf8Q,0","Manrope":"YAHO2b2feC4,0","Merriweather":"YACgEXvHxxs,0","Montserrat":"YAFdtQi73Xs,0","Noto Sans JP":"YAFdJiHXlcI,0","Noto Sans KR":"YAGsojZj-RQ,0","Nunito Sans":"YAFdtQJYB9w,1","Nunito":"YAFdJoNRMmU,1","Oleo Script":"YACgEQQ14jI,0","Oswald":"YACgEQY10lw,0","Outfit":"YAHO2nVlg14,0","Pacifico":"YADLjORQ1u4,0","Playfair Display":"YAFdJhem5V8,1","Plus Jakarta Sans":"YAHO2gdhi18,0","Poppins":"YAFdJjbTu24,1","Press Start 2P":"YAFyGr-8pmQ,0","Public Sans":"YAFdJj8NdaU,1","Quicksand":"YAFdJpYtCxE,1","Raleway":"YAFdJhmxbVQ,1","Roboto Slab":"YAFdJswIKAg,0","Rockwell":"YAFcfyVZnN0,0","Rye":"YACgEdQP21k,0","Sarabun":"YAFdJssSnME,0","Schibsted Grotesk":"YAHO2sWydRk,0","Segoe UI":"YAHNdRD1Klw,0","Source Sans 3":"YAG4lO1Mj10,0","Space Grotesk":"YAHO2sjPCSM,0","Space Mono":"YADW1-vpsoc,0","Spectral":"YAHO2rVUHIM,0","Times New Roman":"YAGzXW3gftg,0","Trebuchet MS":"YAFcfrglpVA,0","Ubuntu":"YACgERDU--Q,0","Verdana":"YAGzXTctYtQ,0","Work Sans":"YAGXhLOKv44,0","Yellowtail":"YACgEYG4kG4,0"}}');</script><script src="/_sdk/3ea5843eacd3e51f.telemetry_sdk.js" integrity="sha512-1IT905GQp6Xezy7dJYJjQl6KtI/PDxD5Vu755gJMNA+luF1QkRT8rHzF+xP7Ekem4HWP8sPFcQQAmx6FCSGaMg=="></script>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>VTech I.T Solution Admin Dashboard</title>
<link rel="icon" type="image/png" href="favicon.png">
<link rel="manifest" href="manifest-admin.webmanifest"><meta name="theme-color" content="#071526"><link rel="apple-touch-icon" href="icons/apple-touch-icon.png"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-title" content="VTech"><script src="pwa.js" defer></script>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&amp;display=swap" rel="stylesheet">
  <style>
    :root{--navy:#071526;--surface:#102942;--surface2:#153552;--line:#284766;--muted:#9ab1c7;--blue:#3294e8;--teal:#23c3ad;--amber:#f7b84b;--red:#f06471;--ink:#eaf4ff}
    *{box-sizing:border-box}
    body{margin:0;font-family:"DM Sans",sans-serif;color:var(--ink);background:var(--navy)}
    button,input{font:inherit}
    button:focus-visible,input:focus-visible,a:focus-visible{outline:3px solid #70c4ff;outline-offset:3px}
    .portal-shell{width:100%;min-height:calc(100 * min(var(--vh,1vh),1vh));background:radial-gradient(circle at 84% 0%,#183e63 0%,#071526 44%,#06111f 100%)}
    .side-nav{background:rgba(6,18,33,.98);border-right:1px solid var(--line)}
    .nav-link{color:#aac0d4;transition:.18s ease}
    .nav-link:hover,.nav-link.active{color:#fff;background:#163b5d}
    .panel{background:rgba(16,41,66,.9);border:1px solid var(--line);box-shadow:0 12px 35px rgba(0,0,0,.16)}
    .summary-card{background:linear-gradient(140deg,rgba(21,53,82,.98),rgba(11,31,54,.94));border:1px solid var(--line)}
    .badge{border-radius:999px;padding:.2rem .52rem;font-size:.71rem;font-weight:700;white-space:nowrap}
    .scheduled{background:#173c5c;color:#9dd7ff}.progress{background:#184f50;color:#8df0dd}.pending{background:#604516;color:#ffd777}.critical{background:#612735;color:#ffabb5}.complete{background:#174b42;color:#85edd8}
    .view{display:none;animation:enter .24s ease both}.view.active{display:block}
    @keyframes enter{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
    .toast{opacity:0;transform:translateY(8px);pointer-events:none;transition:.2s ease}.toast.show{opacity:1;transform:translateY(0)}
    .mobile-nav-toggle,.drawer-overlay{display:none}
    .map-grid{background-color:#0c263c;background-image:linear-gradient(#1c4665 1px,transparent 1px),linear-gradient(90deg,#1c4665 1px,transparent 1px);background-size:28px 28px}
    @media(min-width:1024px){.main-area{margin-left:250px}}
    @media(max-width:1023px){.side-nav{width:76px}.side-nav .nav-word,.side-nav .brand-copy,.side-nav .side-footer{display:none}.main-area{margin-left:76px}}
    @media(max-width:640px){.side-nav{width:min(280px,86vw);transform:translateX(-105%);transition:transform .25s ease}.side-nav.mobile-open{transform:translateX(0)}.side-nav.mobile-open .nav-word,.side-nav.mobile-open .brand-copy,.side-nav.mobile-open .side-footer{display:block}.main-area{margin-left:0}.mobile-nav-toggle{display:grid}.drawer-overlay.show{display:block}}
  </style>
  <link rel="stylesheet" href="vtech-ui.css">
  <script src="https://cdn.tailwindcss.com/3.4.17" type="text/javascript"></script>
  <script src="https://cdn.jsdelivr.net/npm/lucide@0.577.0/dist/umd/lucide.min.js" type="text/javascript"></script>
  <script>window.PORTAL = "admin";</script>
  <script src="sdk-override.js" type="text/javascript"></script>
 </head>
 <body style="background:linear-gradient(135deg,#071526,#102d4a)">
  <style>
   select,textarea{font:inherit}
   .fld{width:100%;border:1px solid #315776;background:#0c263f;color:#fff;border-radius:.6rem;padding:.55rem .7rem;font-size:.875rem}
   .fld::placeholder{color:#7c9bb4}.fld:focus-visible{outline:3px solid #70c4ff;outline-offset:2px}
   select.fld option{background:#0c263f;color:#fff}
   .lbl{display:block;margin-bottom:.3rem;font-size:.75rem;font-weight:600;color:#9ab1c7}
   .btn-b{background:#258fe4;color:#fff;border-radius:.6rem;padding:.55rem 1rem;font-size:.85rem;font-weight:700}.btn-b:hover{background:#1c7fd1}
   .btn-g{border:1px solid #315776;color:#d7ecff;border-radius:.6rem;padding:.45rem .8rem;font-size:.8rem;font-weight:600}.btn-g:hover{background:#163b5d}.btn-g.on{background:#163b5d;border-color:#70c4ff;color:#fff}
   .btn-d{border:1px solid #7b3440;color:#ffabb5;border-radius:.6rem;padding:.45rem .8rem;font-size:.8rem;font-weight:600}.btn-d:hover{background:#3a1a22}
   .gone{display:none!important}
  </style>
  <div class="portal-shell">
   <div id="login-overlay" class="fixed inset-0 z-[70] flex items-center justify-center bg-[#071526] p-4">
    <div class="panel w-full max-w-md rounded-2xl p-6">
     <div class="mb-4 flex items-center gap-3"><img src="logo.png" alt="VTech logo" class="h-12 w-12 object-contain"><div><h1 class="font-bold">VTech I.T Solution</h1><p class="text-xs text-[#9ab1c7]">ADMIN / DISPATCHER PORTAL</p></div></div>
     <p id="login-checking" class="text-sm text-[#9ab1c7]">Checking your session…</p>
    </div>
   </div>
   <div id="drawer-overlay" class="drawer-overlay fixed inset-0 z-20 bg-black/55"></div>
   <aside class="side-nav fixed inset-y-0 left-0 z-30 flex w-[250px] flex-col p-4">
    <header class="mb-8 flex items-center gap-3 px-2">
     <img src="logo.png" alt="VTech logo" class="h-12 w-12 shrink-0 object-contain">
     <div class="brand-copy"><h1 class="font-bold tracking-tight">VTech I.T Solution</h1><p class="text-xs text-[#9ab1c7]">CCTV SERVICE CONTROL</p></div>
    </header>
    <nav aria-label="Primary navigation" class="space-y-1">
     <a href="#dashboard" class="nav-link active flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium" data-view="dashboard"><i data-lucide="layout-dashboard" class="h-4 w-4"></i><span class="nav-word">Dashboard</span></a>
     <a href="#appointments" class="nav-link flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium" data-view="appointments"><i data-lucide="calendar-days" class="h-4 w-4"></i><span class="nav-word">Appointments</span></a>
     <a href="#customers-sites" class="nav-link flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium" data-view="customers-sites"><i data-lucide="building-2" class="h-4 w-4"></i><span class="nav-word">Customers &amp; Sites</span></a>
     <a href="#work-orders" class="nav-link flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium" data-view="work-orders"><i data-lucide="clipboard-list" class="h-4 w-4"></i><span class="nav-word">Work Orders</span></a>
     <a href="#dispatch-board" class="nav-link flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium" data-view="dispatch-board"><i data-lucide="route" class="h-4 w-4"></i><span class="nav-word">Dispatch Board</span></a>
     <a href="#technicians" class="nav-link flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium" data-view="technicians"><i data-lucide="hard-hat" class="h-4 w-4"></i><span class="nav-word">Technicians</span></a>
     <a href="#billing" class="nav-link flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium" data-view="billing"><i data-lucide="receipt-text" class="h-4 w-4"></i><span class="nav-word">Billing</span></a>
     <a href="#reports" class="nav-link flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium" data-view="reports"><i data-lucide="file-bar-chart" class="h-4 w-4"></i><span class="nav-word">Reports</span></a>
     <a href="#communication-center" class="nav-link flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium" data-view="communication-center"><i data-lucide="messages-square" class="h-4 w-4"></i><span class="nav-word">Communication Center</span><span id="nav-unread" class="gone ml-auto rounded-full bg-[#f06471] px-1.5 text-xs font-bold text-white">0</span></a>
     <a href="#settings" class="nav-link flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium" data-view="settings"><i data-lucide="settings" class="h-4 w-4"></i><span class="nav-word">Settings</span></a>
    </nav>
    <div class="side-footer mt-auto rounded-xl border border-[#284766] bg-[#0c243b] p-3">
     <p class="text-xs font-semibold">Operations sync</p>
     <p id="sync-text" class="mt-1 text-xs text-[#9ab1c7]">Connecting…</p>
    </div>
   </aside>
   <div class="main-area min-h-screen">
    <header class="sticky top-0 z-10 flex min-h-[76px] items-center justify-between gap-3 border-b border-[#284766] bg-[#091b30]/95 px-5 py-3 backdrop-blur md:px-7">
     <div><p class="text-xs font-semibold uppercase tracking-[.15em] text-[#9ab1c7]">Operations Control</p><p id="active-section-name" class="text-lg font-bold">Dashboard</p></div>
     <div class="flex items-center gap-3">
      <label class="relative hidden md:block" for="global-search"><span class="sr-only">Search operations records</span><i data-lucide="search" class="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#9ab1c7]"></i><input id="global-search" type="search" class="w-64 rounded-xl border border-[#315776] bg-[#102942] py-2.5 pl-9 pr-3 text-sm text-white placeholder:text-[#90a9c0]" placeholder="Search records"></label>
      <button id="notification-button" type="button" class="relative rounded-xl border border-[#315776] bg-[#102942] p-2.5" aria-label="Notifications"><i data-lucide="bell" class="h-4 w-4"></i><span id="notif-dot" class="gone absolute -right-1 -top-1 min-w-[18px] rounded-full bg-[#f7b84b] px-1 text-center text-[10px] font-bold text-black">0</span></button>
      <button id="signout-btn" type="button" class="btn-g">Sign out</button>
      <div class="flex items-center gap-2 border-l border-[#315776] pl-3">
       <div id="admin-avatar" class="grid h-9 w-9 place-items-center rounded-full bg-[#235170] text-xs font-bold">AD</div>
       <div class="hidden sm:block"><p id="admin-name" class="text-sm font-semibold">Admin</p><p id="admin-role" class="text-xs text-[#9ab1c7]">Operations Admin</p></div>
      </div>
     </div>
    </header>
    <main id="main" tabindex="-1" class="p-5 md:p-7">
     <section id="view-dashboard" class="view active">
      <div id="pw-warning" class="gone mb-5 rounded-xl border border-[#7a5a1c] bg-[#2b2110] p-3 text-sm text-[#ffd777]">You are still using the default admin password. <button type="button" data-act="goto" data-view="settings" class="underline">Change it in Settings</button>.</div>
      <div class="mb-6 flex flex-wrap items-end justify-between gap-3"><div><h2 class="text-2xl font-bold tracking-tight">Field operations</h2><p class="mt-1 text-sm text-[#9ab1c7]">Live view of appointments, dispatch pressure, field coverage and service exceptions.</p></div><button type="button" class="btn-b" data-act="new-job">+ New job</button></div>
      <div class="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
       <article class="summary-card rounded-2xl p-4"><p class="text-sm text-[#9ab1c7]">Scheduled today</p><p id="appointments-count" class="mt-2 text-3xl font-bold">0</p><p id="appointments-sub" class="mt-3 text-xs text-[#9ab1c7]"></p></article>
       <article class="summary-card rounded-2xl p-4"><p class="text-sm text-[#9ab1c7]">Active jobs</p><p id="workorders-count" class="mt-2 text-3xl font-bold">0</p><p id="workorders-sub" class="mt-3 text-xs text-[#9ab1c7]"></p></article>
       <article class="summary-card rounded-2xl p-4"><p class="text-sm text-[#9ab1c7]">Technicians available</p><p id="tech-count" class="mt-2 text-3xl font-bold">0/0</p><p id="tech-sub" class="mt-3 text-xs text-[#9ab1c7]"></p></article>
       <article class="summary-card rounded-2xl p-4"><p class="text-sm text-[#9ab1c7]">Payment follow-up</p><p id="invoice-total" class="mt-2 text-3xl font-bold">₱0</p><p id="invoice-sub" class="mt-3 text-xs text-[#9ab1c7]"></p></article>
      </div>
      <div class="mt-6 grid gap-5 xl:grid-cols-[1.4fr_.8fr]">
       <article class="panel rounded-2xl p-5"><h3 id="schedule-title" class="font-bold">Schedule</h3><div id="dashboard-schedule-list" class="mt-4 space-y-3"></div></article>
       <article class="panel rounded-2xl p-5"><h3 class="font-bold">Needs attention</h3><div id="dashboard-dispatch-list" class="mt-4 space-y-3"></div></article>
      </div>
     </section>

     <section id="view-appointments" class="view">
      <div class="mb-6 flex flex-wrap items-end justify-between gap-3"><div><h2 class="text-2xl font-bold">Appointments</h2><p class="mt-1 text-sm text-[#9ab1c7]">Customer bookings and visits you schedule. Assign a technician to dispatch the visit.</p></div><button type="button" class="btn-b" data-act="new-job" data-type="appointment">+ New appointment</button></div>
      <article class="panel rounded-2xl p-5"><div id="appointments-list" class="grid gap-3 lg:grid-cols-2"></div></article>
     </section>

     <section id="view-customers-sites" class="view">
      <div class="mb-6 flex flex-wrap items-end justify-between gap-3"><div><h2 class="text-2xl font-bold">Customers &amp; Sites</h2><p class="mt-1 text-sm text-[#9ab1c7]">Customers sign up themselves in their portal; you can also create an account for a customer here.</p></div><button type="button" class="btn-b" data-act="new-customer">+ Add customer</button></div>
      <article class="panel rounded-2xl p-5"><div id="customers-list" class="grid gap-3 lg:grid-cols-2"></div></article>
     </section>

     <section id="view-work-orders" class="view">
      <div class="mb-6 flex flex-wrap items-end justify-between gap-3"><div><h2 class="text-2xl font-bold">Work Orders</h2><p class="mt-1 text-sm text-[#9ab1c7]">Installation, maintenance, repair and handover work, including customer maintenance requests.</p></div><button type="button" class="btn-b" data-act="new-job" data-type="work_order">+ New work order</button></div>
      <article class="panel rounded-2xl p-5"><div id="workorders-list" class="space-y-3"></div></article>
     </section>

     <section id="view-dispatch-board" class="view">
      <div class="mb-6"><h2 class="text-2xl font-bold">Dispatch Board</h2><p class="mt-1 text-sm text-[#9ab1c7]">Assign unassigned requests and watch active field jobs.</p></div>
      <div class="grid gap-5 lg:grid-cols-3">
       <article class="panel rounded-2xl p-5"><h3 class="font-bold">Unassigned</h3><div id="dispatch-unassigned" class="mt-4 space-y-3"></div></article>
       <article class="panel rounded-2xl p-5"><h3 class="font-bold">Scheduled</h3><div id="dispatch-scheduled" class="mt-4 space-y-3"></div></article>
       <article class="panel rounded-2xl p-5"><h3 class="font-bold">In progress</h3><div id="dispatch-progress" class="mt-4 space-y-3"></div></article>
      </div>
     </section>

     <section id="view-technicians" class="view">
      <div class="mb-6 flex flex-wrap items-end justify-between gap-3"><div><h2 class="text-2xl font-bold">Technicians</h2><p class="mt-1 text-sm text-[#9ab1c7]">Your field team. You create each technician’s login here.</p></div><button type="button" class="btn-b" data-act="new-tech">+ Add technician</button></div>
      <article class="panel rounded-2xl p-5"><div id="technicians-list" class="grid gap-3 sm:grid-cols-2 xl:grid-cols-3"></div></article>
     </section>


     <section id="view-billing" class="view">
      <div class="mb-6 flex flex-wrap items-end justify-between gap-3"><div><h2 class="text-2xl font-bold">Billing</h2><p class="mt-1 text-sm text-[#9ab1c7]">Invoices you issue appear in the customer’s portal.</p></div><button type="button" class="btn-b" data-act="new-invoice">+ Create invoice</button></div>
      <div id="billing-summary" class="mb-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4"></div>
      <article id="pay-pending-panel" class="panel mb-4 rounded-2xl p-5"><h3 class="mb-3 text-sm font-bold">Payments awaiting confirmation</h3><div id="pay-pending" class="grid gap-3 lg:grid-cols-2"></div></article>
      <article class="panel mb-4 rounded-2xl p-5"><div class="mb-3 flex flex-wrap items-center justify-between gap-3"><div><h3 class="text-sm font-bold">Payment methods</h3><p class="mt-1 text-xs text-[#9ab1c7]">Shown to customers on their Billing page (GCash, bank transfer, cash). Customers send a reference number; you confirm it here.</p></div><button type="button" class="btn-b" data-act="new-method">+ Add payment method</button></div><div id="method-list" class="grid gap-3 lg:grid-cols-3"></div></article>
      <article class="panel rounded-2xl p-5"><div class="mb-3 flex flex-wrap items-center justify-between gap-3"><h3 class="text-sm font-bold">Invoices</h3><div id="billing-filter" class="flex flex-wrap gap-2"></div></div><div id="billing-list" class="grid gap-3 lg:grid-cols-2"></div></article>
     </section>

     <section id="view-reports" class="view">
      <div class="mb-6"><h2 class="text-2xl font-bold">Reports</h2><p class="mt-1 text-sm text-[#9ab1c7]">Technician completion reports, customer sign-offs and operating totals.</p></div>
      <div id="report-stats" class="mb-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-4"></div>
      <div class="grid gap-5 xl:grid-cols-2">
       <article class="panel rounded-2xl p-5"><h3 class="font-bold">Completion reports</h3><div id="reports-list" class="mt-4 space-y-3"></div></article>
       <article class="panel rounded-2xl p-5"><h3 class="font-bold">Customer sign-offs</h3><div id="signoffs-list" class="mt-4 space-y-3"></div></article>
      </div>
     </section>

     <section id="view-communication-center" class="view">
      <div class="mb-6"><h2 class="text-2xl font-bold">Communication Center</h2><p class="mt-1 text-sm text-[#9ab1c7]">Messages with customers and technicians, callback requests, and a log of calls you make.</p></div>
      <div class="grid gap-4 xl:grid-cols-[260px_minmax(320px,1fr)_260px]">
       <article class="panel rounded-2xl p-4"><label class="lbl" for="contact-search">Find a contact</label><input id="contact-search" type="search" class="fld" placeholder="Search contacts">
        <div class="mt-3 flex flex-wrap gap-2"><button type="button" class="filter-chip rounded-lg bg-[#258fe4] px-2 py-1 text-xs" data-filter="all">All</button><button type="button" class="filter-chip rounded-lg border border-[#315776] px-2 py-1 text-xs" data-filter="customer">Customers</button><button type="button" class="filter-chip rounded-lg border border-[#315776] px-2 py-1 text-xs" data-filter="technician">Technicians</button><button type="button" class="filter-chip rounded-lg border border-[#315776] px-2 py-1 text-xs" data-filter="unread">Unread</button></div>
        <div id="contact-list" class="mt-4 space-y-2"></div></article>
       <article class="panel flex min-h-[520px] flex-col rounded-2xl p-4">
        <div id="conversation-header" class="flex items-center justify-between border-b border-[#284766] pb-3"></div>
        <div id="conversation-messages" class="flex-1 space-y-3 overflow-auto py-4"></div>
        <form id="message-form" class="flex gap-2 border-t border-[#284766] pt-3"><label class="sr-only" for="message-input">Message</label><input id="message-input" class="fld" autocomplete="off" placeholder="Write a message"><button type="submit" class="btn-b" aria-label="Send message"><i data-lucide="send" class="h-4 w-4"></i></button></form>
       </article>
       <aside id="contact-details" class="panel rounded-2xl p-4"></aside>
      </div>
     </section>

     <section id="view-settings" class="view">
      <div class="mb-6"><h2 class="text-2xl font-bold">Settings</h2><p class="mt-1 text-sm text-[#9ab1c7]">Your contact details are shown to customers and technicians in their portals.</p></div>
      <div class="grid gap-5 lg:grid-cols-2">
       <article class="panel rounded-2xl p-5"><h3 class="font-bold">Admin profile</h3>
        <form id="profile-form" class="mt-4 space-y-3">
         <div><label class="lbl" for="profile-name">Your name</label><input id="profile-name" class="fld" required placeholder="e.g. Victor Lopez"></div>
         <div><label class="lbl" for="profile-role">Role / title</label><input id="profile-role" class="fld" placeholder="Operations Admin"></div>
         <div class="grid gap-3 sm:grid-cols-2"><div><label class="lbl" for="profile-phone">Phone</label><input id="profile-phone" class="fld" type="tel" placeholder="+63 9XX XXX XXXX"></div><div><label class="lbl" for="profile-email">Email</label><input id="profile-email" class="fld" type="email" placeholder="you@company.ph"></div></div>
         <button type="submit" class="btn-b">Save profile</button>
        </form></article>
       <article class="panel rounded-2xl p-5"><h3 class="font-bold">Account security</h3>
        <p id="account-info" class="mt-1 text-sm text-[#9ab1c7]"></p>
        <form id="pw-form" class="mt-4 space-y-3">
         <div><label class="lbl" for="pw-current">Current password</label><input id="pw-current" class="fld" type="password" required autocomplete="current-password"></div>
         <div class="grid gap-3 sm:grid-cols-2"><div><label class="lbl" for="pw-new">New password</label><input id="pw-new" class="fld" type="password" required minlength="8" autocomplete="new-password"></div><div><label class="lbl" for="pw-new2">Confirm new password</label><input id="pw-new2" class="fld" type="password" required minlength="8" autocomplete="new-password"></div></div>
         <div id="pw-error" class="gone rounded-lg border border-[#a74650] bg-[#4d242b] px-3 py-2 text-sm text-[#ffbdc1]" role="alert"></div>
         <button type="submit" class="btn-b">Update password</button>
        </form></article>
       <article class="panel rounded-2xl p-5"><h3 class="font-bold">How data flows</h3>
        <ul class="mt-3 list-disc space-y-2 pl-5 text-sm text-[#9ab1c7]">
         <li>Customers create their own account in the customer portal; you create technician accounts (Technicians → Add technician).</li>
         <li>You assign technicians; they see only the jobs assigned to them.</li>
         <li>Technicians update status, notes, files and submit completion reports.</li>
         <li>Customers sign off completed work; you issue invoices from Billing.</li>
        </ul></article>
      </div>
     </section>
    </main>
   </div>
   <section id="notification-panel" aria-label="Notifications" class="panel fixed right-5 top-20 z-40 hidden w-[min(340px,calc(100%-2.5rem))] rounded-2xl p-4">
    <div class="mb-3 flex items-center justify-between"><h2 class="font-bold">Notifications</h2><button id="close-notifications" type="button" aria-label="Close notifications" class="rounded-lg p-1 hover:bg-[#173b5d]"><i data-lucide="x" class="h-4 w-4"></i></button></div>
    <div id="notification-list" class="space-y-3"></div>
   </section>
   <button id="mobile-nav-toggle" type="button" aria-label="Open navigation" class="mobile-nav-toggle fixed left-4 top-4 z-40 h-10 w-10 place-items-center rounded-xl border border-[#315776] bg-[#102942] text-white"><i data-lucide="menu" class="h-5 w-5"></i></button>
   <div id="modal-root" class="fixed inset-0 z-50 items-center justify-center bg-black/70 p-4" style="display:none"></div>
   <div id="toast" role="status" aria-live="polite" class="toast fixed bottom-5 right-5 z-[60] rounded-xl border border-[#315776] bg-[#153552] px-4 py-3 text-sm font-semibold shadow-xl"></div>
  </div>
  <script>
    /* ---------- helpers ---------- */
    const $ = s => document.querySelector(s);
    const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
    const money = v => new Intl.NumberFormat("en-PH",{style:"currency",currency:"PHP",minimumFractionDigits:0,maximumFractionDigits:2}).format(Number(v||0));
    const nowIso = () => new Date().toISOString();
    const localToday = () => new Date(Date.now() - new Date().getTimezoneOffset()*60000).toISOString().slice(0,10);
    const fmtDate = d => d ? new Date(d + "T00:00:00").toLocaleDateString("en-PH",{day:"2-digit",month:"short",year:"numeric"}) : "";
    const fmtStamp = t => t ? new Date(t).toLocaleString("en-PH",{month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"}) : "";
    const rid = n => Array.from(crypto.getRandomValues(new Uint8Array(n))).map(b => "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[b % 32]).join("");
    const initials = n => String(n || "?").split(/\s+/).map(w => w[0]).join("").slice(0,2).toUpperCase();

    const JOB_TYPES = ["appointment","maintenance_request","work_order"];
    const CLOSED = ["Completed","Cancelled"];
    const JOB_STATUSES = ["Open","Assigned","In progress","Paused","Completed","Cancelled"];
    const SERVICES = ["Site survey","Installation & configuration","Testing & handover","Maintenance / repair","Other"];
    const viewNames = {dashboard:"Dashboard",appointments:"Appointments","customers-sites":"Customers & Sites","work-orders":"Work Orders","dispatch-board":"Dispatch Board",technicians:"Technicians",billing:"Billing",reports:"Reports","communication-center":"Communication Center",settings:"Settings"};

    let backendRecords = [], initialLoadTimer, loaded = false, currentView = "dashboard";
    let selectedKey = null, contactFilter = "all", activeCall = null, billFilter = "all";
    let authUser = null, usersList = [], usersSig = null;
    const markingRead = new Set();

    /* ---------- derived data ---------- */
    const byType = t => backendRecords.filter(r => r.record_type === t);
    const customers = () => byType("customer");
    const sitesOf = cid => byType("site").filter(s => s.customer_id === cid);
    const technicians = () => byType("technician");
    const jobs = () => backendRecords.filter(r => JOB_TYPES.includes(r.record_type));
    const openJobs = () => jobs().filter(j => !CLOSED.includes(j.status));
    const invoices = () => byType("invoice");
    const payMethods = () => byType("payment_method");
    const payments = () => byType("payment");
    const pendingPayments = () => payments().filter(p => p.status === "Submitted");
    const invoiceOf = p => invoices().find(i => i.__backendId === p.pay_invoice_id);
    const adminRec = () => byType("admin_profile")[0] || null;
    const adminName = () => (adminRec() && adminRec().contact_name) || (authUser && authUser.display_name) || "Admin";
    const techUser = n => usersList.find(u => u.role === "technician" && u.tech_name === n);
    const custUser = id => usersList.find(u => u.role === "customer" && u.customer_id === id);
    const techName = t => t.contact_name || t.title;
    const jobTitle = j => j.job_title || j.title || "Service job";
    const isAssigned = j => !!j.assigned_technician && j.assigned_technician !== "Unassigned";
    const term = () => $("#global-search").value.trim().toLowerCase();
    const filtered = list => { const q = term(); return q ? list.filter(r => Object.values(r).join(" ").toLowerCase().includes(q)) : list; };

    function badgeClass(status) {
      const v = (status || "").toLowerCase();
      if (v.includes("progress") || v.includes("active")) return "progress";
      if (v.includes("submitted") || v.includes("pending") || v.includes("low") || v.includes("due") || v.includes("open") || v.includes("booked") || v.includes("requested") || v.includes("paused") || v.includes("unavail")) return "pending";
      if (v.includes("critical") || v.includes("overdue") || v.includes("cancel") || v.includes("urgent")) return "critical";
      if (v.includes("complete") || v.includes("paid") || v.includes("signed") || v.includes("available") || v.includes("in stock")) return "complete";
      return "scheduled";
    }
    const badge = s => `<span class="badge ${badgeClass(s)}">${esc(s || "Open")}</span>`;
    const empty = t => `<p class="py-4 text-center text-sm text-[#9ab1c7]">${esc(t)}</p>`;

    function toast(message, kind = "success") {
      const el = $("#toast"); el.textContent = message;
      el.style.borderColor = kind === "error" ? "#f06471" : "#23c3ad";
      el.classList.add("show"); clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove("show"), 3400);
    }
    async function save(record, ok) {
      const r = await window.dataSdk.create({...record, created_at: nowIso()});
      if (!r.isOk) { toast(r.error ? "Could not save: " + r.error : "Could not save. Please try again.", "error"); return false; }
      if (ok) toast(ok); window.dataSdk.refresh(); return true;
    }
    async function patch(rec, changes, ok) {
      const r = await window.dataSdk.update({...rec, ...changes, updated_at: nowIso()});
      if (!r.isOk) { toast("Could not update. Please try again.", "error"); return false; }
      if (ok) toast(ok); window.dataSdk.refresh(); return true;
    }
    async function remove(rec, ok) {
      const r = await window.dataSdk.delete(rec.__backendId);
      if (!r.isOk) { toast("Could not delete.", "error"); return false; }
      toast(ok || "Deleted."); window.dataSdk.refresh(); return true;
    }

    /* ---------- technician state ---------- */
    function techState(t) {
      const name = techName(t), mine = openJobs().filter(j => j.assigned_technician === name);
      const running = mine.some(j => j.status === "In progress");
      const state = t.status === "Unavailable" ? "Unavailable" : running ? "On job" : "Available";
      return {state, active: mine.length};
    }

    /* ---------- cards ---------- */
    function techSelect(j) {
      const names = technicians().map(techName);
      if (isAssigned(j) && !names.includes(j.assigned_technician)) names.push(j.assigned_technician);
      return `<select class="fld" data-act="assign" data-id="${esc(j.__backendId)}" aria-label="Assign technician"><option value="">Unassigned</option>${names.map(n => `<option ${n === j.assigned_technician ? "selected" : ""}>${esc(n)}</option>`).join("")}</select>`;
    }
    function statusSelect(j) {
      const list = JOB_STATUSES.includes(j.status) ? JOB_STATUSES : [j.status, ...JOB_STATUSES];
      return `<select class="fld" data-act="job-status" data-id="${esc(j.__backendId)}" aria-label="Job status">${list.map(s => `<option ${s === j.status ? "selected" : ""}>${esc(s)}</option>`).join("")}</select>`;
    }
    function jobCard(j, opts = {}) {
      const meta = [fmtDate(j.scheduled_date) || "Date pending", j.scheduled_time, j.customer_name, j.site_address].filter(Boolean).join(" · ");
      const closed = CLOSED.includes(j.status);
      return `<div class="rounded-xl border border-[#284766] bg-[#0c263f] p-3">
        <div class="flex items-start justify-between gap-3"><div class="min-w-0"><p class="truncate text-sm font-bold">${esc(jobTitle(j))}${j.priority && j.priority !== "Normal" ? ` <span class="badge critical ml-1">${esc(j.priority)}</span>` : ""}</p><p class="mt-1 text-xs text-[#9ab1c7]">${esc(meta)}</p>${j.notes ? `<p class="mt-1 line-clamp-2 text-xs text-[#7f9bb3]">${esc(j.notes)}</p>` : ""}</div>${badge(j.status)}</div>
        ${opts.controls === false ? "" : `<div class="mt-3 grid gap-2 sm:grid-cols-2">${closed ? "" : techSelect(j)}${statusSelect(j)}</div>`}
        <div class="mt-2 flex items-center justify-between text-xs text-[#7f9bb3]"><span>${esc(j.job_id || "")}${j.phone ? " · " + esc(j.phone) : ""}</span><button type="button" class="btn-d" data-act="delete" data-id="${esc(j.__backendId)}" data-label="this job">Delete</button></div></div>`;
    }
    function miniCard(title, detail, status) {
      return `<div class="rounded-xl border border-[#284766] bg-[#0c263f] p-3"><div class="flex items-start justify-between gap-3"><div class="min-w-0"><p class="truncate text-sm font-bold">${esc(title)}</p><p class="mt-1 text-xs text-[#9ab1c7]">${esc(detail)}</p></div>${status ? badge(status) : ""}</div></div>`;
    }

    /* ---------- render ---------- */
    function renderDashboard() {
      const today = localToday(), all = jobs(), open = openJobs();
      const todayJobs = all.filter(j => j.scheduled_date === today && j.status !== "Cancelled");
      const unassigned = open.filter(j => !isAssigned(j));
      const techs = technicians(), avail = techs.filter(t => techState(t).state === "Available");
      const owed = invoices().filter(i => i.status !== "Paid"), overdue = owed.filter(i => i.due_date && i.due_date < today);
      $("#appointments-count").textContent = todayJobs.length;
      $("#appointments-sub").textContent = all.length ? `${all.length} job${all.length === 1 ? "" : "s"} on record` : "No jobs yet";
      $("#workorders-count").textContent = open.length;
      $("#workorders-sub").textContent = `${unassigned.length} unassigned`;
      $("#tech-count").textContent = `${avail.length}/${techs.length}`;
      $("#tech-sub").textContent = techs.length ? `${techs.length - avail.length} busy or unavailable` : "Add your first technician";
      $("#invoice-total").textContent = money(owed.reduce((s,i) => s + Number(i.amount||0), 0));
      $("#invoice-sub").textContent = owed.length ? `${owed.length} unpaid${overdue.length ? " · " + overdue.length + " overdue" : ""}` : "No unpaid invoices";
      const sched = todayJobs.length ? todayJobs : open.filter(j => j.scheduled_date >= today).sort((a,b) => a.scheduled_date.localeCompare(b.scheduled_date));
      $("#schedule-title").textContent = todayJobs.length ? "Today’s schedule" : "Upcoming schedule";
      $("#dashboard-schedule-list").innerHTML = filtered(sched).slice(0,6).map(j => miniCard(jobTitle(j), [j.scheduled_time || "Time TBD", j.customer_name, j.site_address].filter(Boolean).join(" · "), j.status)).join("") || empty("Nothing scheduled. Create a job or wait for customer bookings.");
      const attention = [...open.filter(j => !isAssigned(j)), ...open.filter(j => j.priority === "Urgent" && isAssigned(j))];
      $("#dashboard-dispatch-list").innerHTML = attention.slice(0,6).map(j => miniCard(jobTitle(j), `${j.customer_name || "Customer"} · ${isAssigned(j) ? j.assigned_technician : "awaiting assignment"}`, j.priority === "Urgent" ? "Urgent" : "Unassigned")).join("") || empty("No jobs need attention.");
    }
    function renderLists() {
      const all = filtered(jobs());
      $("#appointments-list").innerHTML = all.filter(j => j.record_type === "appointment").map(j => jobCard(j)).join("") || empty("No appointments yet.");
      $("#workorders-list").innerHTML = all.filter(j => j.record_type !== "appointment").map(j => jobCard(j)).join("") || empty("No work orders yet. Create one, or wait for customer maintenance requests.");
      const open = all.filter(j => !CLOSED.includes(j.status));
      $("#dispatch-unassigned").innerHTML = open.filter(j => !isAssigned(j)).map(j => jobCard(j)).join("") || empty("No unassigned work.");
      $("#dispatch-scheduled").innerHTML = open.filter(j => isAssigned(j) && j.status !== "In progress").map(j => jobCard(j)).join("") || empty("No scheduled work.");
      $("#dispatch-progress").innerHTML = open.filter(j => j.status === "In progress").map(j => jobCard(j)).join("") || empty("No jobs in progress.");
    }
    function renderCustomers() {
      const list = filtered(customers());
      $("#customers-list").innerHTML = list.map(c => {
        const ss = sitesOf(c.customer_id), js = jobs().filter(j => j.customer_id === c.customer_id);
        return `<div class="rounded-xl border border-[#284766] bg-[#0c263f] p-3"><div class="flex items-start justify-between gap-3"><div class="min-w-0"><p class="truncate text-sm font-bold">${esc(c.customer_name)}</p><p class="mt-1 text-xs text-[#9ab1c7]">${esc([c.contact_name, c.phone, c.email].filter(Boolean).join(" · "))}</p><p class="mt-1 text-xs text-[#7f9bb3]">Username: ${esc((custUser(c.customer_id) || {}).username || "— (no login)")}</p></div><span class="badge scheduled">${esc(c.customer_id)}</span></div>
          <div class="mt-2 space-y-1 text-xs text-[#9ab1c7]">${ss.map(s => `<p>📍 ${esc(s.title)} — ${esc(s.site_address)}</p>`).join("") || "<p>No sites yet</p>"}</div>
          <div class="mt-3 flex flex-wrap items-center gap-2"><span class="text-xs text-[#7f9bb3]">${js.length} job${js.length === 1 ? "" : "s"}</span><span class="flex-1"></span>
           <button type="button" class="btn-g" data-act="new-job" data-customer="${esc(c.customer_id)}">New job</button>
           ${custUser(c.customer_id) ? `<button type="button" class="btn-g" data-act="reset-pw" data-uid="${custUser(c.customer_id).id}" data-label="${esc(c.customer_name)}">Reset password</button>` : ""}
           <button type="button" class="btn-g" data-act="open-chat" data-key="customer:${esc(c.customer_id)}">Message</button>
           <button type="button" class="btn-d" data-act="delete" data-id="${esc(c.__backendId)}" data-label="this customer record (their jobs and sites are kept)">Delete</button></div></div>`;
      }).join("") || empty("No customers yet. They appear when someone registers in the customer portal, or add one yourself.");
    }
    function renderTechnicians() {
      $("#technicians-list").innerHTML = filtered(technicians()).map(t => {
        const s = techState(t), n = techName(t);
        return `<div class="rounded-xl border border-[#284766] bg-[#0c263f] p-4"><div class="flex items-center gap-3"><div class="grid h-10 w-10 place-items-center rounded-full border border-[#23c3ad55] bg-[#23c3ad22] text-xs font-bold text-[#23c3ad]">${esc(initials(n))}</div><div class="min-w-0 flex-1"><p class="truncate text-sm font-bold">${esc(n)}</p><p class="mt-1 text-xs text-[#9ab1c7]">${esc(s.state)} · ${s.active} active job${s.active === 1 ? "" : "s"}</p></div>${badge(s.state)}</div>
          <p class="mt-2 text-xs text-[#9ab1c7]">${esc([t.phone, t.email].filter(Boolean).join(" · ") || "No contact details")}</p><p class="mt-1 text-xs text-[#7f9bb3]">Username: ${esc((techUser(n) || {}).username || "— (no login)")}</p>
          <div class="mt-3 flex flex-wrap gap-2"><button type="button" class="btn-g" data-act="open-chat" data-key="tech:${esc(n)}">Message</button>${techUser(n) ? `<button type="button" class="btn-g" data-act="reset-pw" data-uid="${techUser(n).id}" data-label="${esc(n)}">Reset password</button>` : ""}<span class="flex-1"></span><button type="button" class="btn-d" data-act="delete" data-id="${esc(t.__backendId)}" data-label="${esc(n)} from the team">Remove</button></div></div>`;
      }).join("") || empty("No technicians yet. Add one, or have them register in the technician portal.");
    }
    const receiptOf = p => { const e = String(p.documents_uploaded || ""), k = e.indexOf("::"); return k > 0 ? {name: e.slice(0, k), url: "download.php?f=" + encodeURIComponent(e.slice(k + 2)), pdf: /\.pdf$/i.test(e)} : null; };
    // Inline receipt: image thumbnail that opens full-size in a viewer (PDFs open in a new tab). Nothing is downloaded.
    const receiptThumb = p => {
      const r = receiptOf(p);
      if (!r) return `<p class="mt-2 text-xs text-[#7f9bb3]">No receipt attached</p>`;
      return r.pdf ? `<a class="mt-2 inline-block text-xs font-semibold text-[#70c4ff] underline" href="${r.url}" target="_blank" rel="noopener">View PDF receipt · ${esc(r.name)}</a>`
        : `<button type="button" class="mt-2 block w-full" data-act="view-receipt" data-src="${r.url}" data-name="${esc(r.name)}" aria-label="View receipt full size"><img src="${r.url}" alt="Payment receipt" loading="lazy" class="max-h-44 w-full rounded-lg border border-[#284766] object-cover object-top"></button>`;
    };
    const receiptLink = p => {
      const r = receiptOf(p); if (!r) return "";
      return r.pdf ? ` · <a class="underline" href="${r.url}" target="_blank" rel="noopener">View receipt</a>` : ` · <button type="button" class="underline" data-act="view-receipt" data-src="${r.url}" data-name="${esc(r.name)}">View receipt</button>`;
    };
    function showReceipt(src, name) {
      const o = document.createElement("div");
      o.style.cssText = "position:fixed;inset:0;z-index:90;background:rgba(3,12,22,.9);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;padding:16px;cursor:zoom-out";
      o.innerHTML = `<img src="${esc(src)}" alt="Payment receipt" style="max-width:100%;max-height:calc(100vh - 84px);object-fit:contain;border-radius:10px;background:#fff"><div style="color:#cfe0f0;font-size:13px">${esc(name)} · click anywhere or press Esc to close</div>`;
      const key = e => { if (e.key === "Escape") close(); };
      const close = () => { o.remove(); document.removeEventListener("keydown", key); };
      o.addEventListener("click", close); document.addEventListener("keydown", key); document.body.appendChild(o);
    }
    function renderBilling() {
      const today = localToday();
      const pend = pendingPayments();
      $("#pay-pending-panel").classList.toggle("gone", !pend.length);
      $("#pay-pending").innerHTML = pend.map(p => {
        const inv = invoiceOf(p);
        return `<div class="rounded-xl border border-[#d8a23a] bg-[#0c263f] p-3"><p class="truncate text-sm font-bold">${esc(p.customer_name)} · ${money(p.amount)}</p><p class="mt-1 text-xs text-[#9ab1c7]">${esc(inv ? inv.title : p.title)}</p><p class="mt-1 text-xs text-[#cfe0f0]">${esc(p.pay_method)} · Ref <strong>${esc(p.pay_reference)}</strong></p>${p.notes ? `<p class="mt-1 text-xs text-[#7f9bb3]">${esc(p.notes)}</p>` : ""}
          ${receiptThumb(p)}<div class="mt-3 flex gap-2"><button type="button" class="btn-b" data-act="pay-confirm" data-id="${esc(p.__backendId)}">Confirm &amp; mark paid</button><button type="button" class="btn-g" data-act="pay-reject" data-id="${esc(p.__backendId)}">Reject</button></div></div>`;
      }).join("");
      $("#method-list").innerHTML = payMethods().map(m => `<div class="rounded-xl border border-[#284766] bg-[#0c263f] p-3"><div class="flex items-start justify-between gap-3"><div class="min-w-0"><p class="truncate text-sm font-bold">${esc(m.title)}</p><p class="mt-1 text-xs text-[#9ab1c7]">${m.contact_name ? esc(m.contact_name) : ""}${m.pay_account_no ? (m.contact_name ? " · " : "") + esc(m.pay_account_no) : ""}</p>${m.notes ? `<p class="mt-1 whitespace-pre-wrap text-xs text-[#7f9bb3]">${esc(m.notes)}</p>` : ""}</div>${badge(m.status === "Active" ? "Active" : "Hidden")}</div>
          <div class="mt-3 flex gap-2"><button type="button" class="btn-g" data-act="method-toggle" data-id="${esc(m.__backendId)}">${m.status === "Active" ? "Hide from customers" : "Show to customers"}</button><span class="flex-1"></span><button type="button" class="btn-d" data-act="delete" data-id="${esc(m.__backendId)}" data-label="this payment method">Delete</button></div></div>`).join("") || empty("No payment methods yet. Add GCash, bank transfer or cash so customers know how to pay.");
      $("#billing-list").innerHTML = (() => {
        const all = invoices(), isPaid = i => i.status === "Paid", isOver = i => !isPaid(i) && !!i.due_date && i.due_date < today;
        const sum = l => l.reduce((s, i) => s + Number(i.amount || 0), 0), stamp = i => new Date(i.updated_at || i.created_at).getTime() || 0;
        const unpaidL = all.filter(i => !isPaid(i)), overL = all.filter(isOver), paidL = all.filter(isPaid);
        const sc = (l, v, s) => `<article class="summary-card rounded-2xl p-4"><p class="text-sm text-[#9ab1c7]">${l}</p><p class="mt-2 text-2xl font-bold">${v}</p><p class="mt-2 text-xs text-[#9ab1c7]">${s}</p></article>`;
        $("#billing-summary").innerHTML = sc("Outstanding", money(sum(unpaidL)), `${unpaidL.length} unpaid invoice${unpaidL.length === 1 ? "" : "s"}`)
          + sc("Overdue", money(sum(overL)), overL.length ? `${overL.length} past due` : "Nothing overdue")
          + sc("Awaiting confirmation", pend.length, pend.length ? money(sum(pend)) + " to verify" : "No payments to verify")
          + sc("Collected", money(sum(paidL)), `${paidL.length} paid invoice${paidL.length === 1 ? "" : "s"}`);
        const tabs = [["all", "All", all.length], ["unpaid", "Unpaid", unpaidL.length], ["overdue", "Overdue", overL.length], ["paid", "Paid", paidL.length]];
        $("#billing-filter").innerHTML = tabs.map(t => `<button type="button" class="btn-g${billFilter === t[0] ? " on" : ""}" data-act="bill-filter" data-f="${t[0]}">${t[1]} (${t[2]})</button>`).join("");
        const base = billFilter === "unpaid" ? unpaidL : billFilter === "overdue" ? overL : billFilter === "paid" ? paidL : all;
        const list = filtered(base).slice().sort((x, y) => {
          if (isPaid(x) !== isPaid(y)) return isPaid(x) ? 1 : -1;
          if (isPaid(x)) return stamp(y) - stamp(x);
          return (x.due_date || "9999").localeCompare(y.due_date || "9999");
        });
        return list.map(i => {
          const overdue = isOver(i), sub = !isPaid(i) && pend.some(p => p.pay_invoice_id === i.__backendId);
          const hist = payments().filter(p => p.pay_invoice_id === i.__backendId && p.status !== "Submitted").sort((x, y) => stamp(y) - stamp(x))
            .map(p => `<p class="mt-1 text-xs ${p.status === "Confirmed" ? "text-[#5fd6c3]" : "text-[#f09aa4]"}">${esc(p.status)} · ${esc(p.pay_method)} · Ref ${esc(p.pay_reference)} · ${esc(fmtStamp(p.updated_at || p.created_at))}${receiptLink(p)}</p>`).join("");
          return `<div class="rounded-xl border border-[#284766] bg-[#0c263f] p-3"><div class="flex items-start justify-between gap-3"><div class="min-w-0"><p class="truncate text-sm font-bold">${esc(i.title)}</p><p class="mt-1 text-xs text-[#9ab1c7]">${esc(i.customer_name)} · ${money(i.amount)}${i.due_date ? " · due " + esc(fmtDate(i.due_date)) : ""}</p>${i.notes ? `<p class="mt-1 text-xs text-[#7f9bb3]">${esc(i.notes)}</p>` : ""}${hist}</div>${badge(sub ? "Payment submitted" : overdue ? "Overdue" : i.status)}</div>
          <div class="mt-3 flex flex-wrap gap-2">${isPaid(i) ? `<button type="button" class="btn-g" data-act="inv-status" data-id="${esc(i.__backendId)}" data-s="Pending">Mark unpaid</button>` : `<button type="button" class="btn-b" data-act="inv-status" data-id="${esc(i.__backendId)}" data-s="Paid">Mark paid</button>${sub ? "" : `<button type="button" class="btn-g" data-act="inv-edit" data-id="${esc(i.__backendId)}">Edit</button>`}`}<button type="button" class="btn-g" data-act="inv-print" data-id="${esc(i.__backendId)}">${isPaid(i) ? "Receipt" : "Print"}</button><span class="flex-1"></span><button type="button" class="btn-d" data-act="delete" data-id="${esc(i.__backendId)}" data-label="this invoice">Delete</button></div></div>`;
        }).join("") || empty(all.length ? "No invoices match this filter." : "No invoices yet.");
      })();
    }
    function renderReports() {
      const all = jobs(), done = all.filter(j => j.status === "Completed"), paid = invoices().filter(i => i.status === "Paid").reduce((s,i) => s + Number(i.amount||0), 0), owed = invoices().filter(i => i.status !== "Paid").reduce((s,i) => s + Number(i.amount||0), 0);
      const stat = (l, v, s) => `<article class="summary-card rounded-2xl p-4"><p class="text-sm text-[#9ab1c7]">${l}</p><p class="mt-2 text-2xl font-bold">${v}</p><p class="mt-2 text-xs text-[#9ab1c7]">${s}</p></article>`;
      $("#report-stats").innerHTML = stat("Total jobs", all.length, `${openJobs().length} open`) + stat("Completed", done.length, `${all.filter(j => j.report_submitted).length} with reports`) + stat("Collected", money(paid), "Paid invoices") + stat("Outstanding", money(owed), "Unpaid invoices");
      $("#reports-list").innerHTML = filtered(all.filter(j => j.report_submitted)).map(j => `<div class="rounded-xl border border-[#284766] bg-[#0c263f] p-3"><div class="flex items-start justify-between gap-3"><div class="min-w-0"><p class="text-sm font-bold">${esc(jobTitle(j))}</p><p class="mt-1 text-xs text-[#9ab1c7]">${esc(j.customer_name)} · ${esc(j.assigned_technician)} · ${esc(fmtStamp(j.updated_at))}</p></div>${badge(String(j.signature_status || "").startsWith("Customer signed off") ? "Signed off" : "Awaiting sign-off")}</div>
        <details class="mt-2 text-xs text-[#9ab1c7]"><summary class="cursor-pointer">Details</summary><p class="mt-1"><b>Equipment:</b> ${esc(j.equipment_used || "—")}</p><p class="mt-1" style="white-space:pre-wrap"><b>Notes:</b> ${esc(j.notes || "—")}</p></details></div>`).join("") || empty("No completion reports submitted yet.");
      $("#signoffs-list").innerHTML = filtered(byType("sign_off")).map(s => miniCard(s.title, `${s.customer_name} · ${fmtStamp(s.created_at)}${s.notes ? " · " + s.notes : ""}`, "Signed Off")).join("") || empty("No customer sign-offs yet.");
    }

    /* ---------- communication ---------- */
    function contacts() {
      const list = [];
      customers().forEach(c => list.push({key:"customer:" + c.customer_id, kind:"customer", name:c.customer_name, sub:c.contact_name, phone:c.phone, email:c.email, rec:c}));
      technicians().forEach(t => list.push({key:"tech:" + techName(t), kind:"technician", name:techName(t), sub:"Technician", phone:t.phone, email:t.email, rec:t}));
      list.forEach(c => {
        c.msgs = byType("message").filter(m => m.thread_id === c.key).sort((a,b) => new Date(a.msg_timestamp||a.created_at) - new Date(b.msg_timestamp||b.created_at));
        c.unread = c.msgs.filter(m => m.role !== "admin" && m.status === "Unread").length;
        c.last = c.msgs.length ? new Date(c.msgs[c.msgs.length-1].msg_timestamp || c.msgs[c.msgs.length-1].created_at).getTime() : 0;
      });
      return list.sort((a,b) => b.unread - a.unread || b.last - a.last || a.name.localeCompare(b.name));
    }
    function renderCommunication() {
      const all = contacts(), q = ($("#contact-search").value || "").toLowerCase();
      if (!selectedKey || !all.some(c => c.key === selectedKey)) selectedKey = all[0] ? all[0].key : null;
      const sel = all.find(c => c.key === selectedKey);
      const list = all.filter(c => (contactFilter === "all" || (contactFilter === "unread" ? c.unread > 0 : c.kind === contactFilter)) && c.name.toLowerCase().includes(q));
      $("#contact-list").innerHTML = list.map(c => `<button type="button" class="w-full rounded-lg border ${c.key === selectedKey ? "border-[#3294e8] bg-[#123958]" : "border-[#284766] bg-[#0c263f]"} p-3 text-left" data-act="select-contact" data-key="${esc(c.key)}"><div class="flex items-center gap-2"><span class="grid h-8 w-8 place-items-center rounded-full bg-[#235170] text-xs font-bold">${esc(initials(c.name))}</span><span class="min-w-0 flex-1"><b class="block truncate text-sm">${esc(c.name)}</b><small class="text-[#9ab1c7]">${c.kind === "customer" ? "Customer" : "Technician"}</small></span>${c.unread ? `<em class="badge bg-[#f06471] text-white not-italic">${c.unread}</em>` : ""}</div></button>`).join("") || empty(all.length ? "No contacts match." : "No customers or technicians yet.");
      const totalUnread = all.reduce((s,c) => s + c.unread, 0);
      $("#nav-unread").textContent = totalUnread; $("#nav-unread").classList.toggle("gone", !totalUnread);
      const hdr = $("#conversation-header"), box = $("#conversation-messages"), det = $("#contact-details");
      if (!sel) { hdr.innerHTML = "<b>No conversation selected</b>"; box.innerHTML = empty("Add a customer or technician to start messaging."); det.innerHTML = "<p class='text-sm text-[#9ab1c7]'>Contact details appear here.</p>"; $("#message-input").disabled = true; return; }
      $("#message-input").disabled = false;
      hdr.innerHTML = `<div><b>${esc(sel.name)}</b><p class="text-xs text-[#9ab1c7]">${sel.kind === "customer" ? "Customer · " + esc(sel.sub || "") : "Technician"}</p></div><div class="flex gap-2"><button type="button" class="rounded-lg border border-[#315776] p-2" data-act="call" data-kind="Voice" aria-label="Log voice call"><i data-lucide="phone" class="h-4 w-4"></i></button><button type="button" class="rounded-lg border border-[#315776] p-2" data-act="call" data-kind="Video" aria-label="Log video call"><i data-lucide="video" class="h-4 w-4"></i></button></div>`;
      const atBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 40;
      box.innerHTML = sel.msgs.length ? sel.msgs.map(m => `<div class="flex ${m.role === "admin" ? "justify-end" : "justify-start"}"><div class="max-w-[80%] rounded-xl ${m.role === "admin" ? "bg-[#258fe4]" : "bg-[#153552]"} px-3 py-2 text-sm"><p style="white-space:pre-wrap">${esc(m.msg_text || m.notes)}</p><small class="opacity-70">${esc(fmtStamp(m.msg_timestamp || m.created_at))}</small></div></div>`).join("") : empty("No messages yet. Start the conversation.");
      if (atBottom || box.dataset.key !== sel.key) box.scrollTop = box.scrollHeight;
      box.dataset.key = sel.key;
      const cbs = byType("callback_request").filter(r => r.thread_id === sel.key && r.status !== "Done");
      const calls = byType("call").filter(r => r.thread_id === sel.key).slice(0,4);
      det.innerHTML = `<h3 class="font-bold">Contact details</h3><div class="mt-4 space-y-3 text-sm"><p><span class="text-[#9ab1c7]">Name</span><br>${esc(sel.name)}</p><p><span class="text-[#9ab1c7]">Phone</span><br>${sel.phone ? `<a class="underline" href="tel:${esc(String(sel.phone).replace(/[^+\d]/g, ""))}">${esc(sel.phone)}</a>` : "Not provided"}</p><p><span class="text-[#9ab1c7]">Email</span><br>${sel.email ? `<a class="underline" href="mailto:${esc(sel.email)}">${esc(sel.email)}</a>` : "Not provided"}</p></div>
        ${cbs.length ? `<h4 class="mt-5 text-sm font-bold">Callback requests</h4>${cbs.map(c => `<div class="mt-2 rounded-lg border border-[#7a5a1c] bg-[#2b2110] p-2 text-xs"><p><b>${esc(c.scheduled_time)}</b></p><p class="mt-1">${esc(c.notes)}</p><button type="button" class="btn-g mt-2" data-act="cb-done" data-id="${esc(c.__backendId)}">Mark done</button></div>`).join("")}` : ""}
        ${calls.length ? `<h4 class="mt-5 text-sm font-bold">Call log</h4>${calls.map(c => `<p class="mt-1 text-xs text-[#9ab1c7]">${esc(c.msg_type)} · ${esc(fmtStamp(c.created_at))} · ${esc(c.call_duration || c.status)}</p>`).join("")}` : ""}`;
      lucide.createIcons();
      markRead(sel);
    }
    function markRead(sel) {
      if (currentView !== "communication-center") return;
      sel.msgs.filter(m => m.role !== "admin" && m.status === "Unread" && !markingRead.has(m.__backendId)).forEach(m => {
        markingRead.add(m.__backendId);
        window.dataSdk.update({...m, status:"Read", updated_at:nowIso()}).then(r => { if (!r.isOk) markingRead.delete(m.__backendId); });
      });
    }
    function startCall(kind) {
      const sel = contacts().find(c => c.key === selectedKey); if (!sel) return;
      if (activeCall) return toast("A call is already being logged.", "error");
      activeCall = {key: sel.key, started: Date.now(), kind, id: null};
      window.dataSdk.create({record_type:"call", title:kind + " call · " + sel.name, thread_id:sel.key, msg_type:kind.toLowerCase(), msg_sender:adminName(), status:"Active", role:"admin", created_at:nowIso()}).then(r => { if (r.isOk) activeCall.id = r.id; });
      const panel = document.createElement("div");
      panel.className = "fixed inset-0 z-50 grid place-items-center bg-black/70 p-5";
      panel.innerHTML = `<div class="panel w-full max-w-sm rounded-2xl p-6 text-center"><div class="mx-auto grid h-16 w-16 place-items-center rounded-full bg-[#235170] text-xl font-bold">${esc(initials(sel.name))}</div><h2 class="mt-3 font-bold">${esc(kind)} call log</h2><p class="text-sm text-[#9ab1c7]">${esc(sel.name)}</p><p class="mt-3 text-xs text-[#9ab1c7]">This records the call in your log. Audio/video isn’t carried by this portal${sel.phone ? " — use the button below to dial" : ""}.</p>${sel.phone ? `<a class="btn-b mt-4 inline-block" href="tel:${esc(String(sel.phone).replace(/[^+\d]/g, ""))}">Dial ${esc(sel.phone)}</a>` : ""}<div><button type="button" class="mt-4 rounded-lg bg-[#f06471] px-4 py-3 font-semibold" id="end-call">End &amp; save log</button></div></div>`;
      document.body.appendChild(panel);
      panel.querySelector("#end-call").addEventListener("click", async () => {
        const secs = Math.round((Date.now() - activeCall.started) / 1000), dur = Math.floor(secs/60) + "m " + String(secs % 60).padStart(2,"0") + "s";
        await new Promise(r => setTimeout(r, 300));
        const rec = backendRecords.find(r => r.__backendId === activeCall.id) || (await (async () => { await window.dataSdk.refresh(); return backendRecords.find(r => r.__backendId === activeCall.id); })());
        if (rec) await window.dataSdk.update({...rec, status:"Ended", call_duration:dur, updated_at:nowIso()});
        activeCall = null; panel.remove(); toast(kind + " call logged (" + dur + ")"); window.dataSdk.refresh();
      });
    }

    /* ---------- notifications ---------- */
    function notifications() {
      const out = [], today = localToday();
      const un = openJobs().filter(j => !isAssigned(j)); if (un.length) out.push({t:`${un.length} job${un.length === 1 ? "" : "s"} awaiting a technician`, d:un.slice(0,2).map(jobTitle).join(", "), v:"dispatch-board"});
      const cm = contacts().reduce((s,c) => s + c.unread, 0); if (cm) out.push({t:`${cm} unread message${cm === 1 ? "" : "s"}`, d:"Open the Communication Center.", v:"communication-center"});
      const cb = byType("callback_request").filter(r => r.status !== "Done"); if (cb.length) out.push({t:`${cb.length} callback request${cb.length === 1 ? "" : "s"}`, d:cb[0].customer_name + ": " + cb[0].notes, v:"communication-center", k:"customer:" + cb[0].customer_id});
      const pp = pendingPayments(); if (pp.length) out.push({t:`${pp.length} payment${pp.length === 1 ? "" : "s"} to confirm`, d:pp[0].customer_name + " · " + money(pp[0].amount) + " · Ref " + pp[0].pay_reference, v:"billing"});
      const od = invoices().filter(i => i.status !== "Paid" && i.due_date && i.due_date < today); if (od.length) out.push({t:`${od.length} overdue invoice${od.length === 1 ? "" : "s"}`, d:od[0].customer_name + " · " + money(od[0].amount), v:"billing"});
      const sign = jobs().filter(j => j.report_submitted && !String(j.signature_status||"").startsWith("Customer signed off")); if (sign.length) out.push({t:`${sign.length} report${sign.length === 1 ? "" : "s"} awaiting customer sign-off`, d:sign.slice(0,2).map(jobTitle).join(", "), v:"reports"});
      return out;
    }
    function renderNotifications() {
      const n = notifications();
      $("#notif-dot").textContent = n.length; $("#notif-dot").classList.toggle("gone", !n.length);
      $("#notification-list").innerHTML = n.map(x => `<button type="button" class="block w-full rounded-xl border border-[#284766] bg-[#0c263f] p-3 text-left" data-act="goto" data-view="${x.v}" ${x.k ? `data-key="${esc(x.k)}"` : ""}><p class="text-sm font-bold">${esc(x.t)}</p><p class="mt-1 text-xs text-[#9ab1c7]">${esc(x.d)}</p></button>`).join("") || empty("No new notifications.");
    }

    function renderProfile() {
      const ap = adminRec();
      $("#admin-name").textContent = adminName(); $("#admin-role").textContent = (ap && ap.notes) || "Operations Admin"; $("#admin-avatar").textContent = initials(adminName());
    }
    function fillProfileForm() {
      const ap = adminRec(); if (!ap || fillProfileForm.done) return; fillProfileForm.done = true;
      $("#profile-name").value = ap.contact_name || ""; $("#profile-role").value = ap.notes || ""; $("#profile-phone").value = ap.phone || ""; $("#profile-email").value = ap.email || "";
    }

    function renderAll() {
      renderProfile(); renderDashboard(); renderLists(); renderCustomers(); renderTechnicians(); renderBilling(); renderReports(); renderCommunication(); renderNotifications(); fillProfileForm();
      lucide.createIcons();
    }

    function navigate(view, updateHash = true) {
      if (!viewNames[view]) view = "dashboard";
      currentView = view;
      document.querySelectorAll(".view").forEach(e => e.classList.toggle("active", e.id === `view-${view}`));
      document.querySelectorAll(".nav-link").forEach(e => e.classList.toggle("active", e.dataset.view === view));
      $("#active-section-name").textContent = viewNames[view];
      $(".side-nav").classList.remove("mobile-open"); $("#drawer-overlay").classList.remove("show");
      if (updateHash && location.hash !== `#${view}`) history.replaceState(null, "", `#${view}`);
      if (view === "communication-center") renderCommunication();
    }

    /* ---------- modal forms ---------- */
    function openModal(title, fields, submitLabel, onSubmit, intro) {
      const root = $("#modal-root");
      root.innerHTML = `<div class="panel max-h-[92vh] w-full max-w-lg overflow-auto rounded-2xl p-6"><div class="flex items-start justify-between gap-3"><h2 class="text-lg font-bold">${esc(title)}</h2><button type="button" id="modal-x" class="rounded-lg p-1 hover:bg-[#173b5d]" aria-label="Close"><i data-lucide="x" class="h-4 w-4"></i></button></div>${intro ? `<p class="mt-2 text-sm text-[#9ab1c7]">${intro}</p>` : ""}<form id="modal-form" class="mt-4 space-y-3">${fields}<div id="modal-error" class="gone rounded-lg border border-[#a74650] bg-[#4d242b] px-3 py-2 text-sm text-[#ffbdc1]"></div><div class="flex justify-end gap-2 pt-2"><button type="button" id="modal-cancel" class="btn-g">Cancel</button><button type="submit" class="btn-b">${esc(submitLabel)}</button></div></form></div>`;
      root.style.display = "flex"; lucide.createIcons();
      const close = () => { root.style.display = "none"; root.innerHTML = ""; };
      $("#modal-x").addEventListener("click", close); $("#modal-cancel").addEventListener("click", close);
      $("#modal-form").addEventListener("submit", async e => {
        e.preventDefault(); const btn = e.submitter; btn.disabled = true;
        const err = $("#modal-error"); err.classList.add("gone");
        try { const ok = await onSubmit(e.target, msg => { err.textContent = msg; err.classList.remove("gone"); }); if (ok) close(); } finally { btn.disabled = false; }
      });
      const first = root.querySelector("input,select,textarea"); if (first) first.focus();
    }
    const field = (id, label, extra = "") => `<div><label class="lbl" for="${id}">${label}</label>${extra}</div>`;

    function customerForm() {
      openModal("Create customer account",
        `<div class="grid gap-3 sm:grid-cols-2">${field("f-user","Username",`<input id="f-user" class="fld" required minlength="3" maxlength="40" autocomplete="off" placeholder="letters, numbers, . - _">`)}${field("f-pass","Temporary password",`<input id="f-pass" class="fld" type="text" required minlength="8" autocomplete="off" placeholder="At least 8 characters">`)}</div>` +
        field("f-company","Company / household name",`<input id="f-company" class="fld" required>`) +
        field("f-contact","Contact person",`<input id="f-contact" class="fld" required>`) +
        `<div class="grid gap-3 sm:grid-cols-2">${field("f-phone","Phone",`<input id="f-phone" class="fld" type="tel" required>`)}${field("f-email","Email (optional)",`<input id="f-email" class="fld" type="email">`)}</div>` +
        field("f-site","First site name",`<input id="f-site" class="fld" required placeholder="e.g. Head office">`) +
        field("f-addr","Site address",`<input id="f-addr" class="fld" required>`),
        "Create account", async (f, fail) => {
          const r = await window.auth.createCustomer({username:$("#f-user").value.trim(), password:$("#f-pass").value, company:$("#f-company").value.trim(), contact_name:$("#f-contact").value.trim(), phone:$("#f-phone").value.trim(), email:$("#f-email").value.trim(), site_name:$("#f-site").value.trim(), site_address:$("#f-addr").value.trim()});
          if (!r.isOk) { fail(r.error || "Could not create the customer."); return false; }
          toast("Customer account created. Customer ID: " + r.customer_id); window.dataSdk.refresh(); refreshUsers(true); return true;
        }, "Give the customer this username and temporary password. They can change the password after signing in.");
    }
    function techForm() {
      openModal("Create technician account",
        `<div class="grid gap-3 sm:grid-cols-2">${field("f-user","Username",`<input id="f-user" class="fld" required minlength="3" maxlength="40" autocomplete="off" placeholder="letters, numbers, . - _">`)}${field("f-pass","Temporary password",`<input id="f-pass" class="fld" type="text" required minlength="8" autocomplete="off" placeholder="At least 8 characters">`)}</div>` +
        field("f-name","Full name",`<input id="f-name" class="fld" required>`) +
        `<div class="grid gap-3 sm:grid-cols-2">${field("f-phone","Mobile number",`<input id="f-phone" class="fld" type="tel" required>`)}${field("f-email","Email (optional)",`<input id="f-email" class="fld" type="email">`)}</div>`,
        "Create account", async (f, fail) => {
          const r = await window.auth.createTechnician({username:$("#f-user").value.trim(), password:$("#f-pass").value, name:$("#f-name").value.trim(), phone:$("#f-phone").value.trim(), email:$("#f-email").value.trim()});
          if (!r.isOk) { fail(r.error || "Could not create the technician."); return false; }
          toast("Technician account created."); window.dataSdk.refresh(); refreshUsers(true); return true;
        }, "Give the technician this username and temporary password. They can change it after signing in.");
    }
    function resetPwForm(uid, label) {
      openModal("Reset password · " + label,
        field("f-newpw","New temporary password",`<input id="f-newpw" class="fld" type="text" required minlength="8" autocomplete="off" placeholder="At least 8 characters">`),
        "Reset password", async (f, fail) => {
          const r = await window.auth.resetPassword(Number(uid), $("#f-newpw").value);
          if (!r.isOk) { fail(r.error || "Could not reset the password."); return false; }
          toast("Password reset. Share the new password with " + label + "."); return true;
        });
    }
    function methodForm() {
      openModal("Add payment method",
        field("f-mkind","Type",`<select id="f-mkind" class="fld"><option>GCash</option><option>Bank transfer</option><option>Cash</option><option>Other</option></select>`) +
        field("f-mtitle","Name shown to customers",`<input id="f-mtitle" class="fld" required maxlength="60" placeholder="e.g. GCash, BDO bank transfer, Cash at office">`) +
        `<div class="grid gap-3 sm:grid-cols-2">${field("f-mname","Account name",`<input id="f-mname" class="fld" maxlength="120">`)}${field("f-mno","Account / mobile number",`<input id="f-mno" class="fld" maxlength="120">`)}</div>` +
        field("f-minfo","Instructions (optional)",`<textarea id="f-minfo" class="fld" rows="3" placeholder="e.g. Send the exact invoice amount and screenshot the receipt. For cash, pay at the office during business hours."></textarea>`),
        "Save method", () => save({record_type:"payment_method", title:$("#f-mtitle").value.trim(), pay_method:$("#f-mkind").value, contact_name:$("#f-mname").value.trim(), pay_account_no:$("#f-mno").value.trim(), notes:$("#f-minfo").value.trim(), status:"Active", role:"admin"}, "Payment method added."));
    }
    function nextInvoiceNo() {
      const n = invoices().reduce((m, i) => { const x = /INV-(\d+)/i.exec(i.title || ""); return x ? Math.max(m, parseInt(x[1], 10)) : m; }, 0) + 1;
      return "INV-" + String(n).padStart(4, "0");
    }
    function invoiceEditForm(inv) {
      openModal("Edit invoice",
        field("f-title", "Invoice title", `<input id="f-title" class="fld" required value="${esc(inv.title)}">`) +
        `<div class="grid gap-3 sm:grid-cols-2">${field("f-amt", "Amount (₱)", `<input id="f-amt" class="fld" type="number" min="0.01" step="0.01" required value="${esc(inv.amount)}">`)}${field("f-due", "Due date", `<input id="f-due" class="fld" type="date" value="${esc(inv.due_date || "")}">`)}</div>` +
        field("f-notes", "Description (optional)", `<input id="f-notes" class="fld" value="${esc(inv.notes || "")}">`),
        "Save changes", () => patch(inv, {title: $("#f-title").value.trim(), amount: parseFloat($("#f-amt").value), due_date: $("#f-due").value, notes: $("#f-notes").value.trim()}, "Invoice updated."));
    }

    function openInvoiceDoc(o) {
      const w = window.open("", "_blank");
      if (!w) { toast("Allow pop-ups to print this " + (o.paid ? "receipt" : "invoice") + ".", "error"); return; }
      const rows = o.rows.map(r => `<tr><th>${esc(r[0])}</th><td>${esc(r[1])}</td></tr>`).join("");
      w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${esc(o.title)}</title><style>
        body{font-family:Arial,Helvetica,sans-serif;color:#13233a;max-width:640px;margin:32px auto;padding:0 20px}
        h1{font-size:22px;margin:0}.sub{color:#5b6b80;font-size:13px;margin-top:4px}.tag{float:right;font-size:12px;font-weight:700;letter-spacing:.08em;padding:5px 10px;border-radius:6px;border:1px solid ${o.paid ? "#08776a" : "#9a6509"};color:${o.paid ? "#08776a" : "#9a6509"}}
        table{width:100%;border-collapse:collapse;margin-top:22px;font-size:14px}th,td{text-align:left;padding:10px 4px;border-bottom:1px solid #e3e9f0}th{width:34%;color:#5b6b80;font-weight:600}
        .total{margin-top:22px;padding:16px;background:#f2f6fa;border-radius:8px;display:flex;justify-content:space-between;font-size:17px;font-weight:700}
        .foot{margin-top:28px;color:#5b6b80;font-size:12px}@media print{button{display:none}}
      </style></head><body>
        <span class="tag">${o.paid ? "PAID" : "UNPAID"}</span>
        <h1>VTech I.T Solution</h1><div class="sub">${o.paid ? "Payment receipt" : "Invoice"} &middot; ${esc(o.title)}</div>
        <table>${rows}</table>
        <div class="total"><span>${o.paid ? "Amount paid" : "Amount due"}</span><span>${esc(money(o.amount))}</span></div>
        <p class="foot">${o.paid ? "Thank you for your payment." : "Pay using any option listed on the Billing page, then submit your reference number."}</p>
        <button onclick="window.print()" style="margin-top:14px;padding:8px 14px">Print</button>
      </body></html>`);
      w.document.close(); w.focus(); setTimeout(() => { try { w.print(); } catch (e) {} }, 350);
    }
    function printInvoice(i) {
      const paid = i.status === "Paid", p = payments().find(x => x.pay_invoice_id === i.__backendId && x.status === "Confirmed");
      const issued = i.created_at ? new Date(i.created_at).toLocaleDateString("en-PH", {day:"2-digit", month:"short", year:"numeric"}) : "";
      const rows = [["Billed to", i.customer_name], ["Invoice", i.title], ["Issued", issued], ["Due date", i.due_date ? fmtDate(i.due_date) : "—"]];
      if (i.notes) rows.push(["Description", i.notes]);
      rows.push(["Status", paid ? "Paid" : (i.due_date && i.due_date < localToday() ? "Overdue" : "Unpaid")]);
      if (paid) rows.push(["Payment", p ? `${p.pay_method} · Ref ${p.pay_reference} · ${fmtStamp(p.updated_at || p.created_at)}` : "Marked paid by VTech"]);
      openInvoiceDoc({title: i.title, paid, amount: i.amount, rows});
    }
    function invoiceForm(prefCustomer) {
      const cs = customers();
      if (!cs.length) return toast("Add or register a customer before creating an invoice.", "error");
      openModal("Create invoice",
        field("f-cust","Customer",`<select id="f-cust" class="fld" required>${cs.map(c => `<option value="${esc(c.customer_id)}" ${c.customer_id === prefCustomer ? "selected" : ""}>${esc(c.customer_name)}</option>`).join("")}</select>`) +
        field("f-title","Invoice title",`<input id="f-title" class="fld" required value="${nextInvoiceNo()} · " placeholder="e.g. INV-0001 · Installation deposit">`) +
        `<div class="grid gap-3 sm:grid-cols-2">${field("f-amt","Amount (₱)",`<input id="f-amt" class="fld" type="number" min="0.01" step="0.01" required>`)}${field("f-due","Due date",`<input id="f-due" class="fld" type="date">`)}</div>` +
        field("f-notes","Description (optional)",`<input id="f-notes" class="fld">`),
        "Issue invoice", () => {
          const c = cs.find(x => x.customer_id === $("#f-cust").value);
          return save({record_type:"invoice", title:$("#f-title").value.trim(), customer_id:c.customer_id, customer_name:c.customer_name, contact_name:c.contact_name, amount:parseFloat($("#f-amt").value), due_date:$("#f-due").value, notes:$("#f-notes").value.trim(), status:"Pending", role:"admin"}, "Invoice issued.");
        });
    }
    function jobForm(type, prefCustomer) {
      const cs = customers();
      if (!cs.length) return toast("Add or register a customer first (Customers & Sites).", "error");
      openModal(type === "appointment" ? "New appointment" : "New work order",
        field("f-type","Type",`<select id="f-type" class="fld"><option value="work_order" ${type !== "appointment" ? "selected" : ""}>Work order</option><option value="appointment" ${type === "appointment" ? "selected" : ""}>Appointment</option></select>`) +
        field("f-cust","Customer",`<select id="f-cust" class="fld" required>${cs.map(c => `<option value="${esc(c.customer_id)}" ${c.customer_id === prefCustomer ? "selected" : ""}>${esc(c.customer_name)}</option>`).join("")}</select>`) +
        field("f-site","Site",`<select id="f-site" class="fld" required></select>`) +
        field("f-service","Service",`<select id="f-service" class="fld">${SERVICES.map(s => `<option>${esc(s)}</option>`).join("")}</select>`) +
        `<div class="grid gap-3 sm:grid-cols-3">${field("f-date","Date",`<input id="f-date" class="fld" type="date" min="${localToday()}" required>`)}${field("f-time","Time window",`<input id="f-time" class="fld" placeholder="09:00–11:00">`)}${field("f-prio","Priority",`<select id="f-prio" class="fld"><option>Normal</option><option>High</option><option>Urgent</option></select>`)}</div>` +
        field("f-tech","Assign technician (optional)",`<select id="f-tech" class="fld"><option value="">Assign later</option>${technicians().map(t => `<option>${esc(techName(t))}</option>`).join("")}</select>`) +
        field("f-notes","Details / access notes",`<textarea id="f-notes" class="fld" rows="3"></textarea>`),
        "Create", () => {
          const c = cs.find(x => x.customer_id === $("#f-cust").value), s = sitesOf(c.customer_id).find(x => x.__backendId === $("#f-site").value);
          if (!s) { toast("Choose a site.", "error"); return false; }
          const tech = $("#f-tech").value, service = $("#f-service").value, t = $("#f-type").value;
          return save({record_type:t, title:service, job_title:service, service_type:service, job_id:"JOB-" + rid(5), customer_id:c.customer_id, customer_name:c.customer_name, contact_name:c.contact_name, phone:c.phone, role:"admin",
            site_address:[s.title, s.site_address].filter(Boolean).join(" · "), site_lat:s.site_lat ?? null, site_lng:s.site_lng ?? null, scheduled_date:$("#f-date").value, scheduled_time:$("#f-time").value.trim(), priority:$("#f-prio").value, assigned_technician:tech, status: tech ? "Assigned" : "Open", notes:$("#f-notes").value.trim()}, "Job created.");
        });
      const syncSites = () => {
        const ss = sitesOf($("#f-cust").value);
        $("#f-site").innerHTML = ss.map(s => `<option value="${esc(s.__backendId)}">${esc([s.title, s.site_address].filter(Boolean).join(" · "))}</option>`).join("") || `<option value="">This customer has no site</option>`;
      };
      $("#f-cust").addEventListener("change", syncSites); syncSites();
    }

    /* ---------- events ---------- */
    document.addEventListener("click", async e => {
      const el = e.target.closest("[data-act]"); if (!el) return;
      const act = el.dataset.act, rec = el.dataset.id ? backendRecords.find(r => r.__backendId === el.dataset.id) : null;
      if (act === "new-job") jobForm(el.dataset.type, el.dataset.customer);
      else if (act === "new-customer") customerForm();
      else if (act === "new-tech") techForm();
      else if (act === "reset-pw") resetPwForm(el.dataset.uid, el.dataset.label);
      else if (act === "new-invoice") invoiceForm();
      else if (act === "new-method") methodForm();
      else if (act === "method-toggle" && rec) patch(rec, {status: rec.status === "Active" ? "Hidden" : "Active"}, rec.status === "Active" ? "Hidden from customers." : "Now shown to customers.");
      else if (act === "pay-confirm" && rec) {
        const inv = invoiceOf(rec);
        if (!inv) return toast("The invoice for this payment no longer exists.", "error");
        if (await patch(rec, {status:"Confirmed"})) await patch(inv, {status:"Paid"}, "Payment confirmed. Invoice marked paid.");
      }
      else if (act === "pay-reject" && rec) {
        const a = await VUI.ask({title:"Reject this payment?", message:"The customer is told the payment couldn't be confirmed and can submit it again.", confirmLabel:"Reject payment", danger:true, field:{label:"Reason shown to the customer (optional)", placeholder:"e.g. Reference number not found"}});
        if (!a.ok) return;
        patch(rec, {status:"Rejected", notes: a.value}, "Payment rejected. The customer can submit again.");
      }
      else if (act === "delete" && rec) { const a = await VUI.ask({title:"Delete " + (el.dataset.label || "this record") + "?", message:(rec.record_type === "customer" ? "This can't be undone. The customer's login, sites, jobs, messages and uploaded files are removed. Their invoices and payments are kept for your records." : "This can't be undone. Linked sign-in accounts are removed too."), confirmLabel:"Delete", cancelLabel:"Keep", danger:true}); if (a.ok) remove(rec).then(() => refreshUsers(true)); }
      else if (act === "inv-status" && rec) {
        const ok = await patch(rec, {status: el.dataset.s}, el.dataset.s === "Paid" ? "Marked as paid." : "Marked as unpaid.");
        // Marking paid by hand also settles any payment the customer had submitted, so it leaves the "awaiting confirmation" list.
        if (ok && el.dataset.s === "Paid") for (const p of pendingPayments().filter(x => x.pay_invoice_id === rec.__backendId)) await patch(p, {status: "Confirmed"});
      }
      else if (act === "view-receipt") showReceipt(el.dataset.src, el.dataset.name || "Receipt");
      else if (act === "inv-edit" && rec) invoiceEditForm(rec);
      else if (act === "inv-print" && rec) printInvoice(rec);
      else if (act === "bill-filter") { billFilter = el.dataset.f; renderBilling(); }
      else if (act === "cb-done" && rec) patch(rec, {status:"Done"}, "Callback marked done.");
      else if (act === "select-contact") { selectedKey = el.dataset.key; renderCommunication(); }
      else if (act === "open-chat") { selectedKey = el.dataset.key; navigate("communication-center"); }
      else if (act === "call") startCall(el.dataset.kind);
      else if (act === "goto") { if (el.dataset.key) selectedKey = el.dataset.key; navigate(el.dataset.view); $("#notification-panel").classList.add("hidden"); }
    });
    document.addEventListener("change", e => {
      const el = e.target.closest("[data-act]"); if (!el) return;
      const rec = backendRecords.find(r => r.__backendId === el.dataset.id); if (!rec) return;
      if (el.dataset.act === "assign") {
        const name = el.value;
        const status = name ? (["Open","Booked","Requested","Assigned",""].includes(rec.status) || !rec.status ? "Assigned" : rec.status) : (["Assigned"].includes(rec.status) ? (rec.record_type === "appointment" ? "Booked" : "Open") : rec.status);
        patch(rec, {assigned_technician:name, status}, name ? "Assigned to " + name + "." : "Technician unassigned.");
      } else if (el.dataset.act === "job-status") patch(rec, {status: el.value}, "Status updated.");
    });

    async function refreshUsers(force) {
      const sig = customers().length + ":" + technicians().length;
      if (!force && sig === usersSig) return;
      usersSig = sig;
      const r = await window.auth.users();
      if (r.isOk) { usersList = r.users; renderCustomers(); renderTechnicians(); }
    }
    const dataHandler = { onDataChanged(data) { clearTimeout(initialLoadTimer); backendRecords = data; loaded = true; $("#sync-text").textContent = "Synced with database"; renderAll(); refreshUsers(false); } };
    async function initializeData() {
      initialLoadTimer = setTimeout(() => { $("#sync-text").textContent = "Offline"; toast("Could not load saved data. Check your connection, then refresh the page.", "error"); }, 8000);
      const r = await window.dataSdk.init(dataHandler);
      if (!r.isOk) { clearTimeout(initialLoadTimer); $("#sync-text").textContent = "Offline"; }
    }
    function applyUser(u) {
      authUser = u;
      $("#login-overlay").style.display = "none";
      $("#pw-warning").classList.toggle("gone", !u.must_change);
      $("#account-info").textContent = "Signed in as " + u.username;
      renderProfile();
      initializeData();
    }
    async function boot() {
      window.dataSdk.onUnauthorized = () => location.replace("index.php");
      const r = await window.auth.me();
      if (r.user && r.user.role === "admin") return applyUser(r.user);
      location.replace("index.php");
    }

    document.addEventListener("DOMContentLoaded", () => {
      lucide.createIcons();
      boot();
      $("#signout-btn").addEventListener("click", async () => { window.dataSdk.stop(); await window.auth.logout(); location.replace("index.php"); });
      $("#pw-form").addEventListener("submit", async e => {
        e.preventDefault(); const err = $("#pw-error"); err.classList.add("gone");
        const bad = m => { err.textContent = m; err.classList.remove("gone"); };
        if ($("#pw-new").value !== $("#pw-new2").value) return bad("The new passwords do not match.");
        const btn = e.submitter; btn.disabled = true;
        const r = await window.auth.changePassword($("#pw-current").value, $("#pw-new").value);
        btn.disabled = false;
        if (!r.isOk) return bad(r.error || "Could not change the password.");
        e.target.reset(); $("#pw-warning").classList.add("gone"); toast("Password updated.");
      });
      const sideNav = $(".side-nav"), overlay = $("#drawer-overlay");
      $("#mobile-nav-toggle").addEventListener("click", () => { sideNav.classList.toggle("mobile-open"); overlay.classList.toggle("show"); });
      overlay.addEventListener("click", () => { sideNav.classList.remove("mobile-open"); overlay.classList.remove("show"); });
      document.querySelectorAll(".nav-link").forEach(l => l.addEventListener("click", e => { e.preventDefault(); navigate(l.dataset.view); }));
      $("#notification-button").addEventListener("click", () => $("#notification-panel").classList.toggle("hidden"));
      $("#close-notifications").addEventListener("click", () => $("#notification-panel").classList.add("hidden"));
      $("#global-search").addEventListener("input", renderAll);
      $("#contact-search").addEventListener("input", renderCommunication);
      document.querySelectorAll(".filter-chip").forEach(b => b.addEventListener("click", () => {
        contactFilter = b.dataset.filter;
        document.querySelectorAll(".filter-chip").forEach(c => { c.classList.toggle("bg-[#258fe4]", c === b); c.classList.toggle("border", c !== b); });
        renderCommunication();
      }));
      $("#message-form").addEventListener("submit", async e => {
        e.preventDefault();
        const input = $("#message-input"), text = input.value.trim(), sel = contacts().find(c => c.key === selectedKey);
        if (!text || !sel) return;
        const rec = {record_type:"message", title:"Admin message", thread_id:sel.key, msg_sender:adminName(), msg_text:text, msg_timestamp:nowIso(), msg_type:"message", status:"Unread", role:"admin"};
        if (sel.kind === "customer") { rec.customer_id = sel.rec.customer_id; rec.customer_name = sel.rec.customer_name; } else rec.assigned_technician = sel.name;
        if (await save(rec)) input.value = "";
      });
      $("#profile-form").addEventListener("submit", async e => {
        e.preventDefault();
        const data = {record_type:"admin_profile", title:"Admin profile", contact_name:$("#profile-name").value.trim(), notes:$("#profile-role").value.trim(), phone:$("#profile-phone").value.trim(), email:$("#profile-email").value.trim(), status:"Active", role:"admin"};
        const cur = adminRec();
        if (cur) await patch(cur, data, "Profile saved."); else await save(data, "Profile saved.");
      });
      window.addEventListener("hashchange", () => navigate(location.hash.slice(1), false));
      navigate(location.hash.slice(1) || "dashboard", false);
    });
  </script>
 <script src="vtech-ui.js"></script>
 </body>
</html>
