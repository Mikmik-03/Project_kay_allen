<?php
// Landing page + the single sign-in / sign-up screen for VTech (customers, technicians, admins).
// Read the Google client ID from lib.php without opening a DB connection, so the landing page always loads.
$GID = preg_match("/GOOGLE_CLIENT_ID\s*=\s*'([^']*)'/", (string)file_get_contents(__DIR__ . '/lib.php'), $m) ? $m[1] : '';
header('Cache-Control: no-store');
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="VTech I.T. Solution — CCTV and security technology service hub.">
<title>VTech I.T. Solution</title>
<link rel="icon" type="image/png" href="favicon.png">
<meta name="theme-color" content="#071526"><link rel="apple-touch-icon" href="icons/apple-touch-icon.png"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-title" content="VTech"><script src="pwa.js" defer></script>
<script src="https://accounts.google.com/gsi/client" async defer></script>
<style>
@import url('https://fonts.googleapis.com/css2?family=Archivo:wdth,wght@62..125,400..800&display=swap');
:root{--page:#050b17;--blue:#2f5bea;--blue-dark:#2449c4;--ink:#0f1b2d;--muted:#64748b;--soft:#8fa6c0;--paper:#f4f7fb}
*{box-sizing:border-box}html{scroll-behavior:smooth}
body{margin:0;min-height:100vh;min-height:100dvh;display:flex;flex-direction:column;font-family:Archivo,"Segoe UI",system-ui,Arial,sans-serif;color:var(--ink);background:var(--page)}

/* header */
.top{display:flex;justify-content:space-between;align-items:center;width:100%;max-width:1180px;margin:0 auto;padding:22px 24px}
.brand{display:flex;align-items:center;gap:12px;font-weight:700;font-size:20px;color:#fff;letter-spacing:-.01em}.logo{width:48px;height:48px;object-fit:contain;display:block}.brand small{display:block;font-size:12px;font-weight:500;letter-spacing:.02em;color:var(--soft)}

/* layout */
.wrap{flex:1;width:100%;max-width:1180px;margin:0 auto;padding:8px 24px 48px;display:grid;grid-template-columns:minmax(0,1.1fr) minmax(0,.9fr);gap:56px;align-items:center}
.foot{width:100%;max-width:1180px;margin:0 auto;padding:0 24px 28px;font-size:12px;color:#6f86a0}

/* hero */
.hero h1{margin:0 0 16px;max-width:13em;color:#fff;font-size:clamp(34px,4.4vw,58px);font-weight:700;font-stretch:112%;line-height:1.06;letter-spacing:-.025em;text-wrap:balance}
.lead{margin:0 0 20px;font-size:20px;font-weight:600;color:#cfe0f3}
.desc{margin:0;max-width:34em;font-size:17px;line-height:1.75;font-weight:400;color:var(--soft)}

/* sign-in card */
.card{background:var(--paper);border-radius:24px;padding:36px;box-shadow:0 40px 80px -30px #000c;position:sticky;top:20px}
h2{font-size:28px;font-weight:700;font-stretch:108%;letter-spacing:-.03em;margin:0 0 6px}.sub{color:var(--muted);font-size:14px;line-height:1.6;margin:0 0 22px}
.tabs{display:grid;grid-template-columns:1fr 1fr;background:#e6ecf5;border-radius:12px;padding:4px;margin-bottom:22px}
.tabs button{border:0;background:transparent;padding:11px;border-radius:9px;font:inherit;font-size:14px;font-weight:600;color:var(--muted);cursor:pointer;transition:all .2s}.tabs button.on{background:#fff;color:var(--ink);box-shadow:0 2px 8px #0f1b2d1a}
label{display:block;font-size:13px;font-weight:600;margin:0 0 8px;color:#334155}.field{margin-bottom:17px}
input{width:100%;padding:14px 16px;border:1px solid #d6dfeb;border-radius:12px;font:inherit;font-size:14px;outline:none;background:#fbfdff;transition:border-color .15s,box-shadow .15s}input:focus{border-color:var(--blue);box-shadow:0 0 0 4px #2f5bea24;background:#fff}
.row2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.pw{position:relative}.pw input{padding-right:70px}.toggle{position:absolute;right:12px;top:50%;transform:translateY(-50%);border:0;background:transparent;color:#52647c;font-size:12px;font-weight:600;cursor:pointer}
button.submit{width:100%;border:0;border-radius:12px;background:var(--blue);color:#fff;font:inherit;font-weight:700;font-size:15px;padding:15px;cursor:pointer;transition:background .15s,transform .1s}button.submit:hover{background:var(--blue-dark)}button.submit:active{transform:translateY(1px)}button:disabled{opacity:.65;cursor:wait}
.message{display:none;padding:12px 14px;border-radius:12px;background:#fff0f0;color:#b42332;font-size:13px;margin:0 0 16px}.message.show{display:block}
.helper{font-size:12px;color:var(--muted);text-align:center;line-height:1.6;margin-top:18px}.or{color:var(--muted);font-size:12px;text-align:center;margin:0 0 16px}
.hide{display:none!important}
button:focus-visible,a:focus-visible,.toggle:focus-visible{outline:3px solid #4a9dff;outline-offset:2px}
input[aria-invalid=true]{border-color:#d64557;box-shadow:0 0 0 4px #d6455726}
.hint:empty{min-height:0;margin:0}.hint{font-size:12px;color:var(--muted);margin:6px 0 0;min-height:16px;line-height:1.4}.hint.warn{color:#a05d00}.hint.bad{color:#b42332}.hint.good{color:#0b7a5c}
.remember{display:flex;align-items:center;gap:8px;font-size:13px;font-weight:500;margin:-4px 0 18px;color:var(--ink)}.remember input{width:auto;padding:0;margin:0}

@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto}*{transition:none!important}}
@media(max-width:900px){.wrap{grid-template-columns:1fr;gap:36px}.card{position:static;padding:28px 22px;border-radius:22px}.row2{grid-template-columns:1fr}}
</style>
</head>
<body>
<header class="top">
  <div class="brand"><img class="logo" src="logo.png" alt="VTech I.T. Solutions logo"><span>VTech <small>I.T. Solution</small></span></div>
</header>
<div class="wrap">
  <section class="hero">
    <h1>Your CCTV and security service hub.</h1>
    <p class="lead">Security technology, made simpler.</p>
    <p class="desc">VTech I.T. Solution installs, repairs and maintains CCTV and security systems, and has been doing so since 2015. Whether you need new cameras or a fault fixed, we keep your site covered and your footage there when you need it.</p>
  </section>

  <section class="card" id="access">
    <h2 id="title">Sign in</h2>
    <p class="sub" id="sub">Enter your username and password. Your account decides which workspace opens.</p>
    <div class="tabs" id="tabs"><button type="button" id="tab-login" class="on">Sign in</button><button type="button" id="tab-register">New customer</button></div>
    <div id="g-wrap" class="hide"><div id="g-btn" style="display:flex;justify-content:center"></div><p class="or" style="margin-top:14px">— or use a username —</p></div>
    <div id="message" class="message" role="alert"></div>

    <form id="loginForm">
      <div class="field"><label for="username">Username</label><input id="username" autocomplete="username" autocapitalize="none" spellcheck="false" required maxlength="60" placeholder="Enter your username" autofocus></div>
      <div class="field"><label for="password">Password</label><div class="pw"><input id="password" type="password" autocomplete="current-password" required placeholder="Enter your password"><button class="toggle" type="button" id="togglePassword" aria-controls="password">Show</button></div><p class="hint" id="caps" aria-live="polite"></p></div>
      <label class="remember"><input type="checkbox" id="remember"> Remember my username on this device</label>
      <button class="submit" id="submitBtn" type="submit">Sign in</button>
      <p class="helper">Forgot your password? Contact your VTech administrator to have it reset.</p>
    </form>

    <form id="registerForm" class="hide">
      <div class="field"><label for="r-user">Choose a username</label><input id="r-user" required minlength="3" maxlength="40" autocomplete="username" placeholder="letters, numbers, . - _"></div>
      <div class="row2 field"><div><label for="r-pw">Password</label><input id="r-pw" type="password" required minlength="8" maxlength="72" autocomplete="new-password" placeholder="At least 8 characters"></div><div><label for="r-pw2">Confirm password</label><input id="r-pw2" type="password" required minlength="8" maxlength="72" autocomplete="new-password"></div></div>
      <p class="hint" id="r-hint" aria-live="polite" style="margin:-8px 0 14px">Use 8 or more characters. A phrase of a few words works well.</p>
      <div class="field"><label for="r-name">Your full name</label><input id="r-name" required autocomplete="name" placeholder="e.g. Maria Santos"></div>
      <div class="row2 field"><div><label for="r-phone">Mobile number</label><input id="r-phone" type="tel" required autocomplete="tel" placeholder="+63 9XX XXX XXXX"></div><div><label for="r-email">Email (optional)</label><input id="r-email" type="email" autocomplete="email"></div></div>
      <button class="submit" type="submit">Create account</button>
    </form>

    <form id="googleForm" class="hide">
      <p class="sub" id="g-who"></p>
      <div class="field"><label for="gs-name">Your full name</label><input id="gs-name" required autocomplete="name"></div>
      <div class="field"><label for="gs-phone">Mobile number</label><input id="gs-phone" type="tel" required autocomplete="tel" placeholder="+63 9XX XXX XXXX"></div>
      <button class="submit" type="submit">Finish creating account</button>
    </form>
  </section>
</div>
<footer class="foot">© 2026 VTech I.T. Solution · Service and support</footer>

<script>
const $=s=>document.querySelector(s);
const PORTAL_URL={admin:'admin-dispatcher-portal.php',technician:'technician-pportal.php',customer:'customer-portal.php'};
const msg=$('#message');
const showMsg=t=>{msg.textContent=t;msg.classList.add('show');};
const clearMsg=()=>{msg.textContent='';msg.classList.remove('show');};

async function call(portal,action,body){
  const res=await fetch('auth.php?action='+action,{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json','X-Portal':portal},body:JSON.stringify(body||{})});
  let data={};try{data=await res.json();}catch(e){}
  return Object.assign({},data,{ok:res.ok&&data.isOk!==false,status:res.status});
}
const go=role=>{window.location.href=PORTAL_URL[role]||PORTAL_URL.customer;};
const NET_ERR='Could not reach the server. Check your connection and try again.';

$('#togglePassword').addEventListener('click',()=>{const p=$('#password'),b=$('#togglePassword');p.type=p.type==='password'?'text':'password';b.textContent=p.type==='password'?'Show':'Hide';});

function showTab(t){
  clearMsg();
  $('#loginForm').classList.toggle('hide',t!=='login');$('#registerForm').classList.toggle('hide',t!=='register');$('#googleForm').classList.add('hide');
  $('#tab-login').classList.toggle('on',t==='login');$('#tab-register').classList.toggle('on',t==='register');
  $('#title').textContent=t==='login'?'Sign in':'Create account';
  $('#sub').textContent=t==='login'?'Enter your username and password. Your account decides which workspace opens.':'New customer? Set up your account to book and track services.';
}
$('#tab-login').addEventListener('click',()=>showTab('login'));
$('#tab-register').addEventListener('click',()=>showTab('register'));
if(location.hash==='#register')showTab('register');

/* remember username (never the password) */
try{const u=localStorage.getItem('vtech_user');if(u){$('#username').value=u;$('#remember').checked=true;$('#password').focus();}}catch(e){}
/* caps lock warning */
$('#password').addEventListener('keyup',e=>{const on=e.getModifierState&&e.getModifierState('CapsLock');const h=$('#caps');h.textContent=on?'Caps Lock is on.':'';h.className='hint'+(on?' warn':'');});
$('#password').addEventListener('blur',()=>{$('#caps').textContent='';});
/* live password feedback on sign-up */
function checkPw(){
  const a=$('#r-pw').value,b=$('#r-pw2').value,h=$('#r-hint');
  let t='Use 8 or more characters. A phrase of a few words works well.',c='';
  if(a&&a.length<8){t='Too short: '+a.length+' of 8 characters.';c='bad';}
  else if(a&&b&&a!==b){t='The passwords do not match yet.';c='bad';}
  else if(a&&b&&a===b){t='Passwords match.';c='good';}
  else if(a){t='Long enough. Repeat it to confirm.';c='good';}
  h.textContent=t;h.className='hint '+c;$('#r-pw2').setAttribute('aria-invalid',String(!!(a&&b&&a!==b)));
}
$('#r-pw').addEventListener('input',checkPw);$('#r-pw2').addEventListener('input',checkPw);

$('#loginForm').addEventListener('submit',async e=>{
  e.preventDefault();clearMsg();const btn=$('#submitBtn');btn.disabled=true;btn.textContent='Signing in…';
  const payload={username:$('#username').value.trim(),password:$('#password').value};
  try{if($('#remember').checked)localStorage.setItem('vtech_user',payload.username);else localStorage.removeItem('vtech_user');}catch(e){}
  try{
    let lastError='Incorrect username or password.';
    // The same login works for every account type; try each portal until the account's role matches.
    for(const role of ['admin','technician','customer']){
      const r=await call(role,'login',payload);
      if(r.ok){btn.dataset.go='1';btn.textContent='Opening your workspace…';go(role);return;}
      if(r.status===403)continue;           // password right, wrong portal -> try the next one
      lastError=r.error||lastError;break;   // wrong password / locked out -> stop (don't count extra attempts)
    }
    showMsg(lastError);
  }catch(err){showMsg(NET_ERR);}
  finally{if(!btn.dataset.go){btn.disabled=false;btn.textContent='Sign in';}}
});

$('#registerForm').addEventListener('submit',async e=>{
  e.preventDefault();clearMsg();
  if($('#r-pw').value!==$('#r-pw2').value)return showMsg('The passwords do not match.');
  const btn=e.submitter;btn.disabled=true;
  try{
    const r=await call('customer','register',{username:$('#r-user').value.trim(),password:$('#r-pw').value,contact_name:$('#r-name').value.trim(),phone:$('#r-phone').value.trim(),email:$('#r-email').value.trim()});
    if(!r.ok)return showMsg(r.error||'Could not create your account.');
    go('customer');
  }catch(err){showMsg(NET_ERR);}finally{btn.disabled=false;}
});

/* Google sign-in (customers) */
const GOOGLE_CLIENT_ID=<?= json_encode($GID) ?>;
function initGoogle(){
  if(!GOOGLE_CLIENT_ID||GOOGLE_CLIENT_ID.indexOf('PASTE')!==-1)return;
  let tries=0;
  const t=()=>{
    if(!window.google||!google.accounts){if(++tries<50)setTimeout(t,200);return;}
    google.accounts.id.initialize({client_id:GOOGLE_CLIENT_ID,callback:onGoogle});
    google.accounts.id.renderButton($('#g-btn'),{theme:'outline',size:'large',width:280,text:'continue_with'});
    $('#g-wrap').classList.remove('hide');
  };t();
}
async function onGoogle(resp){
  clearMsg();
  try{
    const r=await call('customer','google_login',{credential:resp.credential});
    if(!r.ok)return showMsg(r.error||'Could not sign in with Google.');
    if(r.needs_profile){
      $('#g-who').textContent='Signed in with Google as '+(r.email||'your account')+'. Add your name and mobile number to finish.';
      $('#gs-name').value=r.name||'';
      ['#loginForm','#registerForm','#tabs','#g-wrap'].forEach(s=>$(s).classList.add('hide'));
      $('#title').textContent='Almost there';$('#sub').classList.add('hide');
      $('#googleForm').classList.remove('hide');return;
    }
    go('customer');
  }catch(err){showMsg(NET_ERR);}
}
$('#googleForm').addEventListener('submit',async e=>{
  e.preventDefault();clearMsg();const btn=e.submitter;btn.disabled=true;
  try{
    const r=await call('customer','google_register',{contact_name:$('#gs-name').value.trim(),phone:$('#gs-phone').value.trim()});
    if(!r.ok)return showMsg(r.error||'Could not create your account.');
    go('customer');
  }catch(err){showMsg(NET_ERR);}finally{btn.disabled=false;}
});
initGoogle();
</script>
</body></html>
