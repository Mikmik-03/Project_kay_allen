<?php
// Accepts one file (field "file") from a signed-in technician, admin or customer (payment receipts) and stores it in /uploads.
require_once __DIR__ . '/lib.php';
$portal = request_portal();
ensure_schema();
start_session($portal);
require_user($portal, ['admin', 'technician', 'customer']);
session_write_close();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_FILES['file'])) {
    json_out(['isOk' => false, 'error' => 'No file received'], 400);
}
$f = $_FILES['file'];
if ($f['error'] !== UPLOAD_ERR_OK) {
    $msgs = [
        UPLOAD_ERR_INI_SIZE   => 'That file is larger than the server allows (' . ini_get('upload_max_filesize') . '). Choose a smaller file.',
        UPLOAD_ERR_FORM_SIZE  => 'That file is too large.',
        UPLOAD_ERR_PARTIAL    => 'The upload was interrupted. Please try again.',
        UPLOAD_ERR_NO_FILE    => 'No file was selected.',
        UPLOAD_ERR_NO_TMP_DIR => 'The server has no temporary folder for uploads.',
        UPLOAD_ERR_CANT_WRITE => 'The server could not save the file.',
    ];
    json_out(['isOk' => false, 'error' => $msgs[$f['error']] ?? ('Upload failed (code ' . $f['error'] . ')')], $f['error'] === UPLOAD_ERR_INI_SIZE || $f['error'] === UPLOAD_ERR_FORM_SIZE ? 413 : 400);
}
if ($f['size'] > 8 * 1024 * 1024) json_out(['isOk' => false, 'error' => 'File is larger than 8 MB'], 413);

$allowed = ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp', 'pdf' => 'application/pdf'];
$ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
$mime = function_exists('mime_content_type') ? mime_content_type($f['tmp_name']) : ($allowed[$ext] ?? '');
if (!isset($allowed[$ext]) || $mime !== $allowed[$ext]) json_out(['isOk' => false, 'error' => 'Only JPG, PNG, WEBP or PDF files are allowed'], 415);

$dir = __DIR__ . '/uploads';
if (!is_dir($dir)) { mkdir($dir, 0775, true); }
$stored = bin2hex(random_bytes(10)) . '.' . $ext;
if (!move_uploaded_file($f['tmp_name'], "$dir/$stored")) json_out(['isOk' => false, 'error' => 'Could not save the file'], 500);
$display = preg_replace('/[^A-Za-z0-9._ \-()]/', '_', basename($f['name']));
json_out(['isOk' => true, 'stored' => $stored, 'name' => $display]);
?>
