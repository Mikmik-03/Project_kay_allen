<!doctype html>
<html lang="en"><head><link rel="icon" type="image/png" href="favicon.png">
<meta name="theme-color" content="#10253f"><link rel="apple-touch-icon" href="icons/apple-touch-icon.png"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-title" content="VTech"><script src="pwa.js" defer></script>
<script>window["__codeletBootstrap__"]=JSON.parse('{"A":"A","B":"20261009-04-61a833b","C":{"Abril Fatface":"YACgEZbkUVE,0","Albert Sans":"YAHO2HRfeh4,0","Alfa Slab One":"YACgEYS9sJU,0","Anton":"YACgEcYqQ-A,0","Archivo Black":"YACgEZulLoA,0","Archivo":"YAHO2-t-jNE,0","Arial":"YAGyDvJ_4Ts,0","Baloo 2":"YAHO2IcQUcM,0","Barlow Condensed":"YAFdJljEuFc,0","Barlow":"YAFdJsyuOPM,1","Bebas Neue":"YACgESME5ew,0","Bricolage Grotesque":"YAFyMcdwzpc,0","Canva Sans":"YAFdJjTk5UU,1","Caveat":"YALBs2ploWQ,0","Cinzel":"YACgEeV8bIQ,0","Cormorant Garamond":"YAFdJhX-538,0","Courier New":"YAGzXiGs0_8,0","Courier Prime":"YAD1aFjegN8,0","DM Sans":"YAD1aU3sLnI,0","DM Serif Display":"YAD1aYG82rc,0","Figtree":"YAHO2b-mV7A,0","Forum":"YACgEcnnqB4,0","Fraunces":"YAFdJpU7Kkk,0","Fredoka":"YACgEZml080,0","Georgia":"YAGzXkO0pEM,0","Hanken Grotesk":"YAHO2VB9G0I,0","Helvetica":"YAFcf7zkXN0,0","IBM Plex Mono":"YAFdJkmvhGI,0","IBM Plex Sans":"YAFdJgT0SHI,0","Impact":"YAFcfnjI7Vk,0","Instrument Sans":"YAHO2bKyaSQ,0","Instrument Serif":"YAHFeOnZNEk,0","Inter":"YAFdJvSyp_k,3","Italiana":"YAHO2Toik_w,0","Jacques Francois":"YAHO2a5g66Q,0","JetBrains Mono":"YAFdJksXcAk,0","Josefin Sans":"YAFdJjvw9Ps,0","Karla":"YAHO2V2NSXM,0","Lato":"YAFdJuFCnaw,0","Libre Baskerville":"YACgEUFdPdA,0","Libre Caslon Display":"YAHO2XhLmt0,0","Lobster":"YAD8SnSjSFI,0","Lora":"YACgEXvxf8Q,0","Manrope":"YAHO2b2feC4,0","Merriweather":"YACgEXvHxxs,0","Montserrat":"YAFdtQi73Xs,0","Noto Sans JP":"YAFdJiHXlcI,0","Noto Sans KR":"YAGsojZj-RQ,0","Nunito Sans":"YAFdtQJYB9w,1","Nunito":"YAFdJoNRMmU,1","Oleo Script":"YACgEQQ14jI,0","Oswald":"YACgEQY10lw,0","Outfit":"YAHO2nVlg14,0","Pacifico":"YADLjORQ1u4,0","Playfair Display":"YAFdJhem5V8,1","Plus Jakarta Sans":"YAHO2gdhi18,0","Poppins":"YAFdJjbTu24,1","Press Start 2P":"YAFyGr-8pmQ,0","Public Sans":"YAFdJj8NdaU,1","Quicksand":"YAFdJpYtCxE,1","Raleway":"YAFdJhmxbVQ,1","Roboto Slab":"YAFdJswIKAg,0","Rockwell":"YAFcfyVZnN0,0","Rye":"YACgEdQP21k,0","Sarabun":"YAFdJssSnME,0","Schibsted Grotesk":"YAHO2sWydRk,0","Segoe UI":"YAHNdRD1Klw,0","Source Sans 3":"YAG4lO1Mj10,0","Space Grotesk":"YAHO2sjPCSM,0","Space Mono":"YADW1-vpsoc,0","Spectral":"YAHO2rVUHIM,0","Times New Roman":"YAGzXW3gftg,0","Trebuchet MS":"YAFcfrglpVA,0","Ubuntu":"YACgERDU--Q,0","Verdana":"YAGzXTctYtQ,0","Work Sans":"YAGXhLOKv44,0","Yellowtail":"YACgEYG4kG4,0"}}');</script><script src="/_sdk/3ea5843eacd3e51f.telemetry_sdk.js" integrity="sha512-1IT905GQp6Xezy7dJYJjQl6KtI/PDxD5Vu755gJMNA+luF1QkRT8rHzF+xP7Ekem4HWP8sPFcQQAmx6FCSGaMg=="></script>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>VTech I.T Solution</title>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&amp;family=Space+Mono:wght@400;700&amp;display=swap" rel="stylesheet">
  <style>
    :root{--navy:#10253f;--navy2:#173654;--blue:#1769e0;--teal:#129c8d;--paper:#f4f7fa;--ink:#17283c;--muted:#65758a;--line:#dce4ed;--amber:#c78311;--red:#c83d4d}
    *{box-sizing:border-box} body{margin:0;background:var(--paper);color:var(--ink);font-family:"DM Sans",sans-serif}
    button,input,select,textarea{font:inherit} button{cursor:pointer} button:disabled{opacity:.55;cursor:not-allowed}
    button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{outline:3px solid #81b5ff;outline-offset:2px}
    .portal-shell{width:100%;min-height:calc(100 * min(var(--vh,1vh),1vh));display:flex}
    .side-rail{width:256px;background:var(--navy);padding:22px 14px;color:#fff;flex:none}
    .brand{display:flex;align-items:center;gap:10px;padding:2px 9px 23px;border-bottom:1px solid #ffffff24}.brand-mark{width:38px;height:38px;display:grid;place-items:center;border-radius:12px;background:var(--blue)}.brand small{display:block;margin-top:2px;color:#9db2ca;font:10px "Space Mono",monospace;letter-spacing:.1em}
    .rail-label{margin:24px 10px 8px;color:#91a9c4;font:10px "Space Mono",monospace;letter-spacing:.12em}.rail-btn{width:100%;border:0;background:transparent;color:#c8d6e5;display:flex;gap:11px;align-items:center;padding:10px;border-radius:9px;text-align:left;font-size:14px}.rail-btn:hover,.rail-btn.active{background:#68aeff2a;color:#fff}
    .main-area{width:calc(100% - 256px);min-width:0}.topbar{min-height:72px;padding:12px 28px;background:#fff;border-bottom:1px solid var(--line);display:flex;align-items:center;justify-content:space-between;gap:16px}.top-kicker{font:11px "Space Mono",monospace;color:#53708e;letter-spacing:.09em}.top-actions{display:flex;align-items:center;gap:9px}
    .content-area{width:100%;max-width:1500px;margin:auto;padding:28px}.page-head{display:flex;align-items:flex-end;justify-content:space-between;gap:16px;margin-bottom:20px}
    h1,h2,h3,p{margin:0}h1{font-size:30px;letter-spacing:-.04em}h2{font-size:17px}h3{font-size:14px}.eyebrow{font:11px "Space Mono",monospace;letter-spacing:.09em;text-transform:uppercase;color:#53708e}.muted{font-size:13px;color:var(--muted)}
    .btn{border:0;border-radius:9px;padding:10px 13px;display:inline-flex;align-items:center;justify-content:center;gap:8px;font-size:13px;font-weight:700}.btn-primary{background:var(--blue);color:#fff}.btn-primary:hover{background:#1057bc}.btn-outline{background:#fff;color:#345;border:1px solid var(--line)}.btn-soft{background:#edf4ff;color:#1559bd}.btn-teal{background:var(--teal);color:#fff}
    .card{background:#fff;border:1px solid var(--line);border-radius:14px;box-shadow:0 3px 12px #192e4b0b}.panel-head{padding:16px 18px;border-bottom:1px solid var(--line);display:flex;align-items:center;justify-content:space-between;gap:12px}.panel-body{padding:16px 18px}
    .chip{display:inline-flex;align-items:center;padding:4px 8px;border-radius:999px;font-size:11px;font-weight:700;white-space:nowrap}.blue{background:#e7f0ff;color:#1761c4}.teal{background:#e1f7f1;color:#08776a}.amber{background:#fff3d9;color:#9a6509}.red{background:#fbe9ec;color:#a22a3a}.slate{background:#edf1f5;color:#526176}
    .portal-tabs{display:flex;gap:6px;overflow:auto;margin-bottom:18px}.portal-tab{border:1px solid var(--line);background:#fff;color:#53657b;border-radius:8px;padding:8px 11px;white-space:nowrap;font-size:12px;font-weight:700}.portal-tab.active{background:var(--navy);border-color:var(--navy);color:#fff}
    .hero{position:relative;min-height:218px;overflow:hidden;background:var(--navy)}.hero img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;opacity:.36}.hero:after{content:"";position:absolute;inset:0;background:linear-gradient(90deg,#10253ff0 8%,#10253f8c 58%,#10253f1a)}.hero-copy{position:relative;z-index:1;color:#fff;max-width:66%;padding:25px}.hero-copy .muted{color:#ccdae9}
    .workflow{display:flex;gap:5px;overflow:auto;margin:16px 0;padding:12px;background:var(--navy);border-radius:14px}.step{padding:8px 11px;border-radius:7px;color:#c8d6e5;font-size:12px;font-weight:700;white-space:nowrap}.step.done{color:#8df2dc}.step.current{background:#216ddd;color:#fff}
    .dashboard-grid{display:grid;grid-template-columns:1.45fr .9fr;gap:16px}.stack{display:grid;gap:16px}.row{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:11px 0;border-bottom:1px solid #edf1f5}.row:last-child{border-bottom:0}.row-title{font-size:13px;font-weight:700}
    .appointment{border-left:4px solid var(--blue);padding:16px}.appointment-info{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:13px;margin-top:15px}.data-label{font:10px "Space Mono",monospace;text-transform:uppercase;color:#718198}.data-value{margin-top:3px;font-size:13px;font-weight:700}
    .site-photo{height:128px;width:100%;object-fit:cover;border-radius:10px}.mini{border:1px solid var(--line);border-radius:11px;padding:14px}.notice{padding:12px;border-radius:9px;font-size:13px}.notice.loading{background:#edf4ff;color:#1559bd}.notice.success{background:#e1f7f1;color:#08776a}.notice.error{background:#fbe9ec;color:#a22a3a}
    .view{display:none}.view.active{display:block;animation:rise .25s ease both}@keyframes rise{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
    .drawer{position:fixed;z-index:30;inset:0;pointer-events:none}.drawer.open{pointer-events:auto}.drawer-bg{position:absolute;inset:0;background:#07172966;opacity:0;transition:.2s}.drawer.open .drawer-bg{opacity:1}.drawer-panel{position:absolute;top:0;right:0;width:min(540px,100%);height:100%;overflow:auto;background:#fff;padding:23px;box-shadow:-12px 0 30px #0d20361f;transform:translateX(100%);transition:.25s}.drawer.open .drawer-panel{transform:none}
    label{display:block;margin-bottom:5px;font-size:12px;font-weight:700;color:#526176}input,select,textarea{width:100%;border:1px solid var(--line);border-radius:8px;padding:10px;background:#fff;color:var(--ink)}.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
    .toast{position:fixed;z-index:50;right:20px;bottom:20px;max-width:360px;background:var(--navy);color:#fff;border-radius:9px;padding:12px 15px;font-size:13px;transform:translateY(130px);transition:.25s}.toast.show{transform:none}.toast.error{background:#a22a3a}.hide{display:none!important}
    @media(max-width:950px){.side-rail{width:68px;padding:18px 9px}.brand-copy,.rail-btn span,.rail-label{display:none}.brand{justify-content:center}.rail-btn{justify-content:center}.main-area{width:calc(100% - 68px)}.dashboard-grid{grid-template-columns:1fr}.hero-copy{max-width:82%}}
    @media(max-width:640px){.side-rail{display:none}.main-area{width:100%}.topbar{padding:11px 15px}.content-area{padding:17px}.page-head{align-items:flex-start;flex-direction:column}.hero-copy{max-width:100%;padding:20px}.appointment-info,.form-grid{grid-template-columns:1fr}.top-kicker{display:none}}
  </style>
  <link rel="stylesheet" href="vtech-ui.css">
  <script src="https://cdn.tailwindcss.com/3.4.17" type="text/javascript"></script>
  <script src="https://cdn.jsdelivr.net/npm/lucide@0.577.0/dist/umd/lucide.min.js" type="text/javascript"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.css">
  <script src="https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.js"></script>
  <script>window.PORTAL = "customer";</script>
  <script src="sdk-override.js" type="text/javascript"></script>
 </head>
 <body>
  <a class="skip-link" href="#main">Skip to content</a>
  <div class="portal-shell">
   <aside class="side-rail" aria-label="Customer portal navigation">
    <div class="brand">
     <div class="brand-mark" style="background:none"><img src="logo.png" alt="VTech logo" style="width:42px;height:42px;object-fit:contain"></div>
     <div class="brand-copy"><strong>VTech I.T Solution</strong><small>CUSTOMER PORTAL</small></div>
    </div>
    <div class="rail-label">Menu</div>
    <nav>
     <button class="rail-btn active" data-view="overview"><i data-lucide="layout-dashboard" width="17"></i><span>Overview</span></button>
     <button class="rail-btn" data-view="appointments"><i data-lucide="calendar-days" width="17"></i><span>Appointments</span></button>
     <button class="rail-btn" data-view="sites"><i data-lucide="building-2" width="17"></i><span>Sites</span></button>
     <button class="rail-btn" data-view="documents"><i data-lucide="folder-open" width="17"></i><span>Documents</span></button>
     <button class="rail-btn" data-view="billing"><i data-lucide="receipt-text" width="17"></i><span>Billing</span></button>
     <button class="rail-btn" data-view="support"><i data-lucide="life-buoy" width="17"></i><span>Support</span></button>
    </nav>
    <div class="rail-label">How a project runs</div>
    <p class="muted">Book · Survey · Install · Test · Handover</p>
   </aside>
   <div class="main-area">
    <header class="topbar">
     <div>
      <div class="top-kicker">VTech I.T Solution · Customer services</div>
      <strong id="topbar-name">VTech I.T Solution</strong>
     </div>
     <div class="top-actions">
      <span id="sync-status" class="chip slate">Connecting…</span>
      <button id="notification-button" class="btn btn-outline" aria-expanded="false" aria-controls="notification-panel" aria-label="Notifications"><i data-lucide="bell" width="17"></i><span id="notif-count" class="chip red hide">0</span></button>
      <button id="account-button" class="btn btn-outline hide" type="button" title="Account"><i data-lucide="user-round" width="16"></i><span id="account-name"></span></button>
     </div>
    </header>
    <main class="content-area" id="main" tabindex="-1">
     <section id="notification-panel" class="card hide" aria-live="polite" style="margin-bottom:16px">
      <div class="panel-head"><h2>Notifications</h2><button id="close-notifications" class="btn btn-outline" type="button">Close</button></div>
      <div id="notification-body" class="panel-body"></div>
     </section>

     <section class="page-head">
      <div>
       <div class="eyebrow">VTech I.T Solution</div>
       <h1 id="welcome-title">Welcome</h1>
       <p id="welcome-sub" class="muted" style="margin-top:6px">Manage your CCTV installation, follow service progress, and request support in one place.</p>
      </div>
      <button id="open-booking" class="btn btn-primary"><i data-lucide="calendar-plus" width="17"></i><span>Book a Service</span></button>
     </section>
     <nav class="portal-tabs" aria-label="Customer portal sections">
      <button class="portal-tab active" data-view="overview">Overview</button>
      <button class="portal-tab" data-view="appointments">Appointments</button>
      <button class="portal-tab" data-view="sites">Sites</button>
      <button class="portal-tab" data-view="documents">Documents</button>
      <button class="portal-tab" data-view="billing">Billing</button>
      <button class="portal-tab" data-view="support">Support</button>
     </nav>

     <section id="overview-view" class="view active">
      <section class="card hero" style="background:#10253f">
       <img loading="lazy" src="https://images.pexels.com/photos/13072973/pexels-photo-13072973.jpeg?auto=compress&cs=tinysrgb&w=1280" alt="">
       <div class="hero-copy">
        <div class="eyebrow" style="color:#8ed9ff">Security service status</div>
        <h2 id="hero-title" style="margin-top:8px;color:#fff;font-size:21px">Let’s secure your site</h2>
        <p id="hero-copy" class="muted" style="margin-top:8px;font-size:14px">Book a site survey to get your CCTV project started.</p>
       </div>
      </section>
      <div id="workflow" class="workflow" aria-label="CCTV service progress"></div>
      <div class="dashboard-grid">
       <div class="stack">
        <section class="card">
         <div class="panel-head"><div><h2>Upcoming appointment</h2><p class="muted">Your next service window</p></div></div>
         <div id="upcoming-appointment" class="panel-body"></div>
        </section>
        <section class="card">
         <div class="panel-head"><h2>Recent activity</h2><span class="chip slate">Live updates</span></div>
         <div id="activity-list" class="panel-body"></div>
        </section>
        <section class="card">
         <div class="panel-head"><h2>Service documents</h2><span id="docs-chip" class="chip slate">0 ready</span></div>
         <div id="overview-docs" class="panel-body"></div>
        </section>
       </div>
       <aside class="stack">
        <section class="card">
         <div class="panel-head"><h2>Registered sites</h2><span id="sites-chip" class="chip slate">0</span></div>
         <div id="overview-sites" class="panel-body"></div>
        </section>
        <section class="card">
         <div class="panel-head"><h2>Invoice &amp; payment status</h2><span id="inv-chip" class="chip slate">None</span></div>
         <div class="panel-body"><div id="overview-invoices"></div><button class="btn btn-outline" data-view="billing" style="margin-top:10px">View billing</button></div>
        </section>
        <section class="card">
         <div class="panel-head"><h2>Maintenance &amp; sign-off</h2></div>
         <div class="panel-body">
          <p class="muted">Need a repair or follow-up service at one of your sites?</p>
          <button id="open-maintenance" class="btn btn-soft" style="margin-top:12px"><i data-lucide="wrench" width="16"></i>Request maintenance</button>
          <div id="signoff-state" style="margin-top:17px"></div>
         </div>
        </section>
       </aside>
      </div>
     </section>

     <section id="appointments-view" class="view card">
      <div class="panel-head"><h2>Appointments &amp; service requests</h2><button id="appointments-book" class="btn btn-primary">Book a Service</button></div>
      <div id="appointments-list" class="panel-body"></div>
     </section>

     <section id="sites-view" class="view card">
      <div class="panel-head"><h2>Your sites</h2><span id="customer-id-chip" class="chip teal"></span></div>
      <div class="panel-body">
       <div id="sites-list"></div>
       <form id="site-form" class="mini" style="margin-top:16px">
        <h3>Add another site</h3>
        <div class="form-grid" style="margin-top:10px">
         <div><label for="site-name">Site name</label><input id="site-name" required placeholder="e.g. Main warehouse"></div>
         <div><label for="site-address">Address / location</label><input id="site-address" required placeholder="Street, city"></div>
        </div>
        <button type="submit" class="btn btn-primary" style="margin-top:12px">Save site</button>
       </form>
       <p class="muted" style="margin-top:14px">Your Customer ID is shown for reference when you contact the VTech team.</p>
      </div>
     </section>

     <section id="documents-view" class="view card">
      <div class="panel-head"><h2>Service documents</h2><span class="chip teal">From your technician</span></div>
      <div id="documents-list" class="panel-body"></div>
     </section>

     <section id="billing-view" class="view card">
      <div class="panel-head"><h2>Billing &amp; invoices</h2><span id="billing-chip" class="chip slate"></span></div>
      <div class="panel-body">
       <div id="billing-summary" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin-bottom:6px"></div>
       <div id="billing-filter" class="portal-tabs" style="margin:12px 0 4px"></div>
       <div id="billing-list"></div>
       <div class="mini" style="margin-top:14px">
        <div class="row-title">How to pay</div>
        <div id="pay-methods" style="margin-top:8px"></div>
        <p class="muted" style="margin-top:10px">Pay using one of the options above, then press <strong>I've paid</strong> on the invoice and enter your reference number. We never ask for card details here. Your invoice is marked paid once the VTech team confirms your payment.</p>
       </div>
      </div>
     </section>

     <section id="support-view" class="view card">
      <div class="panel-head"><h2>Support centre</h2><span class="chip blue">Customer care</span></div>
      <div class="panel-body">
       <div class="mini">
        <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start">
         <div><h3 id="support-title">Message the Admin / Dispatcher team</h3><p id="support-sub" class="muted"></p></div>
         <span id="support-unread" class="chip slate">No new messages</span>
        </div>
        <div id="support-messages" class="notice loading" style="margin-top:13px;max-height:260px;overflow:auto" aria-live="polite">Loading conversation…</div>
        <form id="message-form" style="display:flex;gap:8px;margin-top:12px">
         <label for="support-message" class="hide">Message the Admin / Dispatcher team</label>
         <input id="support-message" required placeholder="Write a message…" autocomplete="off" enterkeyhint="send">
         <button class="btn btn-primary" type="submit" style="width:auto">Send</button>
        </form>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">
         <button id="request-call" class="btn btn-outline" type="button">Request a Call</button>
         <button id="call-admin" class="btn btn-teal" type="button">Call Admin</button>
        </div>
       </div>
       <div class="mini" style="margin-top:14px">
        <h3>Maintenance / repair</h3>
        <p class="muted">Report a CCTV issue, request preventative maintenance, or arrange a service follow-up.</p>
        <button id="support-maintenance" class="btn btn-soft" style="margin-top:10px">Request maintenance</button>
       </div>
       <div class="mini" style="margin-top:14px">
        <h3>Completion acknowledgement</h3>
        <p class="muted">Review and confirm completed work once your technician has submitted the service report.</p>
        <button id="support-signoff" class="btn btn-primary" style="margin-top:10px">Review &amp; Sign Off</button>
       </div>
      </div>
     </section>
    </main>
   </div>
  </div>

  <div id="account-drawer" class="drawer" aria-hidden="true">
   <div class="drawer-bg" data-close-account></div>
   <aside class="drawer-panel" aria-label="Your account">
    <div style="display:flex;justify-content:space-between;gap:10px">
     <div><div class="eyebrow">YOUR ACCOUNT</div><h2 id="account-title" style="margin-top:5px;font-size:21px">Account</h2></div>
     <button class="btn btn-outline" data-close-account type="button" aria-label="Close"><i data-lucide="x" width="18"></i></button>
    </div>
    <p id="account-info" class="muted" style="margin-top:8px"></p>
    <form id="pw-form" style="margin-top:20px">
     <h3>Change password</h3>
     <label for="pw-current" style="margin-top:10px">Current password</label><input id="pw-current" type="password" required autocomplete="current-password">
     <label for="pw-new" style="margin-top:12px">New password</label><input id="pw-new" type="password" required minlength="8" autocomplete="new-password">
     <label for="pw-new2" style="margin-top:12px">Confirm new password</label><input id="pw-new2" type="password" required minlength="8" autocomplete="new-password">
     <div id="pw-error" class="notice error hide" role="alert" style="margin-top:10px"></div>
     <button type="submit" class="btn btn-primary" style="margin-top:14px;width:100%">Update password</button>
    </form>
    <button id="signout-btn" type="button" class="btn btn-outline" style="margin-top:20px;width:100%">Sign out</button>
   </aside>
  </div>

  <div id="booking-drawer" class="drawer" aria-hidden="true">
   <div class="drawer-bg" data-close-booking></div>
   <aside class="drawer-panel" aria-label="Book a CCTV service">
    <div style="display:flex;justify-content:space-between;gap:10px">
     <div><div class="eyebrow">CUSTOMER PORTAL</div><h2 style="margin-top:5px;font-size:21px">Book a service</h2></div>
     <button class="btn btn-outline" data-close-booking type="button" aria-label="Close booking"><i data-lucide="x" width="18"></i></button>
    </div>
    <form id="booking-form" style="margin-top:22px">
     <label for="booking-service">Service type</label>
     <select id="booking-service"><option>Site survey</option><option>Installation &amp; configuration</option><option>Maintenance / repair</option></select>
     <label for="booking-site" style="margin-top:14px">Site</label>
     <select id="booking-site"></select>
     <div id="new-site-fields" class="form-grid hide" style="margin-top:10px">
      <div><label for="booking-new-site-name">New site name</label><input id="booking-new-site-name" placeholder="e.g. Branch office"></div>
      <div><label for="booking-new-site-address">New site address</label><input id="booking-new-site-address" placeholder="Street, city"></div>
      <div style="grid-column:1/-1">
       <label for="site-map-search">Pin the location on the map</label>
       <div style="display:flex;gap:8px;align-items:center">
        <input id="site-map-search" placeholder="Search a place or address" style="flex:1;min-width:0">
        <button type="button" id="site-map-find" class="btn btn-outline">Search</button>
        <button type="button" id="site-map-locate" class="btn btn-outline">My location</button>
       </div>
       <div id="site-map" style="height:240px;margin-top:8px;border-radius:10px;border:1px solid var(--line);isolation:isolate"></div>
       <p class="muted" style="margin:6px 0 0">Tap the map or drag the pin. The address above fills in automatically and you can still edit it.</p>
      </div>
     </div>
     <div class="form-grid" style="margin-top:14px">
      <div><label for="booking-date">Preferred date</label><input id="booking-date" type="date" required></div>
      <div><label for="booking-time">Service window</label><select id="booking-time"><option>09:00–11:00</option><option>11:00–13:00</option><option>14:00–16:00</option></select></div>
     </div>
     <label style="margin-top:14px">Camera types and quantities</label>
     <p class="muted" style="margin:4px 0 10px">Select one or more types and enter the quantity for each selected type.</p>
     <div id="booking-camera-types" style="display:grid;gap:8px">
      <div class="camera-type-row" style="display:grid;grid-template-columns:minmax(0,1fr) 110px;gap:12px;align-items:center">
       <label style="display:flex;align-items:center;gap:8px;margin:0"><input type="checkbox" class="booking-camera-type-check" value="Dome"> Dome</label>
       <input type="number" class="booking-camera-type-qty" data-camera-type="Dome" min="1" step="1" inputmode="numeric" placeholder="Qty" disabled aria-label="Number of Dome cameras">
      </div>
      <div class="camera-type-row" style="display:grid;grid-template-columns:minmax(0,1fr) 110px;gap:12px;align-items:center">
       <label style="display:flex;align-items:center;gap:8px;margin:0"><input type="checkbox" class="booking-camera-type-check" value="Bullet"> Bullet</label>
       <input type="number" class="booking-camera-type-qty" data-camera-type="Bullet" min="1" step="1" inputmode="numeric" placeholder="Qty" disabled aria-label="Number of Bullet cameras">
      </div>
      <div class="camera-type-row" style="display:grid;grid-template-columns:minmax(0,1fr) 110px;gap:12px;align-items:center">
       <label style="display:flex;align-items:center;gap:8px;margin:0"><input type="checkbox" class="booking-camera-type-check" value="PTZ"> PTZ</label>
       <input type="number" class="booking-camera-type-qty" data-camera-type="PTZ" min="1" step="1" inputmode="numeric" placeholder="Qty" disabled aria-label="Number of PTZ cameras">
      </div>
      <div class="camera-type-row" style="display:grid;grid-template-columns:minmax(0,1fr) 110px;gap:12px;align-items:center">
       <label style="display:flex;align-items:center;gap:8px;margin:0"><input type="checkbox" class="booking-camera-type-check" value="Turret"> Turret</label>
       <input type="number" class="booking-camera-type-qty" data-camera-type="Turret" min="1" step="1" inputmode="numeric" placeholder="Qty" disabled aria-label="Number of Turret cameras">
      </div>
      <div class="camera-type-row" style="display:grid;grid-template-columns:minmax(0,1fr) 110px;gap:12px;align-items:center">
       <label style="display:flex;align-items:center;gap:8px;margin:0"><input type="checkbox" class="booking-camera-type-check" value="Other"> Other</label>
       <input type="number" class="booking-camera-type-qty" data-camera-type="Other" min="1" step="1" inputmode="numeric" placeholder="Qty" disabled aria-label="Number of Other cameras">
      </div>
     </div>
     <div id="booking-camera-type-error" class="notice error hide" role="alert" style="margin-top:6px">Select at least one camera type and enter a positive whole-number quantity for each selected type.</div>
     <div id="booking-camera-total" class="muted" style="margin-top:8px" aria-live="polite">Total cameras: 0</div>
     <label for="booking-camera-brand" style="margin-top:14px">Camera brand</label>
     <select id="booking-camera-brand" required><option value="">Select a brand</option><option>Hikvision</option><option>Dahua</option><option>TP-Link</option><option>Axis</option><option>Uniview</option><option value="Other">Other</option></select>
     <div id="booking-camera-brand-error" class="notice error hide" role="alert" style="margin-top:6px">Select a camera brand.</div>
     <label for="booking-notes" style="margin-top:14px">Service details</label>
     <textarea id="booking-notes" rows="5" placeholder="Describe the service needed, access notes, or CCTV issue observed"></textarea>
     <div id="booking-summary" class="notice loading hide" style="margin-top:14px" aria-live="polite"></div>
     <button type="submit" class="btn btn-primary" style="margin-top:20px;width:100%">Confirm request</button>
    </form>
   </aside>
  </div>

  <div id="maintenance-drawer" class="drawer" aria-hidden="true">
   <div class="drawer-bg" data-close-maintenance></div>
   <aside class="drawer-panel" aria-label="Request CCTV maintenance">
    <div style="display:flex;justify-content:space-between;gap:10px">
     <div><div class="eyebrow">CUSTOMER SUPPORT</div><h2 style="margin-top:5px;font-size:21px">Request maintenance</h2></div>
     <button class="btn btn-outline" data-close-maintenance type="button" aria-label="Close maintenance request"><i data-lucide="x" width="18"></i></button>
    </div>
    <form id="maintenance-form" style="margin-top:22px">
     <label for="maintenance-site">Site</label><select id="maintenance-site"></select>
     <label for="maintenance-priority" style="margin-top:14px">Request priority</label>
     <select id="maintenance-priority"><option>Normal</option><option>High</option><option>Urgent</option></select>
     <label for="maintenance-notes" style="margin-top:14px">Describe the issue</label>
     <textarea id="maintenance-notes" rows="6" required placeholder="For example: camera offline, recording issue, damaged cable, or follow-up requirement"></textarea>
     <button type="submit" class="btn btn-teal" style="margin-top:18px;width:100%">Send maintenance request</button>
    </form>
   </aside>
  </div>

  <div id="signoff-drawer" class="drawer" aria-hidden="true">
   <div class="drawer-bg" data-close-signoff></div>
   <aside class="drawer-panel" aria-label="Review and sign off">
    <div style="display:flex;justify-content:space-between;gap:10px">
     <div><div class="eyebrow">SERVICE COMPLETION</div><h2 style="margin-top:5px;font-size:21px">Review &amp; Sign Off</h2></div>
     <button class="btn btn-outline" data-close-signoff type="button" aria-label="Close sign off"><i data-lucide="x" width="18"></i></button>
    </div>
    <div id="signoff-body" style="margin-top:18px"></div>
   </aside>
  </div>

  <div id="payment-drawer" class="drawer" aria-hidden="true">
   <div class="drawer-bg" data-close-payment></div>
   <aside class="drawer-panel" aria-label="Submit a payment">
    <div style="display:flex;justify-content:space-between;gap:10px">
     <div><div class="eyebrow">BILLING</div><h2 style="margin-top:5px;font-size:21px">Submit payment</h2></div>
     <button class="btn btn-outline" data-close-payment type="button" aria-label="Close payment"><i data-lucide="x" width="18"></i></button>
    </div>
    <div id="payment-body" style="margin-top:18px"></div>
   </aside>
  </div>

  <div id="call-drawer" class="drawer" aria-hidden="true">
   <div class="drawer-bg" data-close-call></div>
   <aside class="drawer-panel" aria-label="Request a call">
    <div style="display:flex;justify-content:space-between;gap:10px">
     <div><div class="eyebrow">CUSTOMER SUPPORT</div><h2 style="margin-top:5px;font-size:21px">Request a callback</h2></div>
     <button class="btn btn-outline" data-close-call type="button" aria-label="Close call request">×</button>
    </div>
    <form id="call-form" style="margin-top:22px">
     <label for="callback-time">Preferred callback time</label>
     <select id="callback-time"><option>Today, 10:00–12:00</option><option>Today, 14:00–16:00</option><option>Tomorrow, 09:00–11:00</option></select>
     <label for="callback-topic" style="margin-top:14px">Topic</label><input id="callback-topic" required placeholder="What can the team help with?">
     <div id="call-confirmation" class="notice success hide" style="margin-top:14px" aria-live="polite">Your callback request has been sent.</div>
     <div style="display:flex;gap:8px;margin-top:18px"><button class="btn btn-primary" type="submit">Send request</button><button data-close-call class="btn btn-outline" type="button">Cancel</button></div>
    </form>
   </aside>
  </div>
  <div id="toast" class="toast" role="status" aria-live="polite"></div>
  <script src="vtech-ui.js"></script>
  <script>
    /* ---------- helpers ---------- */
    const $ = s => document.querySelector(s);
    const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
    const money = v => new Intl.NumberFormat("en-PH",{style:"currency",currency:"PHP",minimumFractionDigits:0,maximumFractionDigits:2}).format(Number(v||0));
    const localToday = () => new Date(Date.now() - new Date().getTimezoneOffset()*60000).toISOString().slice(0,10);
    const fmtDate = d => d ? new Date(d + "T00:00:00").toLocaleDateString("en-PH",{day:"2-digit",month:"short",year:"numeric"}) : "";
    const fmtTime = t => t ? new Date(t).toLocaleString("en-PH",{month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"}) : "";
    const nowIso = () => new Date().toISOString();
    const rid = n => Array.from(crypto.getRandomValues(new Uint8Array(n))).map(b => "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[b % 32]).join("");
    const JOB_TYPES = ["appointment","maintenance_request","work_order"];
    const DONE = ["Completed","Cancelled","Signed Off"];

    let me = null;
    let backendRecords = [], loadTimer, currentView = "overview", loaded = false;
    const markingRead = new Set();

    /* ---------- derived data (everything comes from saved records) ---------- */
    const mine     = () => me ? backendRecords.filter(r => r.customer_id === me.customer_id) : [];
    const jobs     = () => mine().filter(r => JOB_TYPES.includes(r.record_type));
    const sites    = () => mine().filter(r => r.record_type === "site");
    const invoices = () => mine().filter(r => r.record_type === "invoice");
    const payments = () => mine().filter(r => r.record_type === "payment");
    const payMethods = () => backendRecords.filter(r => r.record_type === "payment_method" && r.status === "Active");
    const payFor = i => payments().filter(p => p.pay_invoice_id === i.__backendId).sort((a,b) => new Date(b.created_at) - new Date(a.created_at));
    let billFilter = "all";
    const isOverdue = i => i.status !== "Paid" && !!i.due_date && i.due_date < localToday();
    const daysOver = i => Math.max(1, Math.round((new Date(localToday() + "T00:00:00") - new Date(i.due_date + "T00:00:00")) / 864e5));
    function paidInfo(i) {
      const p = payFor(i).find(x => x.status === "Confirmed"), when = fmtTime((p && p.updated_at) || i.updated_at);
      return p ? `Paid ${when} via ${p.pay_method} · Ref ${p.pay_reference}` : `Marked paid by VTech${when ? " · " + when : ""}`;
    }
    // What the customer should see for an invoice: Paid / Payment submitted / Payment rejected / the invoice's own status.
    function invState(i) {
      if (i.status === "Paid") return "Paid";
      const last = payFor(i)[0];
      if (last && last.status === "Submitted") return "Payment submitted";
      if (last && last.status === "Rejected") return "Payment rejected";
      if (isOverdue(i)) return "Overdue";
      return i.status;
    }
    const messages = () => mine().filter(r => r.record_type === "message").sort((a,b) => new Date(a.msg_timestamp||a.created_at) - new Date(b.msg_timestamp||b.created_at));
    const admin    = () => backendRecords.find(r => r.record_type === "admin_profile") || null;
    const adminName = () => (admin() && admin().contact_name) || "Admin / Dispatcher";
    const jobTitle = j => j.job_title || j.title || "Service request";
    const signedOff = j => String(j.signature_status || "").startsWith("Customer signed off");
    const siteLabel = s => [s.title, s.site_address].filter(Boolean).join(" · ");

    function chip(status) {
      const s = status || "Open";
      const kind = ["Completed","Signed Off","Paid","Active"].includes(s) ? "teal"
        : ["Pending","Booked","Requested","Assigned","Unread","Payment submitted"].includes(s) ? "amber"
        : ["Urgent","Overdue","Cancelled","Payment rejected"].includes(s) ? "red" : "blue";
      return `<span class="chip ${kind}">${esc(s)}</span>`;
    }
    function toast(message, error = false) {
      const el = $("#toast");
      el.textContent = message;
      el.className = "toast show" + (error ? " error" : "");
      clearTimeout(el._timer);
      el._timer = setTimeout(() => el.className = "toast", error ? 7000 : 3600);
    }
    function setDrawer(id, open) {
      const d = $(id); d.classList.toggle("open", open); d.setAttribute("aria-hidden", String(!open));
    }
    function setSync(ok, text) {
      const el = $("#sync-status"); el.textContent = text || (ok ? "Synced" : "Sync issue"); el.className = "chip " + (ok ? "teal" : "amber");
    }

    /* ---------- rendering ---------- */
    function renderHeader() {
      const registered = !!me;
      $("#account-button").classList.toggle("hide", !registered);
      if (registered) {
        $("#account-name").textContent = me.contact_name;
        $("#topbar-name").textContent = me.customer_name;
        $("#welcome-title").textContent = "Welcome, " + me.contact_name.split(" ")[0];
        $("#customer-id-chip").textContent = "Customer ID: " + me.customer_id;
      } else {
        $("#welcome-title").textContent = "Welcome";
        $("#topbar-name").textContent = "VTech I.T Solution";
      }
    }

    function activeJob() {
      const list = jobs();
      return list.find(j => !DONE.includes(j.status)) || list.find(j => j.status === "Completed") || null;
    }

    function renderOverview() {
      const list = jobs(), job = activeJob();
      // hero
      let title = "Let’s secure your site", copy = "Book a site survey to get your CCTV project started.";
      if (job && signedOff(job)) { title = "Your service is complete"; copy = `${jobTitle(job)} has been signed off. Book another visit any time.`; }
      else if (job) { title = "Your security project is moving forward"; copy = `${jobTitle(job)} · ${job.status}${job.assigned_technician ? " · Technician: " + job.assigned_technician : " · awaiting technician assignment"}.`; }
      $("#hero-title").textContent = title; $("#hero-copy").textContent = copy;

      // workflow
      const steps = ["Appointment Booking","Site Survey","Installation & Configuration","Testing & Handover","Completion & Sign-off"];
      const map = {"Site Survey":1,"Installation & Configuration":2,"Testing & Handover":3,"Maintenance / Repair":2,"Completion Report":4,"Customer Sign-off":4};
      let idx = 0, allDone = false;
      if (job) { allDone = signedOff(job); idx = allDone ? 5 : (map[job.workflow_stage] ?? 1); }
      $("#workflow").innerHTML = steps.map((s,i) => `<span class="step ${i < idx ? "done" : i === idx ? "current" : ""}">${i < idx ? "✓ " : ""}${esc(s)}</span>`).join("");

      // upcoming appointment
      const today = localToday();
      const open = list.filter(j => !DONE.includes(j.status));
      open.sort((a,b) => (a.scheduled_date >= today ? 0 : 1) - (b.scheduled_date >= today ? 0 : 1) || String(a.scheduled_date||"9999").localeCompare(String(b.scheduled_date||"9999")));
      const up = open[0];
      $("#upcoming-appointment").innerHTML = up
        ? `<div class="appointment"><div style="display:flex;justify-content:space-between;gap:12px"><div><div class="eyebrow">NEXT SERVICE</div><h3 style="margin-top:5px">${esc(jobTitle(up))}</h3></div>${chip(up.status)}</div>
           <div class="appointment-info">
            <div><div class="data-label">Date &amp; time</div><div class="data-value">${esc(fmtDate(up.scheduled_date) || "Date pending")} · ${esc(up.scheduled_time || "Time pending")}</div></div>
            <div><div class="data-label">Assigned technician</div><div class="data-value">${esc(up.assigned_technician || "Awaiting assignment")}</div></div>
            <div><div class="data-label">Service site</div><div class="data-value">${esc(up.site_address || "Site pending")}</div></div>
            <div><div class="data-label">Priority</div><div class="data-value">${esc(up.priority || "Normal")}</div></div></div></div>`
        : `<div class="notice loading">No upcoming service. Use “Book a Service” to schedule your first visit.</div>`;

      // activity
      $("#activity-list").innerHTML = list.slice(0,5).map(j => `<div class="row"><div><div class="row-title">${esc(jobTitle(j))}</div><div class="muted">${esc(fmtDate(j.scheduled_date) || "Requested")} · ${esc(j.site_address || "Site pending")}</div></div>${chip(j.status)}</div>`).join("")
        || `<div class="notice loading">No service activity yet.</div>`;

      // overview documents / sites / invoices
      const docs = collectDocs();
      $("#docs-chip").textContent = docs.length + " ready";
      $("#overview-docs").innerHTML = docs.slice(0,3).map(docRow).join("") || `<div class="notice loading">Documents appear here once your technician submits reports or uploads files.</div>`;
      const ss = sites();
      $("#sites-chip").textContent = ss.length + (ss.length === 1 ? " site" : " sites");
      $("#overview-sites").innerHTML = ss.map(s => `<div class="row"><div><strong>${esc(s.title)}</strong><div class="muted">${esc(s.site_address)}</div></div></div>`).join("") || `<div class="notice loading">No sites yet.</div>`;
      const inv = invoices(), pend = inv.filter(i => i.status !== "Paid");
      $("#inv-chip").textContent = pend.length ? pend.length + " pending" : (inv.length ? "All paid" : "None");
      $("#inv-chip").className = "chip " + (pend.length ? "amber" : inv.length ? "teal" : "slate");
      $("#overview-invoices").innerHTML = inv.slice(0,2).map(i => invRow(i)).join("") || `<p class="muted">No invoices have been issued yet.</p>`;

      // sign-off state
      const eligible = signoffJobs();
      $("#signoff-state").innerHTML = eligible.length
        ? `<p class="muted">${eligible.length === 1 ? "A completion report is" : eligible.length + " completion reports are"} ready to review.</p><button id="open-signoff" class="btn btn-primary" style="margin-top:10px"><i data-lucide="badge-check" width="16"></i>Review &amp; Sign Off</button>`
        : `<p class="muted">Completion reports appear here when your technician finishes the work.</p>`;
      const b = $("#open-signoff"); if (b) b.addEventListener("click", openSignoff);
      lucide.createIcons();
    }

    function invRow(i, withAction, full) {
      const st = invState(i), last = payFor(i)[0];
      const canPay = withAction && i.status !== "Paid" && st !== "Payment submitted";
      let detail = "";
      if (st === "Paid") detail = `<div class="muted" style="color:#08776a">${esc(paidInfo(i))}</div>`;
      else if (st === "Payment submitted" && last) detail = `<div class="muted">Reference ${esc(last.pay_reference)} via ${esc(last.pay_method)} · waiting for confirmation</div>`;
      else if (st === "Payment rejected" && last) detail = `<div class="muted" style="color:#a22a3a">We couldn't confirm reference ${esc(last.pay_reference)}.${last.notes ? " " + esc(last.notes) : ""} Please check it and submit again, or contact support.</div>`;
      else if (st === "Overdue") detail = `<div class="muted" style="color:#a22a3a">Overdue by ${daysOver(i)} day${daysOver(i) === 1 ? "" : "s"}</div>`;
      const btn = "margin-top:6px;padding:6px 10px;font-size:12px";
      const actions = (canPay ? `<button type="button" class="btn btn-primary" style="${btn}" data-pay-invoice="${esc(i.__backendId)}">I've paid</button>` : "")
        + (full ? `<button type="button" class="btn btn-outline" style="${btn}" data-print-invoice="${esc(i.__backendId)}">${st === "Paid" ? "Receipt" : "View / print"}</button>` : "");
      return `<div class="row"><div><div class="row-title">${esc(i.title)}</div><div class="muted">${esc(i.notes || "")}${i.due_date ? " · Due " + esc(fmtDate(i.due_date)) : ""}</div>${detail}</div><div style="text-align:right"><strong>${money(i.amount)}</strong><br>${chip(st)}${actions ? `<div style="display:flex;gap:6px;justify-content:flex-end;flex-wrap:wrap">${actions}</div>` : ""}</div></div>`;
    }

    // Shows the invoice/receipt inside the app when pop-up windows aren't available (Android app, iPhone home-screen app).
    function showDocOverlay(html) {
      const box = document.createElement("div");
      box.style.cssText = "position:fixed;inset:0;z-index:2147483000;background:#fff;display:flex;flex-direction:column";
      const bar = document.createElement("div");
      bar.style.cssText = "padding:calc(8px + env(safe-area-inset-top,0px)) 12px 8px;background:#10253f;display:flex;justify-content:flex-end";
      const close = document.createElement("button");
      close.type = "button"; close.textContent = "Close";
      close.style.cssText = "font:600 14px system-ui,sans-serif;padding:8px 16px;border:0;border-radius:8px;background:#fff;color:#10253f;cursor:pointer";
      close.addEventListener("click", () => box.remove());
      bar.appendChild(close);
      const frame = document.createElement("iframe");
      frame.style.cssText = "flex:1;border:0;width:100%";
      frame.srcdoc = html.replace(/<button[^>]*>Print<\/button>/, "");
      box.append(bar, frame);
      document.body.appendChild(box);
    }
    function openInvoiceDoc(o) {

      const rows = o.rows.map(r => `<tr><th>${esc(r[0])}</th><td>${esc(r[1])}</td></tr>`).join("");
      const html = `<!doctype html><html><head><meta charset="utf-8"><title>${esc(o.title)}</title><style>
        body{font-family:Arial,Helvetica,sans-serif;color:#13233a;max-width:640px;margin:32px auto;padding:0 20px}
        h1{font-size:22px;margin:0}.sub{color:#5b6b80;font-size:13px;margin-top:4px}.tag{float:right;font-size:12px;font-weight:700;letter-spacing:.08em;padding:5px 10px;border-radius:6px;border:1px solid ${o.paid ? "#08776a" : "#9a6509"};color:${o.paid ? "#08776a" : "#9a6509"}}
        table{width:100%;border-collapse:collapse;margin-top:22px;font-size:14px}th,td{text-align:left;padding:10px 4px;border-bottom:1px solid #e3e9f0}th{width:34%;color:#5b6b80;font-weight:600}
        .total{margin-top:22px;padding:16px;background:#f2f6fa;border-radius:8px;display:flex;justify-content:space-between;font-size:17px;font-weight:700}
        .foot{margin-top:28px;color:#5b6b80;font-size:12px}@media print{button{display:none}}
      </style></head><body>
        <span class="tag">${o.paid ? "PAID" : "UNPAID"}</span>
        <h1>VTech I.T Solution</h1><div class="sub">${o.paid ? "Payment receipt" : "Invoice"} &middot; ${esc(o.title)}</div>
        <table>${rows}</table>
        <div class="total"><span>${o.paid ? "Amount paid" : "Amount due"}</span><span>${esc(money(o.amount))}</span></div>
        <p class="foot">${o.paid ? "Thank you for your payment." : "Pay using any option listed on the Billing page, then submit your reference number."}</p>
        <button onclick="window.print()" style="margin-top:14px;padding:8px 14px">Print</button>
      </body></html>`;
      const w = window.open("", "_blank");
      if (!w) { showDocOverlay(html); return; }
      w.document.write(html);
      w.document.close(); w.focus(); setTimeout(() => { try { w.print(); } catch (e) {} }, 350);
    }
    function printInvoice(i) {
      const paid = i.status === "Paid", who = (me && (me.customer_name || me.display_name)) || "";
      const issued = i.created_at ? new Date(i.created_at).toLocaleDateString("en-PH", {day:"2-digit", month:"short", year:"numeric"}) : "";
      const rows = [["Billed to", who], ["Invoice", i.title], ["Issued", issued], ["Due date", i.due_date ? fmtDate(i.due_date) : "—"]];
      if (i.notes) rows.push(["Description", i.notes]);
      rows.push(["Status", invState(i)]);
      if (paid) rows.push(["Payment", paidInfo(i)]);
      openInvoiceDoc({title: i.title, paid, amount: i.amount, rows});
    }
    async function copyText(text) {
      try { await navigator.clipboard.writeText(text); }
      catch (e) { const t = document.createElement("textarea"); t.value = text; document.body.appendChild(t); t.select(); try { document.execCommand("copy"); } catch (e2) {} t.remove(); }
      toast("Copied " + text);
    }
    function methodBlock(m) {
      const copy = m.pay_account_no ? ` <button type="button" class="btn btn-outline" style="padding:2px 8px;font-size:11px;margin-left:4px" data-copy="${esc(m.pay_account_no)}">Copy</button>` : "";
      return `<div class="row" style="align-items:flex-start"><div><div class="row-title">${esc(m.title)}</div><div class="muted">${m.contact_name ? "Account name: " + esc(m.contact_name) : ""}${m.pay_account_no ? (m.contact_name ? " · " : "") + "Number: <strong>" + esc(m.pay_account_no) + "</strong>" + copy : ""}</div>${m.notes ? `<div class="muted" style="white-space:pre-wrap">${esc(m.notes)}</div>` : ""}</div></div>`;
    }

    function collectDocs() {
      const out = [];
      jobs().forEach(j => {
        if (j.report_submitted) out.push({kind:"report", job:j});
        String(j.documents_uploaded || "").split("|").filter(x => x.includes("::")).forEach(entry => {
          const [name, stored] = entry.split("::");
          out.push({kind:"file", job:j, name, stored});
        });
      });
      return out;
    }
    function docRow(d) {
      if (d.kind === "file") return `<div class="row"><div><div class="row-title">${esc(d.name)}</div><div class="muted">${esc(jobTitle(d.job))} · uploaded by technician</div></div><a class="btn btn-outline" target="_blank" rel="noopener" href="download.php?f=${encodeURIComponent(d.stored)}">Open</a></div>`;
      const j = d.job;
      return `<div class="row" style="align-items:flex-start"><div style="min-width:0"><div class="row-title">Completion report · ${esc(jobTitle(j))}</div>
        <details class="muted" style="margin-top:4px"><summary style="cursor:pointer">View details</summary>
         <p style="margin-top:6px"><strong>Technician:</strong> ${esc(j.assigned_technician || "—")}</p>
         <p><strong>Equipment used:</strong> ${esc(j.equipment_used || "Not recorded")}</p>
         <p style="white-space:pre-wrap"><strong>Notes:</strong> ${esc(j.notes || "None")}</p>
         <p><strong>Last updated:</strong> ${esc(fmtTime(j.updated_at))}</p></details></div>${signedOff(j) ? chip("Signed Off") : chip("Pending")}</div>`;
    }

    function renderAppointments() {
      const list = jobs();
      $("#appointments-list").innerHTML = list.map(j => {
        const cancellable = ["Booked","Requested","Assigned"].includes(j.status);
        return `<div class="row"><div><div class="row-title">${esc(jobTitle(j))}</div><div class="muted">${esc(fmtDate(j.scheduled_date) || "Date pending")} · ${esc(j.scheduled_time || "Time pending")} · ${esc(j.site_address || "Site pending")}</div><div class="muted">Technician: ${esc(j.assigned_technician || "awaiting assignment")}${j.job_id ? " · " + esc(j.job_id) : ""}</div></div><div style="display:flex;gap:8px;align-items:center">${chip(j.status)}${cancellable ? `<button class="btn btn-outline" data-cancel="${esc(j.__backendId)}" type="button">Cancel</button>` : ""}</div></div>`;
      }).join("") || `<div class="notice loading">No appointments yet. Use “Book a Service” to request one.</div>`;
    }

    function renderSites() {
      $("#sites-list").innerHTML = sites().map(s => `<div class="row"><div><strong>${esc(s.title)}</strong><div class="muted">${esc(s.site_address)}</div></div><span class="chip teal">Active</span></div>`).join("") || `<div class="notice loading">No sites registered yet.</div>`;
    }
    function renderDocuments() {
      $("#documents-list").innerHTML = collectDocs().map(docRow).join("") || `<div class="notice loading">No documents yet. Reports and files from your technician will appear here.</div>`;
    }
    function renderBilling() {
      const inv = invoices(), unpaid = inv.filter(i => i.status !== "Paid"), paid = inv.filter(i => i.status === "Paid"), over = unpaid.filter(isOverdue);
      const sum = l => l.reduce((s, i) => s + Number(i.amount || 0), 0);
      $("#billing-chip").textContent = inv.length ? "Outstanding " + money(sum(unpaid)) : "No invoices";
      $("#billing-chip").className = "chip " + (over.length ? "red" : sum(unpaid) > 0 ? "amber" : "slate");
      const card = (l, v, s, col) => `<div class="mini"><div class="muted">${l}</div><div style="font-size:21px;font-weight:800;margin-top:4px${col ? ";color:" + col : ""}">${v}</div><div class="muted" style="margin-top:2px">${s}</div></div>`;
      $("#billing-summary").innerHTML = inv.length
        ? card("Outstanding", money(sum(unpaid)), unpaid.length ? unpaid.length + " unpaid invoice" + (unpaid.length === 1 ? "" : "s") : "All settled")
          + card("Overdue", money(sum(over)), over.length ? over.length + " past due" : "Nothing overdue", over.length ? "#a22a3a" : "")
          + card("Paid to date", money(sum(paid)), paid.length + " paid invoice" + (paid.length === 1 ? "" : "s"), paid.length ? "#08776a" : "")
        : "";
      const tabs = [["all", "All", inv.length], ["unpaid", "Unpaid", unpaid.length], ["paid", "Paid", paid.length]];
      $("#billing-filter").innerHTML = inv.length ? tabs.map(t => `<button type="button" class="portal-tab${billFilter === t[0] ? " active" : ""}" data-bill-filter="${t[0]}">${t[1]} (${t[2]})</button>`).join("") : "";
      const pm = payMethods();
      $("#pay-methods").innerHTML = pm.map(methodBlock).join("") || `<p class="muted">Payment options haven't been set up yet. Please contact support to arrange payment.</p>`;
      const stamp = i => new Date(i.updated_at || i.created_at).getTime() || 0;
      const shown = (billFilter === "unpaid" ? unpaid : billFilter === "paid" ? paid : inv).slice().sort((a, b) => {
        const pa = a.status === "Paid", pb = b.status === "Paid";
        if (pa !== pb) return pa ? 1 : -1;
        if (pa) return stamp(b) - stamp(a);
        return (a.due_date || "9999").localeCompare(b.due_date || "9999");
      });
      $("#billing-list").innerHTML = shown.map(i => invRow(i, pm.length > 0, true)).join("")
        || `<div class="notice loading">${inv.length ? "No " + billFilter + " invoices." : "No invoices have been issued to you yet."}</div>`;
    }

    function renderSupport() {
      const msgs = messages(), box = $("#support-messages"), ap = admin();
      $("#support-title").textContent = "Message " + adminName();
      $("#support-sub").textContent = ap && ap.phone ? "Phone: " + ap.phone : "Admin / Dispatcher team";
      const unread = msgs.filter(m => m.role === "admin" && m.status === "Unread").length;
      $("#support-unread").textContent = unread ? unread + " unread" : "No new messages";
      $("#support-unread").className = "chip " + (unread ? "red" : "slate");
      const atBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 40;
      box.className = msgs.length ? "" : "notice loading";
      box.style.cssText = "margin-top:13px;max-height:340px;overflow:auto";
      box.innerHTML = msgs.length ? msgs.map(m => { const mine = m.role === "customer"; return `<div class="chat-name ${mine ? "me" : ""}">${mine ? "You" : esc(m.msg_sender || adminName())}</div><div class="bubble ${mine ? "me" : ""}">${esc(m.msg_text || m.notes)}<span class="bubble-meta">${esc(fmtTime(m.msg_timestamp || m.created_at))}</span></div>`; }).join("") : "No messages yet. Write below to start a conversation with the team.";
      if (atBottom) box.scrollTop = box.scrollHeight;
      markAdminRead();
    }
    function markAdminRead() {
      if (currentView !== "support") return;
      messages().filter(m => m.role === "admin" && m.status === "Unread" && !markingRead.has(m.__backendId)).forEach(m => {
        markingRead.add(m.__backendId);
        window.dataSdk.update({...m, status:"Read", updated_at: nowIso()}).then(r => { if (!r.isOk) markingRead.delete(m.__backendId); });
      });
    }

    function notifications() {
      const items = [];
      jobs().forEach(j => {
        if (j.assigned_technician && ["Assigned","Booked"].includes(j.status)) items.push({t:"Technician assigned", d:`${j.assigned_technician} will handle “${jobTitle(j)}”${j.scheduled_date ? " on " + fmtDate(j.scheduled_date) : ""}.`, c:"blue", l:"Assigned"});
        if (j.status === "In progress") items.push({t:"Work in progress", d:`${j.assigned_technician || "Your technician"} is working on “${jobTitle(j)}”.`, c:"blue", l:"Live"});
        if (j.report_submitted && !signedOff(j)) items.push({t:"Completion report ready", d:`Review “${jobTitle(j)}” and confirm the sign-off.`, c:"teal", l:"Action"});
      });
      invoices().filter(i => invState(i) !== "Paid" && invState(i) !== "Payment submitted").forEach(i => items.push({t:"Invoice awaiting payment", d:`${i.title} · ${money(i.amount)}${i.due_date ? " · due " + fmtDate(i.due_date) : ""}`, c:"amber", l:"Billing"}));
      const un = messages().filter(m => m.role === "admin" && m.status === "Unread").length;
      if (un) items.push({t:"New message", d:`You have ${un} unread message${un === 1 ? "" : "s"} from ${adminName()}.`, c:"red", l:"Support"});
      return items;
    }
    function renderNotifications() {
      const items = notifications();
      const badge = $("#notif-count"); badge.textContent = items.length; badge.classList.toggle("hide", !items.length);
      $("#notification-body").innerHTML = items.map(n => `<div class="row"><div><div class="row-title">${esc(n.t)}</div><div class="muted">${esc(n.d)}</div></div><span class="chip ${n.c}">${esc(n.l)}</span></div>`).join("") || `<div class="notice loading">You’re all caught up.</div>`;
    }

    /* ---------- map picker for a new site (OpenStreetMap + Leaflet, no API key) ---------- */
    let siteMap = null, siteMarker = null, pinLookupId = 0, sitePin = null; // sitePin = exact {lat,lng} chosen on the map
    const NOMINATIM = "https://nominatim.openstreetmap.org";
    function ensureSiteMap() {
      const el = $("#site-map");
      if (!window.L) { if (!el.dataset.failed) { el.dataset.failed = "1"; el.innerHTML = '<div class="notice loading" style="margin:10px">The map could not load. Type the address instead.</div>'; } return; }
      if (!siteMap) {
        siteMap = L.map(el).setView([14.1, 121.3], 9);
        L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {maxZoom: 19, attribution: "&copy; OpenStreetMap contributors"}).addTo(siteMap);
        siteMap.on("click", e => setSitePin(e.latlng.lat, e.latlng.lng, true));
      }
      setTimeout(() => siteMap.invalidateSize(), 300);
    }
    function setNewSiteVisible(show) {
      $("#new-site-fields").classList.toggle("hide", !show);
      if (show) ensureSiteMap();
    }
    async function setSitePin(lat, lng, lookup) {
      if (!siteMap) return;
      sitePin = {lat: +lat.toFixed(7), lng: +lng.toFixed(7)};
      if (!siteMarker) {
        siteMarker = L.marker([lat, lng], {draggable: true}).addTo(siteMap);
        siteMarker.on("dragend", () => { const p = siteMarker.getLatLng(); setSitePin(p.lat, p.lng, true); });
      } else siteMarker.setLatLng([lat, lng]);
      if (!lookup) return;
      const addr = $("#booking-new-site-address"), my = ++pinLookupId, coords = lat.toFixed(6) + ", " + lng.toFixed(6);
      addr.placeholder = "Looking up address…";
      try {
        const res = await fetch(`${NOMINATIM}/reverse?format=jsonv2&zoom=18&accept-language=en&lat=${lat}&lon=${lng}`);
        const d = await res.json();
        if (my === pinLookupId) addr.value = d.display_name || coords;
      } catch (e) { if (my === pinLookupId) addr.value = coords; }
      addr.placeholder = "Street, city";
    }
    async function searchSite() {
      const q = $("#site-map-search").value.trim();
      if (!q || !siteMap) return;
      try {
        const res = await fetch(`${NOMINATIM}/search?format=jsonv2&limit=1&countrycodes=ph&accept-language=en&q=${encodeURIComponent(q)}`);
        const list = await res.json();
        if (!list.length) return toast("No match found. Try a nearby landmark, or tap the map.", true);
        const lat = parseFloat(list[0].lat), lng = parseFloat(list[0].lon);
        siteMap.setView([lat, lng], 17); setSitePin(lat, lng, false);
        $("#booking-new-site-address").value = list[0].display_name;
      } catch (e) { toast("Search is unavailable right now. Tap the map instead.", true); }
    }
    function locateSite() {
      if (!siteMap) return;
      if (!navigator.geolocation) return toast("Your browser can't share its location.", true);
      navigator.geolocation.getCurrentPosition(
        p => { siteMap.setView([p.coords.latitude, p.coords.longitude], 17); setSitePin(p.coords.latitude, p.coords.longitude, true); },
        () => toast("Could not get your location. Allow location access, or tap the map.", true),
        {enableHighAccuracy: true, timeout: 10000});
    }
    function fillSiteSelects() {
      const ss = sites();
      const opts = ss.map(s => `<option value="${esc(s.__backendId)}">${esc(siteLabel(s))}</option>`).join("");
      const book = $("#booking-site"), prevB = book.value;
      book.innerHTML = opts + `<option value="__new">+ Add a new site…</option>`;
      if ([...book.options].some(o => o.value === prevB)) book.value = prevB;
      setNewSiteVisible(book.value === "__new");
      const mt = $("#maintenance-site"), prevM = mt.value;
      mt.innerHTML = opts || `<option value="">No site registered</option>`;
      if ([...mt.options].some(o => o.value === prevM)) mt.value = prevM;
    }

    function renderAll() {
      renderHeader();
      if (!me) return;
      renderOverview(); renderAppointments(); renderSites(); renderDocuments(); renderBilling(); renderSupport(); renderNotifications(); fillSiteSelects();
      if ($("#signoff-drawer").classList.contains("open")) renderSignoffBody();
    }

    function switchView(name) {
      currentView = name;
      document.querySelectorAll(".view").forEach(v => v.classList.toggle("active", v.id === `${name}-view`));
      document.querySelectorAll("[data-view]").forEach(b => b.classList.toggle("active", b.dataset.view === name));
      if (name === "support") { renderSupport(); const box = $("#support-messages"); box.scrollTop = box.scrollHeight; }
    }

    /* ---------- saving ---------- */
    async function save(record, control, success) {
      if (control) control.disabled = true;
      try {
        const r = await window.dataSdk.create({...record, created_at: nowIso()});
        if (!r.isOk) { toast(r.error ? "Could not save: " + r.error : "Could not save. Please try again.", true); return false; }
        toast(success); window.dataSdk.refresh && window.dataSdk.refresh(); return true;
      } catch (e) { toast("Could not save this request.", true); return false; }
      finally { if (control) control.disabled = false; }
    }
    const base = () => ({customer_id: me.customer_id, customer_name: me.customer_name, contact_name: me.contact_name, phone: me.phone, email: me.email, role: "customer"});

    /* ---------- account ---------- */
    function applyUser(u) {
      me = {customer_id:u.customer_id, customer_name:u.customer_name, contact_name:u.contact_name || u.display_name, phone:u.phone || "", email:u.email || "", username:u.username};
      renderHeader();
      initializeData();
    }
    async function boot() {
      window.dataSdk.onUnauthorized = () => location.replace("index.php");
      const r = await window.auth.me();
      if (r.user && r.user.role === "customer") applyUser(r.user);
      else location.replace("index.php");
    }
    function showErr(sel, msg) { const el = $(sel); el.textContent = msg; el.classList.remove("hide"); }

    /* ---------- sign-off ---------- */
    const signoffJobs = () => jobs().filter(j => j.report_submitted && !signedOff(j));
    function renderSignoffBody() {
      const list = signoffJobs(), el = $("#signoff-body"), prev = $("#signoff-job") ? $("#signoff-job").value : "";
      if (!list.length) { el.innerHTML = `<div class="notice loading">No completion reports are waiting for your sign-off. Your technician will submit one when the work is done.</div>`; return; }
      const keepNote = $("#signoff-notes") ? $("#signoff-notes").value : "";
      el.innerHTML = `<form id="signoff-form"><label for="signoff-job">Service to sign off</label>
        <select id="signoff-job">${list.map(j => `<option value="${esc(j.__backendId)}">${esc(jobTitle(j))} · ${esc(j.site_address || "")}</option>`).join("")}</select>
        <div id="signoff-summary" class="notice success" style="margin-top:12px"></div>
        <label for="signoff-notes" style="margin-top:14px">Optional acknowledgement note</label><textarea id="signoff-notes" rows="4" placeholder="Add any notes for the service team"></textarea>
        <button type="submit" class="btn btn-primary" style="margin-top:16px;width:100%">Confirm service sign-off</button></form>`;
      const sel = $("#signoff-job"); if ([...sel.options].some(o => o.value === prev)) sel.value = prev; $("#signoff-notes").value = keepNote;
      const showSummary = () => { const j = list.find(x => x.__backendId === sel.value); $("#signoff-summary").innerHTML = `<strong>${esc(jobTitle(j))}</strong><br>Technician: ${esc(j.assigned_technician || "—")}<br>Equipment: ${esc(j.equipment_used || "Not recorded")}<br><span style="white-space:pre-wrap">${esc(j.notes || "")}</span>`; };
      sel.addEventListener("change", showSummary); showSummary();
      $("#signoff-form").addEventListener("submit", async ev => {
        ev.preventDefault();
        const j = list.find(x => x.__backendId === sel.value), btn = ev.submitter, note = $("#signoff-notes").value.trim();
        btn.disabled = true;
        const upd = await window.dataSdk.update({...j, signature_status: "Customer signed off on " + new Date().toLocaleDateString("en-PH"), workflow_stage: "Customer Sign-off", updated_at: nowIso()});
        if (!upd.isOk) { toast("Could not record the sign-off. Please try again.", true); btn.disabled = false; return; }
        await window.dataSdk.create({...base(), record_type:"sign_off", title:"Customer sign-off · " + jobTitle(j), status:"Signed Off", site_address:j.site_address, assigned_technician:j.assigned_technician, job_id:j.job_id, notes: note || "Customer confirmed completed service and handover.", created_at: nowIso()});
        toast("Sign-off recorded. Thank you!"); setDrawer("#signoff-drawer", false); window.dataSdk.refresh();
      });
    }
    function openSignoff() { renderSignoffBody(); setDrawer("#signoff-drawer", true); }

    /* ---------- payments ---------- */
    function openPayment(invoiceId) {
      const inv = invoices().find(i => i.__backendId === invoiceId), pm = payMethods(), el = $("#payment-body");
      if (!inv || !pm.length) { toast("Payment options aren't available yet.", true); return; }
      el.innerHTML = `<form id="payment-form"><div class="notice success"><strong>${esc(inv.title)}</strong><br>Amount to pay: <strong>${money(inv.amount)}</strong></div>
        <label for="pay-method" style="margin-top:14px">Payment method used</label>
        <select id="pay-method">${pm.map(m => `<option value="${esc(m.__backendId)}">${esc(m.title)}</option>`).join("")}</select>
        <div id="pay-method-info" class="mini" style="margin-top:10px"></div>
        <label for="pay-ref" style="margin-top:14px">Reference number</label>
        <input id="pay-ref" required minlength="4" maxlength="60" autocomplete="off" placeholder="e.g. GCash reference or bank transaction number">
        <label for="pay-file" style="margin-top:14px">Screenshot or receipt <span id="pay-file-req" class="muted"></span></label>
        <input id="pay-file" type="file" accept="image/jpeg,image/png,image/webp,application/pdf">
        <div id="pay-preview" style="margin-top:8px"></div>
        <label for="pay-notes" style="margin-top:14px">Note (optional)</label>
        <textarea id="pay-notes" rows="3" maxlength="500" placeholder="Date and time paid, sender name, anything that helps us match it"></textarea>
        <button type="submit" class="btn btn-primary" style="margin-top:16px;width:100%">Submit payment for confirmation</button></form>`;
      const sel = $("#pay-method");
      const isCash = () => ((pm.find(x => x.__backendId === sel.value) || {}).pay_method === "Cash");
      const showInfo = () => { const m = pm.find(x => x.__backendId === sel.value); $("#pay-method-info").innerHTML = methodBlock(m); $("#pay-file-req").textContent = isCash() ? "(optional for cash)" : "(required: JPG, PNG, WEBP or PDF, up to 8 MB)"; };
      sel.addEventListener("change", showInfo); showInfo();
      $("#pay-file").addEventListener("change", ev => {
        const f = ev.target.files[0], box = $("#pay-preview"); box.innerHTML = "";
        if (!f) return;
        if (f.size > 8 * 1024 * 1024) { toast("That file is larger than 8 MB.", true); ev.target.value = ""; return; }
        if (f.type.startsWith("image/")) { const img = document.createElement("img"); img.src = URL.createObjectURL(f); img.alt = "Receipt preview"; img.style.cssText = "max-width:100%;max-height:220px;border-radius:10px;border:1px solid var(--line)"; box.appendChild(img); }
        else box.innerHTML = `<div class="muted">${esc(f.name)}</div>`;
      });
      $("#payment-form").addEventListener("submit", async ev => {
        ev.preventDefault();
        const btn = ev.submitter, ref = $("#pay-ref").value.trim();
        if (ref.length < 4) return toast("Enter the reference number from your payment.", true);
        const file = $("#pay-file").files[0];
        if (!file && !isCash()) return toast("Attach a screenshot or photo of your payment receipt.", true);
        btn.disabled = true; const label = btn.textContent;
        let doc = "";
        if (file) {
          btn.textContent = "Uploading receipt…";
          const up = await window.dataSdk.upload(file);
          if (!up.isOk) { btn.disabled = false; btn.textContent = label; toast(up.error ? "Upload failed: " + up.error : "Could not upload the receipt. Please try again.", true); return; }
          doc = up.name + "::" + up.stored;
        }
        btn.textContent = label;
        const r = await window.dataSdk.create({record_type:"payment", pay_invoice_id: inv.__backendId, pay_account_id: sel.value, pay_reference: ref, documents_uploaded: doc, notes: $("#pay-notes").value.trim(), created_at: nowIso()});
        btn.disabled = false;
        if (!r.isOk) { toast(r.error ? "Could not submit: " + r.error : "Could not submit. Please try again.", true); return; }
        toast("Payment submitted. We'll confirm it shortly."); setDrawer("#payment-drawer", false); window.dataSdk.refresh && window.dataSdk.refresh();
      });
      setDrawer("#payment-drawer", true);
    }

    /* ---------- data loading ---------- */
    const handler = {
      onDataChanged(data) {
        clearTimeout(loadTimer); backendRecords = data; loaded = true; setSync(true); renderAll();
      }
    };
    async function initializeData() {
      loadTimer = setTimeout(() => { setSync(false); toast("Could not load your data. Check your connection, then refresh the page.", true); }, 8000);
      try {
        const r = await window.dataSdk.init(handler);
        if (!r.isOk) { clearTimeout(loadTimer); setSync(false); toast("Could not connect to the database.", true); }
      } catch (e) { clearTimeout(loadTimer); setSync(false); }
    }

    document.addEventListener("DOMContentLoaded", () => {
      lucide.createIcons();
      $("#booking-date").min = localToday();
      const skel = '<div class="vui-skel" aria-hidden="true"><i></i><i></i><i></i></div>';
      ["#upcoming-appointment","#activity-list","#overview-docs","#overview-sites","#overview-invoices","#appointments-list","#documents-list","#billing-list"].forEach(s => { const el = $(s); if (el && !el.innerHTML.trim()) { el.innerHTML = skel; el.setAttribute("aria-busy","true"); } });
      renderHeader();
      boot();

      document.addEventListener("click", e => {
        const v = e.target.closest("[data-view]"); if (v) switchView(v.dataset.view);
        const c = e.target.closest("[data-cancel]");
        if (c) VUI.ask({title:"Cancel this request?", message:"The VTech team will be told it was cancelled. You can book again at any time.", confirmLabel:"Cancel request", cancelLabel:"Keep it", danger:true}).then(a => {
          if (!a.ok) return;
          const j = backendRecords.find(r => r.__backendId === c.dataset.cancel);
          if (j) window.dataSdk.update({...j, status:"Cancelled", updated_at: nowIso()}).then(r => { toast(r.isOk ? "Request cancelled." : "Could not cancel the request. Try again.", !r.isOk); window.dataSdk.refresh(); });
        });
      });
      $("#notification-button").addEventListener("click", () => { const p = $("#notification-panel"); p.classList.toggle("hide"); $("#notification-button").setAttribute("aria-expanded", String(!p.classList.contains("hide"))); });
      $("#close-notifications").addEventListener("click", () => $("#notification-panel").classList.add("hide"));
      $("#account-button").addEventListener("click", () => {
        $("#account-title").textContent = me.contact_name;
        $("#account-info").textContent = "Signed in as " + me.username + " · Customer ID " + me.customer_id;
        setDrawer("#account-drawer", true);
      });
      document.querySelectorAll("[data-close-account]").forEach(b => b.addEventListener("click", () => setDrawer("#account-drawer", false)));
      $("#signout-btn").addEventListener("click", async () => { window.dataSdk.stop(); await window.auth.logout(); location.replace("index.php"); });
      $("#pw-form").addEventListener("submit", async ev => {
        ev.preventDefault(); $("#pw-error").classList.add("hide");
        if ($("#pw-new").value !== $("#pw-new2").value) return showErr("#pw-error", "The new passwords do not match.");
        const btn = ev.submitter; btn.disabled = true;
        const r = await window.auth.changePassword($("#pw-current").value, $("#pw-new").value);
        btn.disabled = false;
        if (!r.isOk) return showErr("#pw-error", r.error || "Could not change the password.");
        ev.target.reset(); setDrawer("#account-drawer", false); toast("Password updated.");
      });

      /* drawers */
      const wire = (openers, drawer, closeAttr, before) => {
        openers.forEach(sel => { const el = $(sel); if (el) el.addEventListener("click", () => { if (!me) return; if (before) before(); setDrawer(drawer, true); }); });
        document.querySelectorAll(`[${closeAttr}]`).forEach(b => b.addEventListener("click", () => setDrawer(drawer, false)));
      };
      wire(["#open-booking","#appointments-book"], "#booking-drawer", "data-close-booking", fillSiteSelects);
      wire(["#open-maintenance","#support-maintenance"], "#maintenance-drawer", "data-close-maintenance", fillSiteSelects);
      wire(["#request-call"], "#call-drawer", "data-close-call");
      document.querySelectorAll("[data-close-payment]").forEach(b => b.addEventListener("click", () => setDrawer("#payment-drawer", false)));
      $("#billing-list").addEventListener("click", ev => { const b = ev.target.closest("[data-pay-invoice]"); if (b) openPayment(b.dataset.payInvoice); });
      $("#billing-view").addEventListener("click", ev => {
        const f = ev.target.closest("[data-bill-filter]"); if (f) { billFilter = f.dataset.billFilter; renderBilling(); return; }
        const p = ev.target.closest("[data-print-invoice]"); if (p) { const i = invoices().find(x => x.__backendId === p.dataset.printInvoice); if (i) printInvoice(i); return; }
      });
      document.addEventListener("click", ev => { const b = ev.target.closest("[data-copy]"); if (b) copyText(b.dataset.copy); });
      document.querySelectorAll("[data-close-signoff]").forEach(b => b.addEventListener("click", () => setDrawer("#signoff-drawer", false)));
      $("#support-signoff").addEventListener("click", openSignoff);
      $("#booking-site").addEventListener("change", () => setNewSiteVisible($("#booking-site").value === "__new"));
      $("#site-map-find").addEventListener("click", searchSite);
      $("#site-map-locate").addEventListener("click", locateSite);
      $("#site-map-search").addEventListener("keydown", ev => { if (ev.key === "Enter") { ev.preventDefault(); searchSite(); } });
      $("#booking-form").addEventListener("reset", () => { if (siteMarker && siteMap) { siteMap.removeLayer(siteMarker); siteMarker = null; } sitePin = null; });

      /* sites */
      $("#site-form").addEventListener("submit", async ev => {
        ev.preventDefault();
        const ok = await save({...base(), record_type:"site", title:$("#site-name").value.trim(), site_address:$("#site-address").value.trim(), status:"Active"}, ev.submitter, "Site saved.");
        if (ok) ev.target.reset();
      });

      /* messaging */
      $("#message-form").addEventListener("submit", async ev => {
        ev.preventDefault();
        const text = $("#support-message").value.trim(); if (!text) return;
        const ok = await save({...base(), record_type:"message", title:"Support conversation", thread_id:"customer:" + me.customer_id, msg_sender: me.contact_name, msg_text: text, msg_timestamp: nowIso(), msg_type:"message", status:"Unread"}, ev.submitter, "Message sent.");
        if (ok) $("#support-message").value = "";
      });
      $("#call-admin").addEventListener("click", () => {
        const ap = admin();
        if (ap && ap.phone) window.location.href = "tel:" + ap.phone.replace(/[^+\d]/g, "");
        else toast("The admin hasn’t added a phone number yet. Send a message or request a callback instead.");
      });
      $("#call-form").addEventListener("submit", async ev => {
        ev.preventDefault();
        const ok = await save({...base(), record_type:"callback_request", title:"Callback request · " + me.contact_name, status:"Requested", thread_id:"customer:" + me.customer_id, scheduled_time:$("#callback-time").value, notes:$("#callback-topic").value.trim()}, ev.submitter, "Callback request sent.");
        if (ok) { $("#call-confirmation").classList.remove("hide"); setTimeout(() => { setDrawer("#call-drawer", false); $("#call-confirmation").classList.add("hide"); ev.target.reset(); }, 900); }
      });

      /* booking camera type quantities */
      const updateCameraTotal = () => {
        let total = 0;
        document.querySelectorAll(".booking-camera-type-check").forEach(check => {
          const qtyInput = document.querySelector('.booking-camera-type-qty[data-camera-type="' + check.value + '"]');
          qtyInput.disabled = !check.checked;
          qtyInput.required = check.checked;
          if (!check.checked) qtyInput.value = "";
          else {
            const qty = Number(qtyInput.value);
            if (Number.isInteger(qty) && qty > 0) total += qty;
          }
        });
        $("#booking-camera-total").textContent = "Total cameras: " + total;
      };
      document.querySelectorAll(".booking-camera-type-check").forEach(check => check.addEventListener("change", updateCameraTotal));
      document.querySelectorAll(".booking-camera-type-qty").forEach(input => input.addEventListener("input", updateCameraTotal));
      $("#booking-form").addEventListener("reset", () => setTimeout(updateCameraTotal, 0));

      /* booking */
      $("#booking-form").addEventListener("submit", async ev => {
        ev.preventDefault();
        const btn = ev.submitter, brand = $("#booking-camera-brand").value;
        const cameraTypes = {};
        let cameraTypeValid = true;
        document.querySelectorAll(".booking-camera-type-check").forEach(check => {
          const qtyInput = document.querySelector('.booking-camera-type-qty[data-camera-type="' + check.value + '"]');
          qtyInput.disabled = !check.checked;
          if (check.checked) {
            const qty = Number(qtyInput.value);
            if (!Number.isInteger(qty) || qty < 1) cameraTypeValid = false;
            else cameraTypes[check.value] = qty;
          }
        });
        const n = Object.values(cameraTypes).reduce((sum, qty) => sum + qty, 0);
        const selectedTypeCount = Object.keys(cameraTypes).length;
        cameraTypeValid = cameraTypeValid && selectedTypeCount > 0;
        $("#booking-camera-brand-error").classList.toggle("hide", !!brand);
        $("#booking-camera-type-error").classList.toggle("hide", cameraTypeValid);
        if (!cameraTypeValid || !brand) return toast("Please select at least one camera type, enter its quantity, and choose a brand.", true);
        const typeSummary = Object.entries(cameraTypes).map(([name, qty]) => name + ": " + qty).join(", ");
        let siteText = "", pin = {};
        btn.disabled = true;
        if ($("#booking-site").value === "__new") {
          const nm = $("#booking-new-site-name").value.trim(), ad = $("#booking-new-site-address").value.trim();
          if (!nm || !ad) { btn.disabled = false; return toast("Enter the new site’s name and address.", true); }
          pin = sitePin ? {site_lat: sitePin.lat, site_lng: sitePin.lng} : {};
          const r = await window.dataSdk.create({...base(), record_type:"site", title:nm, site_address:ad, status:"Active", ...pin, created_at: nowIso()});
          if (!r.isOk) { btn.disabled = false; return toast("Could not save the new site.", true); }
          siteText = nm + " · " + ad;
        } else {
          const s = sites().find(x => x.__backendId === $("#booking-site").value);
          if (!s) { btn.disabled = false; return toast("Choose a site for this visit.", true); }
          siteText = siteLabel(s);
          if (s.site_lat != null && s.site_lng != null) pin = {site_lat: s.site_lat, site_lng: s.site_lng};
        }
        const service = $("#booking-service").value, id = "JOB-" + rid(5);
        const ok = await save({...base(), record_type:"appointment", title:service, job_title:service, service_type:service, job_id:id, status:"Booked", assigned_technician:"", site_address:siteText, ...pin,
          scheduled_date:$("#booking-date").value, scheduled_time:$("#booking-time").value, priority:"Normal",
          notes:`Cameras: ${n}; Brand: ${brand}; Types: ${typeSummary}.` + ($("#booking-notes").value.trim() ? " " + $("#booking-notes").value.trim() : "")}, btn,
          `Request saved: ${n} camera${n === 1 ? "" : "s"} · ${brand} · ${typeSummary}.`);
        btn.disabled = false;
        if (ok) { ev.target.reset(); $("#new-site-fields").classList.add("hide"); setDrawer("#booking-drawer", false); switchView("appointments"); }
      });

      /* maintenance */
      $("#maintenance-form").addEventListener("submit", async ev => {
        ev.preventDefault();
        const s = sites().find(x => x.__backendId === $("#maintenance-site").value);
        if (!s) return toast("Register a site first (Sites tab).", true);
        const ok = await save({...base(), record_type:"maintenance_request", title:"Maintenance / repair", job_title:"Maintenance / repair", service_type:"Maintenance / repair", job_id:"JOB-" + rid(5), status:"Requested", site_address:siteLabel(s), ...(s.site_lat != null && s.site_lng != null ? {site_lat:s.site_lat, site_lng:s.site_lng} : {}), priority:$("#maintenance-priority").value, notes:$("#maintenance-notes").value.trim()}, ev.submitter, "Maintenance request sent. Our team will review it.");
        if (ok) { ev.target.reset(); setDrawer("#maintenance-drawer", false); }
      });
    });
  </script>
 </body>
</html>
