<!doctype html>
<html lang="en"><head><script>window["__codeletBootstrap__"]=JSON.parse('{"A":"A","B":"20261009-04-61a833b","C":{"Abril Fatface":"YACgEZbkUVE,0","Albert Sans":"YAHO2HRfeh4,0","Alfa Slab One":"YACgEYS9sJU,0","Anton":"YACgEcYqQ-A,0","Archivo Black":"YACgEZulLoA,0","Archivo":"YAHO2-t-jNE,0","Arial":"YAGyDvJ_4Ts,0","Baloo 2":"YAHO2IcQUcM,0","Barlow Condensed":"YAFdJljEuFc,0","Barlow":"YAFdJsyuOPM,1","Bebas Neue":"YACgESME5ew,0","Bricolage Grotesque":"YAFyMcdwzpc,0","Canva Sans":"YAFdJjTk5UU,1","Caveat":"YALBs2ploWQ,0","Cinzel":"YACgEeV8bIQ,0","Cormorant Garamond":"YAFdJhX-538,0","Courier New":"YAGzXiGs0_8,0","Courier Prime":"YAD1aFjegN8,0","DM Sans":"YAD1aU3sLnI,0","DM Serif Display":"YAD1aYG82rc,0","Figtree":"YAHO2b-mV7A,0","Forum":"YACgEcnnqB4,0","Fraunces":"YAFdJpU7Kkk,0","Fredoka":"YACgEZml080,0","Georgia":"YAGzXkO0pEM,0","Hanken Grotesk":"YAHO2VB9G0I,0","Helvetica":"YAFcf7zkXN0,0","IBM Plex Mono":"YAFdJkmvhGI,0","IBM Plex Sans":"YAFdJgT0SHI,0","Impact":"YAFcfnjI7Vk,0","Instrument Sans":"YAHO2bKyaSQ,0","Instrument Serif":"YAHFeOnZNEk,0","Inter":"YAFdJvSyp_k,3","Italiana":"YAHO2Toik_w,0","Jacques Francois":"YAHO2a5g66Q,0","JetBrains Mono":"YAFdJksXcAk,0","Josefin Sans":"YAFdJjvw9Ps,0","Karla":"YAHO2V2NSXM,0","Lato":"YAFdJuFCnaw,0","Libre Baskerville":"YACgEUFdPdA,0","Libre Caslon Display":"YAHO2XhLmt0,0","Lobster":"YAD8SnSjSFI,0","Lora":"YACgEXvxf8Q,0","Manrope":"YAHO2b2feC4,0","Merriweather":"YACgEXvHxxs,0","Montserrat":"YAFdtQi73Xs,0","Noto Sans JP":"YAFdJiHXlcI,0","Noto Sans KR":"YAGsojZj-RQ,0","Nunito Sans":"YAFdtQJYB9w,1","Nunito":"YAFdJoNRMmU,1","Oleo Script":"YACgEQQ14jI,0","Oswald":"YACgEQY10lw,0","Outfit":"YAHO2nVlg14,0","Pacifico":"YADLjORQ1u4,0","Playfair Display":"YAFdJhem5V8,1","Plus Jakarta Sans":"YAHO2gdhi18,0","Poppins":"YAFdJjbTu24,1","Press Start 2P":"YAFyGr-8pmQ,0","Public Sans":"YAFdJj8NdaU,1","Quicksand":"YAFdJpYtCxE,1","Raleway":"YAFdJhmxbVQ,1","Roboto Slab":"YAFdJswIKAg,0","Rockwell":"YAFcfyVZnN0,0","Rye":"YACgEdQP21k,0","Sarabun":"YAFdJssSnME,0","Schibsted Grotesk":"YAHO2sWydRk,0","Segoe UI":"YAHNdRD1Klw,0","Source Sans 3":"YAG4lO1Mj10,0","Space Grotesk":"YAHO2sjPCSM,0","Space Mono":"YADW1-vpsoc,0","Spectral":"YAHO2rVUHIM,0","Times New Roman":"YAGzXW3gftg,0","Trebuchet MS":"YAFcfrglpVA,0","Ubuntu":"YACgERDU--Q,0","Verdana":"YAGzXTctYtQ,0","Work Sans":"YAGXhLOKv44,0","Yellowtail":"YACgEYG4kG4,0"}}');</script><script src="/_sdk/3ea5843eacd3e51f.telemetry_sdk.js" integrity="sha512-1IT905GQp6Xezy7dJYJjQl6KtI/PDxD5Vu755gJMNA+luF1QkRT8rHzF+xP7Ekem4HWP8sPFcQQAmx6FCSGaMg=="></script>
  <meta charset="UTF-8">
  <meta name="robots" content="noindex, nofollow">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>VTech I.T Solution</title>
<link rel="icon" type="image/png" href="favicon.png">
<meta name="theme-color" content="#071b35"><link rel="apple-touch-icon" href="icons/apple-touch-icon.png"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-title" content="VTech"><script src="pwa.js" defer></script>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&amp;display=swap" rel="stylesheet">
  <style>
    :root {
      --navy: #071b35;
      --navy-2: #0c2848;
      --panel: #102f51;
      --line: #244766;
      --ink: #eaf4ff;
      --muted: #9eb7cc;
      --blue: #2786e8;
      --teal: #17b897;
      --amber: #e8a530;
      --red: #e05b63;
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      font-family: "DM Sans", sans-serif;
      color: var(--ink);
      background: var(--navy);
    }
    button, input, textarea, select { font: inherit; }
    button:focus-visible, input:focus-visible, textarea:focus-visible, select:focus-visible {
      outline: 3px solid #7cc4ff;
      outline-offset: 2px;
    }
    .portal-shell { width: 100%; min-height: calc(100 * min(var(--vh, 1vh), 1vh)); background: #071b35; }
    .side-nav { background: #081f3b; border-right: 1px solid var(--line); }
    .nav-item { color: #a9c0d3; border: 1px solid transparent; transition: .18s ease; }
    .nav-item:hover, .nav-item.active { color: #ffffff; background: #12395f; border-color: #2b5c85; }
    .card { background: rgba(16, 47, 81, .95); border: 1px solid var(--line); box-shadow: 0 12px 30px rgba(0, 0, 0, .14); }
    .job-card { transition: transform .18s ease, border-color .18s ease, background .18s ease; }
    .job-card:hover, .job-card.selected { transform: translateY(-2px); border-color: #4a9eea; background: #143a60; }
    .pill { border: 1px solid transparent; }
    .status-assigned { background: #173d61; color: #a8d9ff; border-color: #3575a7; }
    .status-progress { background: #174b49; color: #8bf0d9; border-color: #2a9988; }
    .status-paused { background: #4b3718; color: #ffd681; border-color: #a6782c; }
    .status-completed { background: #144638; color: #9af0cf; border-color: #287d65; }
    .priority-urgent { background: #54242c; color: #ffb3b7; border-color: #b64a55; }
    .priority-high { background: #513b1b; color: #ffd681; border-color: #aa7b27; }
    .priority-normal { background: #173d61; color: #acd8ff; border-color: #3876a6; }
    .workflow-step { border: 1px solid #2b506f; color: #a8c1d5; background: #0c2948; }
    .workflow-step.active { color: white; border-color: #4aa9f2; background: #1766aa; }
    .workflow-step.done { color: #9df2dc; border-color: #299b85; background: #123f3c; }
    .field { width: 100%; border: 1px solid #315776; background: #091f38; color: #eff8ff; border-radius: 10px; padding: .72rem .8rem; }
    .field::placeholder { color: #7c9bb4; }
    .action-blue { background: #2786e8; color: white; }
    .action-blue:hover { background: #1677d9; }
    .action-teal { background: #17a98d; color: #042c2b; }
    .action-teal:hover { background: #28c8a9; }
    .action-amber { background: #d89121; color: #251500; }
    .action-amber:hover { background: #f2ae3c; }
    .action-muted { background: #183b5e; color: #d7ecff; border: 1px solid #356489; }
    .route-grid {
      background-color: #0b2947;
      background-image: linear-gradient(90deg, rgba(79,142,188,.14) 1px, transparent 1px), linear-gradient(rgba(79,142,188,.14) 1px, transparent 1px);
      background-size: 26px 26px;
    }
    .map-line { stroke: #42a5f5; stroke-width: 5; fill: none; stroke-linecap: round; stroke-dasharray: 11 9; }
    .hidden-view { display: none !important; }
    #route-map { height: 540px; border-radius: 1rem; border: 1px solid #315776; isolation: isolate; background: #0b2947; }
    @media (max-width: 1023px) { #route-map { height: 380px; } }
    .stop-pin { width: 28px; height: 28px; border-radius: 50%; background: #1766aa; color: #fff; font-weight: 800; font-size: 13px; display: grid; place-items: center; border: 2px solid #fff; box-shadow: 0 2px 8px #0008; }
    .stop-pin.next { background: #17b897; }
    .me-dot { width: 18px; height: 18px; border-radius: 50%; background: #2786e8; border: 3px solid #fff; box-shadow: 0 0 0 6px #2786e855; }
    .stop-row { border: 1px solid #284c6e; background: #0c2948; border-radius: .9rem; padding: .8rem; }
    .stop-row.next { border-color: #17b897; background: #0e3a3a; }
    @media (max-width: 767px) {
      .desktop-nav { display: none; }
      .content-pad { padding-bottom: 6.5rem; }
    }
    @media (min-width: 768px) {
      .mobile-nav { display: none; }
    }
  </style>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.css">
  <script src="https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/lucide@0.577.0/dist/umd/lucide.min.js" type="text/javascript"></script>
  <link rel="stylesheet" href="vtech-ui.css">
  <script src="https://cdn.tailwindcss.com/3.4.17" type="text/javascript"></script>
  <script>window.PORTAL = "technician";</script>
  <script src="sdk-override.js" type="text/javascript"></script>
 </head>

 <body data-template-id="__page-root" style="background: rgb(7, 27, 53);">
  <div class="portal-shell flex">
   <aside class="side-nav desktop-nav w-64 shrink-0 p-5" aria-label="Technician workspace navigation">
    <div class="mb-9">
     <div class="flex items-center gap-3">
      <img src="logo.png" alt="VTech logo" class="h-12 w-12 shrink-0 object-contain">
      <div>
       <h1 data-template-id="portal-title" class="canva-text font-bold leading-tight" style="color: rgb(255, 255, 255); font-weight: 700; font-style: normal; font-size: 30px;">VTech I.T Solution</h1>
       <p data-template-id="portal-subtitle" class="canva-text mt-0.5 text-xs" style="color: rgb(142, 171, 193); font-weight: 600; font-style: normal; font-size: 15px; letter-spacing: 0.08rem;">VTech I.T Solution</p>
      </div>
     </div>
    </div>
    <nav class="space-y-2">
     <button type="button" class="nav-item active flex w-full items-center gap-3 rounded-xl px-4 py-3 text-left" data-view="today"><i data-lucide="sun" aria-hidden="true"></i><span data-template-id="nav-today" class="canva-text" style="color: rgb(220, 239, 255); font-weight: 600; font-style: normal; font-size: 15px;">Today</span></button> <button type="button" class="nav-item flex w-full items-center gap-3 rounded-xl px-4 py-3 text-left" data-view="jobs"><i data-lucide="clipboard-list" aria-hidden="true"></i><span data-template-id="nav-jobs" class="canva-text" style="color: rgb(220, 239, 255); font-weight: 600; font-style: normal; font-size: 15px;">Jobs</span></button> <button type="button" class="nav-item flex w-full items-center gap-3 rounded-xl px-4 py-3 text-left" data-view="route"><i data-lucide="route" aria-hidden="true"></i><span data-template-id="nav-route" class="canva-text" style="color: rgb(220, 239, 255); font-weight: 600; font-style: normal; font-size: 15px;">Route</span></button> <button type="button" class="nav-item flex w-full items-center gap-3 rounded-xl px-4 py-3 text-left" data-view="reports"><i data-lucide="file-check-2" aria-hidden="true"></i><span data-template-id="nav-reports" class="canva-text" style="color: rgb(220, 239, 255); font-weight: 600; font-style: normal; font-size: 15px;">Reports</span></button> <button type="button" class="nav-item flex w-full items-center gap-3 rounded-xl px-4 py-3 text-left" data-view="communication"><i data-lucide="messages-square" aria-hidden="true"></i><span data-template-id="nav-communication" class="canva-text" style="color: rgb(220, 239, 255); font-weight: 600; font-style: normal; font-size: 15px;">Communication</span><span id="unread-badge" class="ml-auto hidden rounded-full bg-[#e8a530] px-2 py-0.5 text-[11px] font-bold text-[#251500]">0</span></button>
    </nav>
    <div class="mt-auto pt-10">
     <div class="card rounded-2xl p-3">
      <div class="flex items-center gap-3">
       <div id="tech-avatar" class="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#2786e8] text-sm font-bold text-white">?</div>
       <div class="min-w-0">
        <p id="tech-name" data-template-id="technician-name" class="canva-text truncate text-sm font-bold" style="color: rgb(255, 255, 255); font-weight: 700; font-style: normal; font-size: 15px;">Not signed in</p><button id="account-btn" type="button" class="text-xs text-[#8db4d0] underline">Account</button>
        <p data-template-id="technician-role" class="canva-text text-xs" style="color: rgb(158, 183, 204); font-weight: 400; font-style: normal; font-size: 15px;">CCTV Field Technician</p>
       </div>
      </div>
     </div>
    </div>
   </aside>
   <div class="min-w-0 flex-1 content-pad">
    <header class="flex flex-wrap items-center justify-between gap-4 border-b border-[#244766] bg-[#09233f] px-4 py-4 md:px-7">
     <div>
      <p data-template-id="header-kicker" class="canva-text text-xs font-semibold uppercase tracking-[.16em]" style="color: rgb(88, 175, 240); font-weight: 700; font-style: normal; font-size: 15px; letter-spacing: 0.1rem;">FIELD OPERATIONS</p>
      <p id="date-display" class="mt-1 text-sm text-[#a9c0d3]"></p>
     </div>
     <div class="flex items-center gap-3">
      <button id="availability-button" type="button" class="flex items-center gap-2 rounded-xl border border-[#2e7e71] bg-[#113f3b] px-3 py-2 text-sm font-semibold text-[#9cf0da]"> <span class="h-2 w-2 rounded-full bg-[#2fdbb6]"></span><span data-template-id="availability-label" class="canva-text" style="color: rgb(156, 240, 218); font-weight: 600; font-style: normal; font-size: 15px;">Available</span> </button> <button id="bell-button" type="button" class="relative rounded-xl border border-[#315776] bg-[#102f51] p-2.5 text-[#dcefff]" aria-label="Notifications"> <i data-lucide="bell" aria-hidden="true"></i><span id="bell-dot" class="absolute right-2 top-2 hidden h-2 w-2 rounded-full bg-[#e8a530]"></span> </button>
      <div class="hidden items-center gap-2 text-xs text-[#9eb7cc] sm:flex"><i data-lucide="cloud-check" class="h-4 w-4 text-[#2fdbb6]" aria-hidden="true"></i><span id="sync-text" data-template-id="sync-label" class="canva-text" style="color: rgb(158, 183, 204); font-weight: 400; font-style: normal; font-size: 15px;">Connecting…</span>
      </div>
     </div>
    </header>
    <main id="main" tabindex="-1" class="p-4 md:p-7">
     <div id="feedback" class="mb-4 hidden rounded-xl border px-4 py-3 text-sm" role="status" aria-live="polite"></div>
     <section id="loading-state" class="card rounded-2xl p-8 text-center">
      <div class="mx-auto mb-4 h-10 w-10 animate-spin rounded-full border-4 border-[#2a567b] border-t-[#58aff0]"></div>
      <p data-template-id="loading-label" class="canva-text font-semibold" style="color: rgb(220, 239, 255); font-weight: 600; font-style: normal; font-size: 15px;">Loading your field schedule…</p>
     </section>
     <section id="today-view" class="hidden-view view-section">
      <div class="mb-6 flex flex-wrap items-end justify-between gap-4">
       <div>
        <h2 data-template-id="today-title" class="canva-text font-bold" style="color: rgb(255, 255, 255); font-weight: 700; font-style: normal; font-size: 23px;">Today’s Field Schedule</h2>
        <p data-template-id="today-copy" class="canva-text mt-1 text-sm" style="color: rgb(169, 192, 211); font-weight: 400; font-style: normal; font-size: 15px;">Review assigned CCTV service visits and keep every job moving.</p>
       </div>
       <div id="job-count" class="rounded-xl border border-[#315776] bg-[#0d2c4b] px-3 py-2 text-sm text-[#b9d2e5]"></div>
      </div>
      <div id="urgent-panel" class="mb-5 hidden rounded-2xl border border-[#a74650] bg-[#4d242b] p-4">
       <div class="flex gap-3"><i data-lucide="triangle-alert" class="mt-0.5 text-[#ff9da5]" aria-hidden="true"></i>
        <div>
         <h3 data-template-id="urgent-title" class="canva-text font-bold" style="color: rgb(255, 189, 193); font-weight: 700; font-style: normal; font-size: 18px;">Urgent service attention</h3>
         <p data-template-id="urgent-copy" class="canva-text mt-1 text-sm" style="color: rgb(255, 215, 218); font-weight: 400; font-style: normal; font-size: 15px;">An urgent job is in your route. Review access notes before travelling.</p>
        </div>
       </div>
      </div>
      <div class="grid gap-5 xl:grid-cols-[1.15fr_.85fr]">
       <section aria-labelledby="jobs-heading">
        <h3 id="jobs-heading" data-template-id="assigned-jobs-title" class="canva-text mb-3 font-bold" style="color: rgb(255, 255, 255); font-weight: 700; font-style: normal; font-size: 18px;">Assigned jobs</h3>
        <div id="job-list" class="space-y-3"></div>
        <div id="empty-state" class="hidden card rounded-2xl p-8 text-center">
         <i data-lucide="calendar-check" class="mx-auto mb-3 text-[#58aff0]" aria-hidden="true"></i>
         <h3 data-template-id="job-empty-title" class="canva-text font-bold" style="color: rgb(255, 255, 255); font-weight: 700; font-style: normal; font-size: 18px;">No jobs scheduled</h3>
         <p data-template-id="job-empty-copy" class="canva-text mt-2 text-sm" style="color: rgb(169, 192, 211); font-weight: 400; font-style: normal; font-size: 15px;">Your schedule is clear. New assignments will appear here when they are dispatched.</p>
        </div>
       </section>
       <aside class="card overflow-hidden rounded-2xl">
        <div class="flex items-center justify-between p-5 pb-3">
         <div>
          <h3 data-template-id="route-title" class="canva-text font-bold" style="color: rgb(255, 255, 255); font-weight: 700; font-style: normal; font-size: 18px;">Today’s route</h3>
          <p data-template-id="route-copy" class="canva-text mt-1 text-sm" style="color: rgb(169, 192, 211); font-weight: 400; font-style: normal; font-size: 15px;">A practical stop-by-stop overview.</p>
         </div><i data-lucide="navigation" class="text-[#57aff1]" aria-hidden="true"></i>
        </div>
        <div class="route-grid relative mx-5 h-56 overflow-hidden rounded-xl border border-[#315776]">
         <svg viewBox="0 0 400 220" class="h-full w-full" aria-label="Route overview illustration" role="img">
          <path class="map-line" d="M55 180 C90 146, 80 82, 148 98 S203 47, 264 76 S320 133, 352 45"></path> <circle cx="55" cy="180" r="10" fill="#17b897"></circle><circle cx="148" cy="98" r="9" fill="#e8a530"></circle><circle cx="264" cy="76" r="9" fill="#2786e8"></circle><circle cx="352" cy="45" r="10" fill="#e05b63"></circle>
         </svg>
        </div>
        <div class="grid grid-cols-3 gap-2 p-5 text-center text-xs">
         <div>
          <p class="font-bold text-[#eaf4ff]">18 km</p>
          <p class="text-[#9eb7cc]">Distance</p>
         </div>
         <div>
          <p class="font-bold text-[#eaf4ff]">3 stops</p>
          <p class="text-[#9eb7cc]">Assigned</p>
         </div>
         <div>
          <p class="font-bold text-[#eaf4ff]">42 min</p>
          <p class="text-[#9eb7cc]">Drive time</p>
         </div>
        </div>
       </aside>
      </div>
     </section>
     <section id="jobs-view" class="hidden-view view-section">
      <div class="mb-5">
       <h2 data-template-id="jobs-view-title" class="canva-text font-bold" style="color: rgb(255, 255, 255); font-weight: 700; font-style: normal; font-size: 23px;">All assigned jobs</h2>
       <p data-template-id="jobs-view-copy" class="canva-text mt-1 text-sm" style="color: rgb(169, 192, 211); font-weight: 400; font-style: normal; font-size: 15px;">Open a job to record your on-site work and progress.</p>
      </div>
      <div id="jobs-view-list" class="grid gap-3 lg:grid-cols-2"></div>
     </section>
     <section id="route-view" class="hidden-view view-section">
      <h2 data-template-id="route-view-title" class="canva-text mb-1 font-bold" style="color: rgb(255, 255, 255); font-weight: 700; font-style: normal; font-size: 23px;">Route overview</h2>
      <p data-template-id="route-view-copy" class="canva-text mb-5 text-sm" style="color: rgb(169, 192, 211); font-weight: 400; font-style: normal; font-size: 15px;">Plan your technician route around your assigned service locations.</p>
      <div class="grid gap-4 lg:grid-cols-[360px_1fr]">
       <div class="card rounded-2xl p-4">
        <div class="flex flex-wrap items-center gap-2">
         <button id="track-btn" type="button" class="action-blue flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-bold"><i data-lucide="navigation" class="h-4 w-4" aria-hidden="true"></i><span>Start live tracking</span></button>
         <button id="reroute-btn" type="button" class="action-muted rounded-xl px-3 py-2 text-sm font-bold">Recalculate</button>
        </div>
        <p id="route-status" class="mt-3 text-xs text-[#9eb7cc]">Start live tracking to get the best route from where you are.</p>
        <div id="route-summary" class="mt-3 hidden rounded-xl bg-[#0c2948] p-3 text-sm"></div>
        <ol id="route-stops" class="mt-4 space-y-3 text-sm"></ol>
        <p class="mt-4 text-[11px] leading-relaxed text-[#7f9bb3]">Route order and times are estimates from OpenStreetMap routing and do not include live traffic. Stops marked “exact pin” use the customer’s dropped map pin; “approximate” stops are looked up from the address.</p>
       </div>
       <div><div id="route-map" role="application" aria-label="Route map"></div></div>
      </div>
     </section>
     <section id="communication-view" class="hidden-view view-section">
      <div class="mb-5 flex flex-wrap items-end justify-between gap-4">
       <div>
        <h2 data-template-id="communication-title" class="canva-text font-bold" style="color: rgb(255, 255, 255); font-weight: 700; font-style: normal; font-size: 23px;">Communication Center</h2>
        <p data-template-id="communication-copy" class="canva-text mt-1 text-sm" style="color: rgb(169, 192, 211); font-weight: 400; font-style: normal; font-size: 15px;"><span id="comm-copy">Message or call the admin.</span></p>
       </div><span id="call-status" class="hidden rounded-full px-3 py-1 text-xs font-bold"></span>
      </div>
      <div class="grid gap-5 xl:grid-cols-[.72fr_1.28fr]">
       <aside class="space-y-5">
        <article class="card rounded-2xl p-5">
         <h3 data-template-id="contact-title" class="canva-text font-bold" style="color: rgb(255, 255, 255); font-weight: 700; font-style: normal; font-size: 18px;">Admin contact</h3><div class="mt-4 flex w-full items-center gap-3 rounded-xl border border-[#4a9eea] bg-[#143a60] p-3 text-left"><span id="admin-contact-initials" class="flex h-10 w-10 items-center justify-center rounded-full bg-[#2786e8] font-bold text-white">AD</span><span class="min-w-0"><strong id="admin-contact-name" class="block truncate">Admin / Dispatcher</strong><span id="admin-contact-role" class="text-xs text-[#a9c0d3]">Operations Admin</span></span></div>
        </article>
        <article class="card rounded-2xl p-5">
         <h3 data-template-id="call-history-title" class="canva-text font-bold" style="color: rgb(255, 255, 255); font-weight: 700; font-style: normal; font-size: 18px;">Call history</h3>
         <div id="call-history" class="mt-4 space-y-3"></div>
        </article>
       </aside>
       <article class="card flex min-h-[520px] flex-col rounded-2xl p-5">
        <div id="message-thread" class="flex-1 space-y-3 overflow-auto" aria-live="polite"></div>
        <div id="active-call-controls" class="mt-4 hidden rounded-xl border border-[#2e7e71] bg-[#113f3b] p-3">
         <div class="flex items-center justify-between gap-3">
          <span id="active-call-label" data-template-id="active-call-label" class="canva-text text-sm font-semibold" style="color: rgb(157, 242, 220); font-weight: 600; font-style: normal; font-size: 15px;">Call in progress</span><button id="end-call" type="button" class="rounded-lg bg-[#4d242b] px-3 py-2 text-xs font-bold text-[#ffbdc1]">End call</button>
         </div>
        </div>
        <div class="mt-4 flex flex-wrap gap-2">
         <button id="start-voice-call" type="button" class="action-muted flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-bold"><i data-lucide="phone" class="h-4 w-4" aria-hidden="true"></i><span data-template-id="voice-call-label" class="canva-text" style="color: rgb(220, 239, 255); font-weight: 600; font-style: normal; font-size: 15px;">Voice call</span></button><button id="start-video-call" type="button" class="action-muted flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-bold"><i data-lucide="video" class="h-4 w-4" aria-hidden="true"></i><span data-template-id="video-call-label" class="canva-text" style="color: rgb(220, 239, 255); font-weight: 600; font-style: normal; font-size: 15px;">Video call</span></button>
        </div>
        <form id="message-form" class="mt-3 flex gap-2">
         <label class="sr-only" for="message-input">Message the admin</label><input id="message-input" class="field flex-1" type="text" autocomplete="off" placeholder="Write a message"><button id="send-message" type="submit" class="action-blue rounded-xl px-4 py-2 font-bold"><span data-template-id="send-message-label" class="canva-text" style="color: rgb(255, 255, 255); font-weight: 700; font-style: normal; font-size: 15px;">Send</span></button>
        </form>
       </article>
      </div>
     </section>
     <section id="reports-view" class="hidden-view view-section">
      <h2 data-template-id="report-title" class="canva-text mb-1 font-bold" style="color: rgb(255, 255, 255); font-weight: 700; font-style: normal; font-size: 23px;">Service reports</h2>
      <p data-template-id="report-copy" class="canva-text mb-5 text-sm" style="color: rgb(169, 192, 211); font-weight: 400; font-style: normal; font-size: 15px;">Monitor draft and submitted completion reports from your field work.</p>
      <div id="report-list" class="space-y-3"></div>
     </section>
     <section id="detail-view" class="hidden-view mt-7 border-t border-[#244766] pt-7">
      <div class="mb-5 flex flex-wrap items-start justify-between gap-4">
       <div><button id="back-to-jobs" type="button" class="mb-3 flex items-center gap-2 text-sm text-[#a8d9ff]"><i data-lucide="arrow-left" class="h-4 w-4" aria-hidden="true"></i>Back to jobs</button>
        <p id="detail-job-id" class="text-xs font-bold tracking-widest text-[#57aff1]"></p>
        <h2 id="detail-job-title" class="mt-1 text-2xl font-bold"></h2>
        <p id="detail-customer" class="mt-1 text-sm text-[#a9c0d3]"></p>
       </div><span id="detail-status" class="pill rounded-full px-3 py-1 text-sm font-bold"></span>
      </div>
      <div class="grid gap-5 xl:grid-cols-[.72fr_1.28fr]">
       <aside class="space-y-5">
        <article class="card rounded-2xl p-5">
         <h3 data-template-id="site-info-title" class="canva-text font-bold" style="color: rgb(255, 255, 255); font-weight: 700; font-style: normal; font-size: 18px;">Site information</h3>
         <div class="mt-4 space-y-4 text-sm">
          <div class="flex gap-3"><i data-lucide="map-pin" class="h-5 shrink-0 text-[#58aff0]" aria-hidden="true"></i>
           <p id="detail-address"></p>
          </div>
          <div class="flex gap-3"><i data-lucide="key-round" class="h-5 shrink-0 text-[#ffd681]" aria-hidden="true"></i>
           <p data-template-id="access-note" class="canva-text" style="color: rgb(215, 233, 248); font-weight: 400; font-style: normal; font-size: 15px;">Access note: Check in with the site security desk and request roof access clearance before installation work.</p>
          </div>
         </div>
        </article>
        <article class="card rounded-2xl p-5">
         <h3 data-template-id="history-title" class="canva-text font-bold" style="color: rgb(255, 255, 255); font-weight: 700; font-style: normal; font-size: 18px;">Service history</h3>
         <p data-template-id="history-copy" class="canva-text mt-3 text-sm" style="color: rgb(169, 192, 211); font-weight: 400; font-style: normal; font-size: 15px;">Previous inspection completed 14 June. Remote viewing intermittent after recent router replacement.</p>
        </article>
        <article class="card rounded-2xl p-5"><label for="status-select" data-template-id="status-label" class="canva-text mb-2 block text-sm font-semibold" style="color: rgb(220, 239, 255); font-weight: 600; font-style: normal; font-size: 15px;">Job status</label><select id="status-select" class="field"><option>Assigned</option><option>In progress</option><option>Paused</option><option>Completed</option></select>
         <div class="mt-3 grid grid-cols-2 gap-2"><button id="start-job" type="button" class="action-blue rounded-xl px-3 py-2 text-sm font-bold">Start Job</button><button id="pause-job" type="button" class="action-amber rounded-xl px-3 py-2 text-sm font-bold">Pause</button>
         </div>
        </article>
       </aside>
       <div class="space-y-5">
        <article class="card rounded-2xl p-5">
         <div class="flex flex-wrap items-center justify-between gap-3">
          <div>
           <h3 data-template-id="workflow-title" class="canva-text font-bold" style="color: rgb(255, 255, 255); font-weight: 700; font-style: normal; font-size: 18px;">Service workflow</h3>
           <p data-template-id="workflow-copy" class="canva-text mt-1 text-sm" style="color: rgb(169, 192, 211); font-weight: 400; font-style: normal; font-size: 15px;">Move through each required on-site outcome in sequence.</p>
          </div><span id="progress-indicator" class="rounded-full bg-[#123f3c] px-3 py-1 text-xs font-bold text-[#9df2dc]"></span>
         </div>
         <div class="mt-5 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          <button type="button" class="workflow-step rounded-xl p-3 text-left text-sm font-semibold" data-stage="Site Survey"><span data-template-id="stage-survey" class="canva-text" style="color: rgb(220, 239, 255); font-weight: 600; font-style: normal; font-size: 15px;">1. Site Survey</span></button> <button type="button" class="workflow-step rounded-xl p-3 text-left text-sm font-semibold" data-stage="Installation &amp; Configuration"><span data-template-id="stage-installation" class="canva-text" style="color: rgb(220, 239, 255); font-weight: 600; font-style: normal; font-size: 15px;">2. Installation &amp; Configuration</span></button> <button type="button" class="workflow-step rounded-xl p-3 text-left text-sm font-semibold" data-stage="Testing &amp; Handover"><span data-template-id="stage-testing" class="canva-text" style="color: rgb(220, 239, 255); font-weight: 600; font-style: normal; font-size: 15px;">3. Testing &amp; Handover</span></button> <button type="button" class="workflow-step rounded-xl p-3 text-left text-sm font-semibold" data-stage="Maintenance / Repair"><span data-template-id="stage-maintenance" class="canva-text" style="color: rgb(220, 239, 255); font-weight: 600; font-style: normal; font-size: 15px;">4. Maintenance / Repair</span></button> <button type="button" class="workflow-step rounded-xl p-3 text-left text-sm font-semibold" data-stage="Completion Report"><span data-template-id="stage-report" class="canva-text" style="color: rgb(220, 239, 255); font-weight: 600; font-style: normal; font-size: 15px;">5. Completion Report</span></button> <button type="button" class="workflow-step rounded-xl p-3 text-left text-sm font-semibold" data-stage="Customer Sign-off"><span data-template-id="stage-signoff" class="canva-text" style="color: rgb(220, 239, 255); font-weight: 600; font-style: normal; font-size: 15px;">6. Customer Sign-off</span></button>
         </div>
        </article>
        <article class="card rounded-2xl p-5">
         <h3 data-template-id="checklist-title" class="canva-text font-bold" style="color: rgb(255, 255, 255); font-weight: 700; font-style: normal; font-size: 18px;">Stage checklist</h3>
         <div id="checklist" class="mt-4 grid gap-3 sm:grid-cols-2"></div>
        </article>
        <article class="card rounded-2xl p-5">
         <div class="grid gap-5 md:grid-cols-2">
          <div><label for="equipment-input" data-template-id="equipment-label" class="canva-text mb-2 block text-sm font-semibold" style="color: rgb(220, 239, 255); font-weight: 600; font-style: normal; font-size: 15px;">Equipment used</label><textarea id="equipment-input" class="field min-h-28" placeholder="e.g. 4 × 4MP dome cameras, 80m Cat6, PoE switch"></textarea>
          </div>
          <div><label for="notes-input" data-template-id="notes-label" class="canva-text mb-2 block text-sm font-semibold" style="color: rgb(220, 239, 255); font-weight: 600; font-style: normal; font-size: 15px;">Technician notes</label><textarea id="notes-input" class="field min-h-28" placeholder="Record service details, configurations and observations"></textarea>
          </div>
         </div>
         <div class="mt-5"><label for="issue-input" data-template-id="issue-label" class="canva-text mb-2 block text-sm font-semibold" style="color: rgb(220, 239, 255); font-weight: 600; font-style: normal; font-size: 15px;">Report an issue</label><input id="issue-input" class="field" type="text" placeholder="Describe any safety, access, hardware or network issue"><button id="report-issue" type="button" class="mt-2 rounded-xl border border-[#a74650] bg-[#4d242b] px-3 py-2 text-sm font-bold text-[#ffbdc1]">Report issue</button>
         </div>
        </article>
        <article class="card rounded-2xl p-5">
         <h3 data-template-id="documentation-title" class="canva-text font-bold" style="color: rgb(255, 255, 255); font-weight: 700; font-style: normal; font-size: 18px;">Photos &amp; documents</h3>
         <p data-template-id="documentation-copy" class="canva-text mt-1 text-sm" style="color: rgb(169, 192, 211); font-weight: 400; font-style: normal; font-size: 15px;">Upload site photos (JPG/PNG/WEBP) or PDF documents. The customer can open them from their portal.</p>
         <div class="mt-4 flex flex-wrap gap-3"><button id="upload-photo" type="button" class="action-muted flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold"><i data-lucide="image-plus" class="h-4 w-4" aria-hidden="true"></i>Upload photo</button><button id="upload-document" type="button" class="action-muted flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold"><i data-lucide="file-up" class="h-4 w-4" aria-hidden="true"></i>Upload document</button><input id="photo-file" type="file" accept="image/jpeg,image/png,image/webp" capture="environment" class="hidden"><input id="doc-file" type="file" accept="application/pdf,image/jpeg,image/png,image/webp" class="hidden">
         </div>
         <div id="document-list" class="mt-4 flex flex-wrap gap-2"></div>
        </article>
        <article class="card rounded-2xl p-5">
         <div class="grid gap-5 md:grid-cols-2">
          <div>
           <h3 data-template-id="signoff-title" class="canva-text font-bold" style="color: rgb(255, 255, 255); font-weight: 700; font-style: normal; font-size: 18px;">Customer sign-off</h3>
           <p id="signature-display" class="mt-2 text-sm text-[#a9c0d3]"></p><label for="signoff-name" class="mt-3 block text-xs font-semibold text-[#a9c0d3]">Name of person acknowledging on site</label><input id="signoff-name" class="field mt-1" type="text" placeholder="e.g. Maria Santos"><button id="capture-signature" type="button" class="action-muted mt-3 rounded-xl px-4 py-2.5 text-sm font-bold">Record on-site acknowledgement</button>
          </div>
          <div>
           <h3 data-template-id="completion-title" class="canva-text font-bold" style="color: rgb(255, 255, 255); font-weight: 700; font-style: normal; font-size: 18px;">Completion report</h3>
           <p id="report-status-display" class="mt-2 text-sm text-[#a9c0d3]"></p><button id="submit-report" type="button" class="action-teal mt-4 rounded-xl px-4 py-2.5 text-sm font-bold">Submit completion report</button>
          </div>
         </div><button id="save-job" type="button" class="action-blue mt-6 w-full rounded-xl px-4 py-3 font-bold">Save job updates</button>
        </article>
       </div>
      </div>
     </section>
    </main>
   </div>
   <nav class="mobile-nav fixed bottom-0 left-0 right-0 z-30 border-t border-[#244766] bg-[#09233f] px-2 py-2" aria-label="Mobile technician navigation">
    <div class="flex justify-around">
     <button type="button" class="nav-item active rounded-lg p-2" data-view="today" aria-label="Today"><i data-lucide="sun" aria-hidden="true"></i></button> <button type="button" class="nav-item rounded-lg p-2" data-view="jobs" aria-label="Jobs"><i data-lucide="clipboard-list" aria-hidden="true"></i></button> <button type="button" class="nav-item rounded-lg p-2" data-view="route" aria-label="Route"><i data-lucide="route" aria-hidden="true"></i></button> <button type="button" class="nav-item rounded-lg p-2" data-view="reports" aria-label="Reports"><i data-lucide="file-check-2" aria-hidden="true"></i></button> <button type="button" class="nav-item rounded-lg p-2" data-view="communication" aria-label="Communication"><i data-lucide="messages-square" aria-hidden="true"></i></button>
    </div>
   </nav>
  </div>
  
  <div id="account-modal" class="hidden fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4" role="dialog" aria-modal="true" aria-label="Your account">
   <div class="card w-full max-w-md rounded-2xl p-6">
    <div class="flex items-start justify-between gap-3"><div><h2 class="text-xl font-bold">Your account</h2><p id="account-info" class="mt-1 text-sm text-[#a9c0d3]"></p></div><button id="account-close" type="button" class="rounded-lg p-1 hover:bg-[#12395f]" aria-label="Close"><i data-lucide="x" class="h-4 w-4"></i></button></div>
    <form id="pw-form" class="mt-5 space-y-3">
     <h3 class="font-bold">Change password</h3>
     <div><label for="pw-current" class="mb-2 block text-sm font-semibold">Current password</label><input id="pw-current" class="field" type="password" required autocomplete="current-password"></div>
     <div><label for="pw-new" class="mb-2 block text-sm font-semibold">New password</label><input id="pw-new" class="field" type="password" required minlength="8" autocomplete="new-password"></div>
     <div><label for="pw-new2" class="mb-2 block text-sm font-semibold">Confirm new password</label><input id="pw-new2" class="field" type="password" required minlength="8" autocomplete="new-password"></div>
     <div id="pw-error" class="hidden rounded-xl border border-[#a74650] bg-[#4d242b] px-3 py-2 text-sm text-[#ffbdc1]" role="alert"></div>
     <button type="submit" class="action-blue w-full rounded-xl px-4 py-3 font-bold">Update password</button>
    </form>
    <button id="signout-btn" type="button" class="action-muted mt-4 w-full rounded-xl px-4 py-3 font-bold">Sign out</button>
   </div>
  </div>
  <span id="admin-label" class="hidden"></span>
  <template id="job-card-template">
   <button type="button" class="job-card card w-full rounded-2xl p-4 text-left" aria-label="Open job details">
    <div class="flex items-start justify-between gap-3">
     <div>
      <p class="job-time text-sm font-bold text-[#a8d9ff]"></p>
      <h3 class="job-title mt-1 font-bold"></h3>
     </div><span class="job-priority pill rounded-full px-2.5 py-1 text-xs font-bold"></span>
    </div><p class="job-customer mt-3 text-sm text-[#d9edff]"></p><p class="job-address mt-1 flex items-center gap-1 text-xs text-[#9eb7cc]"><i data-lucide="map-pin" class="h-3.5 w-3.5"></i><span></span></p>
    <div class="mt-4 flex items-center justify-between"><span class="job-status pill rounded-full px-2.5 py-1 text-xs font-bold"></span><span class="text-xs text-[#8db4d0]">Open workspace <i data-lucide="arrow-up-right" class="inline h-3.5 w-3.5"></i></span>
    </div></button>
  </template>
    <script>
    /* ---------- helpers ---------- */
    const $ = s => document.querySelector(s);
    const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
    const nowIso = () => new Date().toISOString();
    const localToday = () => new Date(Date.now() - new Date().getTimezoneOffset()*60000).toISOString().slice(0,10);
    const fmtDate = d => d ? new Date(d + "T00:00:00").toLocaleDateString("en-PH",{month:"short",day:"numeric"}) : "";
    const fmtStamp = t => t ? new Date(t).toLocaleString("en-PH",{month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"}) : "";

    const stages = ["Site Survey","Installation & Configuration","Testing & Handover","Maintenance / Repair","Completion Report","Customer Sign-off"];
    const checklistItems = [
      "Confirm site access and safety",
      "Inspect camera coverage and mounting points",
      "Verify power, cable and network paths",
      "Configure recorder and remote viewing",
      "Test live view, recording and alerts",
      "Brief customer on system handover"
    ];
    const JOB_TYPES = ["appointment","maintenance_request","work_order"];

    let me = null;
    let backendRecords = [], selectedId = null, selectedSnapshot = "", initialLoadTimer, loaded = false, activeCall = null;
    const markingRead = new Set();

    const statusClass = s => ({"Assigned":"status-assigned","In progress":"status-progress","Paused":"status-paused","Completed":"status-completed"}[s] || "status-assigned");
    const priorityClass = p => ({"Urgent":"priority-urgent","High":"priority-high","Normal":"priority-normal"}[p] || "priority-normal");
    const jobTitle = j => j.job_title || j.title || "Service job";
    const jobCode = j => j.job_id || ("JOB-" + String(j.__backendId || "").slice(-5).toUpperCase());

    /* ---------- derived data ---------- */
    const myRecord = () => me ? backendRecords.find(r => r.record_type === "technician" && (r.contact_name || r.title) === me.name) : null;
    const allMine  = () => me ? backendRecords.filter(r => JOB_TYPES.includes(r.record_type) && r.assigned_technician === me.name && r.status !== "Cancelled") : [];
    const sortJobs = list => [...list].sort((a,b) => (b.priority === "Urgent") - (a.priority === "Urgent") || String(a.scheduled_date || "9999").localeCompare(String(b.scheduled_date || "9999")));
    const jobsAll  = () => sortJobs(allMine());
    const jobsToday = () => jobsAll().filter(j => j.status !== "Completed" && (!j.scheduled_date || j.scheduled_date <= localToday() || j.status === "In progress" || j.priority === "Urgent"));
    const selectedJob = () => backendRecords.find(r => r.__backendId === selectedId);
    const adminRec = () => backendRecords.find(r => r.record_type === "admin_profile") || null;
    const adminName = () => (adminRec() && adminRec().contact_name) || "Admin / Dispatcher";
    const threadId = () => "tech:" + (me ? me.name : "");
    const threadMsgs = () => backendRecords.filter(r => r.record_type === "message" && r.thread_id === threadId()).sort((a,b) => new Date(a.msg_timestamp||a.created_at) - new Date(b.msg_timestamp||b.created_at));
    const initials = n => String(n || "?").split(/\s+/).map(w => w[0]).join("").slice(0,2).toUpperCase();

    function showFeedback(message, type = "success") {
      const el = $("#feedback");
      el.textContent = message;
      el.className = "mb-4 rounded-xl border px-4 py-3 text-sm " + (type === "error" ? "border-[#a74650] bg-[#4d242b] text-[#ffbdc1]" : "border-[#287d65] bg-[#123f3c] text-[#a8f0d9]");
      el.classList.remove("hidden");
      clearTimeout(showFeedback.t); showFeedback.t = setTimeout(() => el.classList.add("hidden"), 4500);
    }

    /* ---------- navigation ---------- */
    function showView(view) {
      document.querySelectorAll(".view-section").forEach(s => s.classList.add("hidden-view"));
      $("#" + view + "-view").classList.remove("hidden-view");
      $("#detail-view").classList.add("hidden-view");
      document.querySelectorAll("[data-view]").forEach(b => b.classList.toggle("active", b.dataset.view === view));
      if (view === "route") { ensureRouteMap(); if (rMap) setTimeout(() => rMap.invalidateSize(), 80); if (watchId === null && navigator.permissions) navigator.permissions.query({name: "geolocation"}).then(p => { if (p.state === "granted") startTracking(); }).catch(() => {}); }
      if (view === "communication") { renderCommunication(); const t = $("#message-thread"); t.scrollTop = t.scrollHeight; markAdminRead(); }
    }
    const detailOpen = () => !$("#detail-view").classList.contains("hidden-view");

    /* ---------- header / profile ---------- */
    function renderProfile() {
      if (!me) return;
      $("#tech-name").textContent = me.name;
      $("#tech-avatar").textContent = initials(me.name);
      const rec = myRecord(), avail = !rec || rec.status !== "Unavailable";
      const btn = $("#availability-button");
      btn.querySelector("span:last-child").textContent = avail ? "Available" : "Unavailable";
      btn.classList.toggle("bg-[#4d242b]", !avail); btn.classList.toggle("border-[#a74650]", !avail);
      $("#admin-label").textContent = adminName();
      const ap = adminRec();
      $("#admin-contact-name").textContent = adminName();
      $("#admin-contact-role").textContent = (ap && ap.notes) || "Operations Admin";
      $("#admin-contact-initials").textContent = initials(adminName());
      $("#comm-copy").textContent = `Message or call ${adminName()}${ap && ap.phone ? " · " + ap.phone : ""}.`;
      $("#message-input").placeholder = "Write a message to " + adminName();
      $("#date-display").textContent = new Intl.DateTimeFormat("en-PH", {weekday:"long", month:"long", day:"numeric"}).format(new Date());
    }

    /* ---------- jobs ---------- */
    function createJobCard(job) {
      const fragment = $("#job-card-template").content.cloneNode(true);
      const button = fragment.querySelector("button");
      button.querySelector(".job-time").textContent = job.status === "Completed" ? "Completed" : [fmtDate(job.scheduled_date), job.scheduled_time].filter(Boolean).join(" · ") || (job.priority === "Urgent" ? "Immediate response" : "Time to be confirmed");
      button.querySelector(".job-title").textContent = jobTitle(job);
      button.querySelector(".job-customer").textContent = job.customer_name || "";
      button.querySelector(".job-address span").textContent = job.site_address || "";
      const p = button.querySelector(".job-priority"); p.textContent = job.priority || "Normal"; p.classList.add(priorityClass(job.priority));
      const s = button.querySelector(".job-status"); s.textContent = job.status || "Assigned"; s.classList.add(statusClass(job.status));
      button.addEventListener("click", () => openDetail(job.__backendId, true));
      return fragment;
    }
    function renderJobs() {
      $("#loading-state").classList.add("hidden");
      const today = jobsToday(), all = jobsAll();
      const t1 = $("#job-list"), t2 = $("#jobs-view-list");
      t1.innerHTML = ""; t2.innerHTML = "";
      $("#job-count").textContent = today.length + (today.length === 1 ? " job to do" : " jobs to do");
      $("#empty-state").classList.toggle("hidden", today.length !== 0);
      $("#urgent-panel").classList.toggle("hidden", !all.some(j => j.priority === "Urgent" && j.status !== "Completed"));
      today.forEach(j => t1.appendChild(createJobCard(j)));
      all.forEach(j => t2.appendChild(createJobCard(j)));
      if (!all.length) t2.innerHTML = '<p class="text-sm text-[#9eb7cc]">No jobs have been assigned to you yet. The admin will dispatch work here.</p>';
      lucide.createIcons();
    }

    function openDetail(id, scroll) {
      selectedId = id;
      const job = selectedJob(); if (!job) return;
      selectedSnapshot = JSON.stringify(job);
      document.querySelectorAll(".view-section").forEach(s => s.classList.add("hidden-view"));
      $("#detail-view").classList.remove("hidden-view");
      $("#detail-job-id").textContent = jobCode(job);
      $("#detail-job-title").textContent = jobTitle(job);
      $("#detail-customer").textContent = [job.customer_name, job.contact_name, job.phone].filter(Boolean).join(" · ");
      $("#detail-address").textContent = job.site_address || "";
      $("#detail-status").textContent = job.status;
      $("#detail-status").className = "pill rounded-full px-3 py-1 text-sm font-bold " + statusClass(job.status);
      $("#status-select").value = ["Assigned","In progress","Paused","Completed"].includes(job.status) ? job.status : "Assigned";
      $("#equipment-input").value = job.equipment_used || "";
      $("#notes-input").value = job.notes || "";
      $("#issue-input").value = "";
      $("#signature-display").textContent = job.signature_status || "Awaiting customer sign-off";
      $("#report-status-display").textContent = job.report_submitted ? "Completion report submitted" : "Completion report not yet submitted";
      renderWorkflow(job); renderChecklist(job); renderDocuments(job);
      lucide.createIcons();
      if (scroll) $("#detail-view").scrollIntoView({behavior:"smooth", block:"start"});
    }
    function renderWorkflow(job) {
      const stage = job.workflow_stage || stages[0], cur = Math.max(0, stages.indexOf(stage));
      document.querySelectorAll(".workflow-step").forEach((b, i) => { b.classList.toggle("active", b.dataset.stage === stage); b.classList.toggle("done", i < cur); });
      $("#progress-indicator").textContent = "Stage " + (cur + 1) + " of " + stages.length;
    }
    function renderChecklist(job) {
      const done = (job.checklist_progress || "").split("|").filter(Boolean);
      const list = $("#checklist"); list.innerHTML = "";
      checklistItems.forEach((item, index) => {
        const label = document.createElement("label");
        label.className = "flex cursor-pointer items-center gap-3 rounded-xl border border-[#2b506f] bg-[#0c2948] p-3 text-sm";
        const input = document.createElement("input");
        input.type = "checkbox"; input.checked = done.includes(item); input.className = "h-4 w-4 accent-[#2fdbb6]";
        input.addEventListener("change", () => {
          const vals = [...list.querySelectorAll("input")].map((el, i) => el.checked ? checklistItems[i] : null).filter(Boolean);
          updateSelected({checklist_progress: vals.join("|")}, input);
        });
        const text = document.createElement("span"); text.textContent = (index + 1) + ". " + item;
        label.append(input, text); list.appendChild(label);
      });
    }
    function renderDocuments(job) {
      const docs = (job.documents_uploaded || "").split("|").filter(Boolean);
      $("#document-list").innerHTML = docs.length ? docs.map(d => {
        const [name, stored] = d.split("::");
        const cls = "rounded-lg border border-[#356489] bg-[#12395f] px-2.5 py-1 text-xs text-[#cde7fb]";
        return stored ? `<a class="${cls} underline" target="_blank" rel="noopener" href="download.php?f=${encodeURIComponent(stored)}">${esc(name)}</a>` : `<span class="${cls}">${esc(name)}</span>`;
      }).join("") : '<span class="text-sm text-[#8eabc1]">No files uploaded yet.</span>';
    }

    /* ---------- route: exact customer pins, live GPS, best route (OpenStreetMap + OSRM, no API key) ---------- */
    const NOMINATIM = "https://nominatim.openstreetmap.org", OSRM = "https://router.project-osrm.org";
    let rMap = null, rLayer = null, rLine = null, meMarker = null, meAcc = null, watchId = null, myPos = null;
    let lastRoutePos = null, lastRouteAt = 0, routeSeq = 0, stopsSig = "", stopCache = [];
    const fmtKm = m => m >= 1000 ? (m / 1000).toFixed(1) + " km" : Math.round(m) + " m";
    const fmtMin = s => { const m = Math.round(s / 60); return m >= 60 ? Math.floor(m / 60) + " h " + (m % 60) + " min" : Math.max(1, m) + " min"; };
    const setRouteStatus = t => { $("#route-status").textContent = t; };
    const hav = (a, b) => { const R = 6371000, r = x => x * Math.PI / 180, dl = r(b.lat - a.lat), dg = r(b.lng - a.lng); const h = Math.sin(dl / 2) ** 2 + Math.cos(r(a.lat)) * Math.cos(r(b.lat)) * Math.sin(dg / 2) ** 2; return 2 * R * Math.asin(Math.sqrt(h)); };
    const cleanAddr = a => { const p = String(a || "").split(" · "); return (p.length > 1 ? p.slice(1).join(", ") : p[0]).trim(); };
    const sleep = ms => new Promise(r => setTimeout(r, ms));

    function ensureRouteMap() {
      if (rMap || !window.L) { if (!window.L) setRouteStatus("The map could not load. Check your internet connection."); return; }
      rMap = L.map("route-map").setView([14.1, 121.3], 9);
      L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {maxZoom: 19, attribution: "&copy; OpenStreetMap contributors"}).addTo(rMap);
      rLayer = L.layerGroup().addTo(rMap);
    }

    // Exact pin if the customer dropped one; otherwise look the address up (cached in this browser).
    async function geocode(address) {
      const key = "vtech_geo:" + address;
      try { const c = JSON.parse(localStorage.getItem(key) || "null"); if (c) return c; } catch (e) {}
      try {
        const res = await fetch(`${NOMINATIM}/search?format=jsonv2&limit=1&accept-language=en&q=${encodeURIComponent(address)}`);
        const list = await res.json();
        if (!list.length) return null;
        const pt = {lat: parseFloat(list[0].lat), lng: parseFloat(list[0].lon)};
        try { localStorage.setItem(key, JSON.stringify(pt)); } catch (e) {}
        return pt;
      } catch (e) { return null; }
    }
    async function resolveStops(jobs) {
      const out = [];
      for (const job of jobs) {
        const hasPin = job.site_lat != null && job.site_lng != null && isFinite(job.site_lat) && isFinite(job.site_lng);
        let pt = hasPin ? {lat: +job.site_lat, lng: +job.site_lng} : null, exact = hasPin;
        if (!pt) {
          const addr = cleanAddr(job.site_address);
          const cached = addr && (() => { try { return localStorage.getItem("vtech_geo:" + addr); } catch (e) { return null; } })();
          if (addr && !cached) await sleep(1100);          // be polite to the free geocoder: ~1 request/second
          if (addr) pt = await geocode(addr);
        }
        out.push({job, pt, exact});
      }
      return out;
    }

    async function renderRoute() {
      const list = $("#route-stops");
      const jobs = jobsAll().filter(j => j.status !== "Completed").slice(0, 8);
      const sig = JSON.stringify(jobs.map(j => [j.__backendId, j.site_address, j.site_lat, j.site_lng, j.scheduled_date, j.scheduled_time]));
      if (sig === stopsSig) return;
      stopsSig = sig;
      if (!jobs.length) { stopCache = []; list.innerHTML = '<li class="text-sm text-[#9eb7cc]">No upcoming stops.</li>'; drawRoute(null); return; }
      list.innerHTML = '<li class="text-sm text-[#9eb7cc]">Locating your stops…</li>';
      const my = ++routeSeq;
      const stops = await resolveStops(jobs);
      if (my !== routeSeq) return;
      stopCache = stops;
      computeRoute(true);
    }

    async function computeRoute(force) {
      ensureRouteMap();
      const stops = stopCache.filter(s => s.pt);
      if (!stopCache.length) return;
      const my = ++routeSeq;
      let order = stops.map((s, i) => i), legs = null, geometry = null;
      if (myPos && stops.length) {
        try {
          setRouteStatus("Calculating the best route…");
          const coords = [[myPos.lng, myPos.lat]].concat(stops.map(s => [s.pt.lng, s.pt.lat])).map(c => c.join(",")).join(";");
          let data;
          if (stops.length > 1) {
            const res = await fetch(`${OSRM}/trip/v1/driving/${coords}?source=first&roundtrip=false&overview=full&geometries=geojson`);
            data = await res.json();
            if (data.code === "Ok" && data.trips && data.trips[0]) {
              const wp = data.waypoints.slice(1).map((w, i) => ({i, idx: w.waypoint_index}));
              order = wp.sort((a, b) => a.idx - b.idx).map(w => w.i);
              legs = data.trips[0].legs; geometry = data.trips[0].geometry;
            } else data = null;
          }
          if (!legs) {
            const res = await fetch(`${OSRM}/route/v1/driving/${coords}?overview=full&geometries=geojson`);
            data = await res.json();
            if (data.code === "Ok" && data.routes[0]) { legs = data.routes[0].legs; geometry = data.routes[0].geometry; order = stops.map((s, i) => i); }
          }
          if (!legs) setRouteStatus("Could not calculate a route right now. Stops are shown in schedule order.");
        } catch (e) { setRouteStatus("Routing service unreachable. Stops are shown in schedule order."); legs = null; geometry = null; }
      }
      if (my !== routeSeq) return;
      lastRoutePos = myPos ? {lat: myPos.lat, lng: myPos.lng} : null; lastRouteAt = Date.now();
      drawRoute({stops, order, legs, geometry});
    }

    function drawRoute(r) {
      const list = $("#route-stops"), sum = $("#route-summary");
      if (!window.L) { if (r) list.innerHTML = r.stops.map(s => `<li class="stop-row">${esc(jobTitle(s.job))}<br><span class="text-[#a9c0d3]">${esc(s.job.site_address || "")}</span></li>`).join(""); return; }
      ensureRouteMap();
      if (rLayer) rLayer.clearLayers();
      rLine = null;
      if (!r) { sum.classList.add("hidden"); return; }
      const {stops, order, legs, geometry} = r, bounds = [];
      const missing = stopCache.filter(s => !s.pt);
      const ordered = order.map(i => stops[i]);
      let html = "", totalM = 0, totalS = 0;
      ordered.forEach((s, n) => {
        const leg = legs && legs[n];
        if (leg) { totalM += leg.distance; totalS += leg.duration; }
        const j = s.job, dest = s.pt.lat + "," + s.pt.lng;
        html += `<li class="stop-row ${n === 0 ? "next" : ""}"><div class="flex gap-3"><span class="stop-pin ${n === 0 ? "next" : ""} shrink-0">${n + 1}</span><div class="min-w-0 flex-1"><p class="font-bold text-[#eaf4ff]">${esc(jobTitle(j))}</p><p class="text-[#d9edff]">${esc(j.customer_name || "")}</p><p class="text-[#a9c0d3]">${esc(j.site_address || "")}</p><p class="text-xs text-[#8db4d0]">${esc([fmtDate(j.scheduled_date), j.scheduled_time].filter(Boolean).join(" · "))}</p>
          <p class="mt-1 text-xs ${s.exact ? "text-[#9cf0da]" : "text-[#f0c36a]"}">${s.exact ? "📍 Exact pin" : "≈ Approximate (from address)"} · ${s.pt.lat.toFixed(5)}, ${s.pt.lng.toFixed(5)}</p>
          ${leg ? `<p class="mt-1 text-xs font-semibold text-[#58aff0]">${n === 0 ? "From you" : "From previous stop"}: ${fmtKm(leg.distance)} · ${fmtMin(leg.duration)}</p>` : ""}
          <a class="action-muted mt-2 inline-flex items-center gap-1 rounded-lg px-3 py-1.5 text-xs font-bold" target="_blank" rel="noopener" href="https://www.google.com/maps/dir/?api=1&destination=${dest}&travelmode=driving">Open turn-by-turn navigation ↗</a></div></div></li>`;
        const icon = L.divIcon({className: "", html: `<div class="stop-pin ${n === 0 ? "next" : ""}">${n + 1}</div>`, iconSize: [28, 28], iconAnchor: [14, 14]});
        if (rLayer) L.marker([s.pt.lat, s.pt.lng], {icon}).bindPopup(`<b>${esc(jobTitle(j))}</b><br>${esc(j.customer_name || "")}<br>${esc(j.site_address || "")}`).addTo(rLayer);
        if (rLayer && !s.exact) L.circle([s.pt.lat, s.pt.lng], {radius: 120, color: "#e8a530", weight: 1, fillOpacity: .1}).addTo(rLayer);
        bounds.push([s.pt.lat, s.pt.lng]);
      });
      missing.forEach(s => { html += `<li class="stop-row"><p class="font-bold text-[#eaf4ff]">${esc(jobTitle(s.job))}</p><p class="text-[#a9c0d3]">${esc(s.job.site_address || "")}</p><p class="mt-1 text-xs text-[#ffbdc1]">Location not found — ask the customer to drop a map pin, or check the address.</p></li>`; });
      list.innerHTML = html || '<li class="text-sm text-[#9eb7cc]">No upcoming stops.</li>';
      if (geometry && rLayer) {
        rLine = L.geoJSON(geometry, {style: {color: "#42a5f5", weight: 6, opacity: .9}}).addTo(rLayer);
        sum.innerHTML = `<b>Best route:</b> ${ordered.length} stop${ordered.length === 1 ? "" : "s"} · ${fmtKm(totalM)} · about ${fmtMin(totalS)} driving`;
        sum.classList.remove("hidden");
        setRouteStatus("Live tracking is on. The route updates as you move.");
      } else sum.classList.add("hidden");
      if (myPos) bounds.push([myPos.lat, myPos.lng]);
      if (rMap && bounds.length && !drawRoute.fitted) { rMap.fitBounds(bounds, {padding: [40, 40], maxZoom: 16}); drawRoute.fitted = true; }
      if (rMap) setTimeout(() => rMap.invalidateSize(), 50);
    }

    function onPosition(p) {
      myPos = {lat: p.coords.latitude, lng: p.coords.longitude, acc: p.coords.accuracy};
      ensureRouteMap(); if (!rMap) return;
      if (!meMarker) {
        meMarker = L.marker([myPos.lat, myPos.lng], {icon: L.divIcon({className: "", html: '<div class="me-dot"></div>', iconSize: [18, 18], iconAnchor: [9, 9]}), zIndexOffset: 1000}).bindPopup("You are here").addTo(rMap);
        meAcc = L.circle([myPos.lat, myPos.lng], {radius: myPos.acc, color: "#2786e8", weight: 1, fillOpacity: .08}).addTo(rMap);
      } else { meMarker.setLatLng([myPos.lat, myPos.lng]); meAcc.setLatLng([myPos.lat, myPos.lng]).setRadius(myPos.acc); }
      // Re-plan the best route after moving 150 m (at most every 20 s), or on the first fix.
      const moved = !lastRoutePos || hav(lastRoutePos, myPos) > 150;
      if (stopCache.length && moved && Date.now() - lastRouteAt > (lastRoutePos ? 20000 : 0)) { drawRoute.fitted = false; computeRoute(); }
    }
    function startTracking() {
      if (!navigator.geolocation) return setRouteStatus("This browser can't share its location.");
      if (watchId !== null) return;
      setRouteStatus("Waiting for your location… allow location access if asked.");
      watchId = navigator.geolocation.watchPosition(onPosition, err => {
        setRouteStatus(err.code === 1 ? "Location permission was denied. Allow it in your browser settings (this needs HTTPS or localhost)." : "Could not get your location. Move to an open area and try again.");
        stopTracking(true);
      }, {enableHighAccuracy: true, maximumAge: 5000, timeout: 20000});
      $("#track-btn span").textContent = "Stop live tracking";
    }
    function stopTracking(keepStatus) {
      if (watchId !== null) navigator.geolocation.clearWatch(watchId);
      watchId = null; $("#track-btn span").textContent = "Start live tracking";
      if (!keepStatus) setRouteStatus("Live tracking stopped.");
    }

    function renderReports() {
      const list = $("#report-list");
      const jobs = jobsAll();
      list.innerHTML = jobs.length ? jobs.map(job => `<article class="card flex flex-wrap items-center justify-between gap-3 rounded-2xl p-4"><div><p class="font-bold">${esc(jobTitle(job))}</p><p class="mt-1 text-sm text-[#a9c0d3]">${esc(job.customer_name)} · ${esc(job.updated_at ? new Date(job.updated_at).toLocaleDateString() : "No updates yet")}</p></div><span class="rounded-full px-3 py-1 text-xs font-bold ${job.report_submitted ? "status-completed" : "status-paused"}">${job.report_submitted ? "Submitted" : "Draft"}</span></article>`).join("") : '<p class="text-sm text-[#9eb7cc]">Reports will be listed here once you have assigned jobs.</p>';
    }

    /* ---------- messaging & calls ---------- */
    function renderCommunication() {
      const msgs = threadMsgs(), thread = $("#message-thread");
      const atBottom = thread.scrollHeight - thread.scrollTop - thread.clientHeight < 40;
      thread.innerHTML = msgs.length ? msgs.map(m => {
        const fromAdmin = m.role === "admin";
        return `<div class="max-w-[85%] rounded-2xl p-3 ${fromAdmin ? "bg-[#183b5e]" : "ml-auto bg-[#1766aa]"}"><p class="text-xs font-bold">${esc(fromAdmin ? (m.msg_sender || adminName()) : "You")}</p><p class="mt-1 text-sm" style="white-space:pre-wrap">${esc(m.msg_text)}</p><p class="mt-1 text-[11px] opacity-70">${esc(fmtStamp(m.msg_timestamp || m.created_at))}</p></div>`;
      }).join("") : `<p class="text-sm text-[#9eb7cc]">No messages yet. Start the conversation with ${esc(adminName())}.</p>`;
      if (atBottom) thread.scrollTop = thread.scrollHeight;
      const unread = msgs.filter(m => m.role === "admin" && m.status === "Unread").length;
      $("#unread-badge").textContent = unread; $("#unread-badge").classList.toggle("hidden", !unread);
      const calls = backendRecords.filter(r => r.record_type === "call" && r.thread_id === threadId());
      $("#call-history").innerHTML = calls.length ? calls.map(c => `<div class="flex items-center justify-between rounded-xl bg-[#0c2948] p-3 text-sm"><span>${c.msg_type === "video" ? "Video" : "Voice"} call · ${esc(fmtStamp(c.created_at))}</span><span class="text-[#9eb7cc]">${esc(c.call_duration || c.status || "")}</span></div>`).join("") : '<p class="text-sm text-[#9eb7cc]">No calls logged yet.</p>';
      $("#bell-dot").classList.toggle("hidden", !(unread || allMine().some(j => j.status === "Assigned")));
    }
    function markAdminRead() {
      if ($("#communication-view").classList.contains("hidden-view")) return;
      threadMsgs().filter(m => m.role === "admin" && m.status === "Unread" && !markingRead.has(m.__backendId)).forEach(m => {
        markingRead.add(m.__backendId);
        window.dataSdk.update({...m, status:"Read", updated_at: nowIso()}).then(r => { if (!r.isOk) markingRead.delete(m.__backendId); });
      });
    }
    async function startCall(type) {
      if (activeCall) return showFeedback("A call is already being logged. End it first.", "error");
      const r = await window.dataSdk.create({record_type:"call", title:(type === "video" ? "Video" : "Voice") + " call · " + me.name, thread_id:threadId(), msg_type:type, msg_sender:me.name, assigned_technician:me.name, role:"technician", status:"Active", created_at:nowIso()});
      if (!r.isOk) return showFeedback("Could not start the call log.", "error");
      activeCall = {id:r.id, started:Date.now(), type};
      const ap = adminRec();
      $("#active-call-controls").classList.remove("hidden");
      $("#call-status").classList.remove("hidden");
      $("#call-status").textContent = (type === "video" ? "Video" : "Voice") + " call logged" + (ap && ap.phone ? " · dial " + ap.phone : "");
      $("#call-status").className = "rounded-full bg-[#123f3c] px-3 py-1 text-xs font-bold text-[#9df2dc]";
      $("#active-call-label").textContent = "Call with " + adminName() + " (log only — this portal doesn’t carry audio/video)";
      if (type === "voice" && ap && ap.phone) window.location.href = "tel:" + ap.phone.replace(/[^+\d]/g, "");
      window.dataSdk.refresh();
    }
    async function endCall() {
      if (!activeCall) return;
      const secs = Math.round((Date.now() - activeCall.started) / 1000);
      const dur = Math.floor(secs / 60) + "m " + String(secs % 60).padStart(2, "0") + "s";
      const rec = backendRecords.find(r => r.__backendId === activeCall.id);
      if (rec) await window.dataSdk.update({...rec, status:"Ended", call_duration:dur, updated_at:nowIso()});
      activeCall = null;
      $("#active-call-controls").classList.add("hidden");
      $("#call-status").textContent = "Call ended · " + dur;
      $("#call-status").className = "rounded-full bg-[#4d3718] px-3 py-1 text-xs font-bold text-[#ffd681]";
      window.dataSdk.refresh();
    }

    /* ---------- saving ---------- */
    async function updateSelected(changes, control) {
      const job = selectedJob();
      if (!job) return showFeedback("This job is no longer available.", "error");
      if (control) { control.disabled = true; control.classList.add("opacity-60"); }
      try {
        const r = await window.dataSdk.update({...job, ...changes, updated_at: nowIso()});
        if (!r.isOk) showFeedback("Could not confirm this update. Refresh before trying again.", "error");
        else { showFeedback("Job update saved."); await window.dataSdk.refresh(); }
        return r.isOk;
      } finally { if (control) { control.disabled = false; control.classList.remove("opacity-60"); } }
    }
    async function attachFile(file, control) {
      if (!file) return;
      control.classList.add("opacity-60");
      const up = await window.dataSdk.upload(file);
      control.classList.remove("opacity-60");
      if (!up.isOk) return showFeedback("Upload failed: " + (up.error || "unknown error"), "error");
      const job = selectedJob();
      await updateSelected({documents_uploaded: [job.documents_uploaded, up.name + "::" + up.stored].filter(Boolean).join("|")});
    }

    /* ---------- sign-in ---------- */
    function showErr(sel, msg) { const el = $(sel); el.textContent = msg; el.classList.remove("hidden"); }
    function applyUser(u) {
      me = {name: u.tech_name || u.display_name, username: u.username};
      selectedId = null; showView("today"); renderProfile(); initializeDataSdk();
    }
    async function boot() {
      window.dataSdk.onUnauthorized = () => location.replace("index.php");
      const r = await window.auth.me();
      if (r.user && r.user.role === "technician") applyUser(r.user);
      else location.replace("index.php");
    }

    function renderAll() {
      renderProfile();
      if (!me) return;
      renderJobs(); renderRoute(); renderReports(); renderCommunication(); markAdminRead();
      if (selectedId && detailOpen()) {
        const j = selectedJob();
        if (!j) { showView("jobs"); showFeedback("That job is no longer available.", "error"); }
        else if (JSON.stringify(j) !== selectedSnapshot) openDetail(selectedId, false);
      }
    }

    const handler = {
      onDataChanged(data) {
        clearTimeout(initialLoadTimer); backendRecords = data; loaded = true;
        $("#sync-text").textContent = "Synced";
        renderAll();
      }
    };

    async function initializeDataSdk() {
      clearTimeout(initialLoadTimer);
      initialLoadTimer = setTimeout(() => {
        $("#sync-text").textContent = "Offline";
        $("#loading-state").innerHTML = '<p class="font-bold text-[#ffbdc1]">Could not load saved jobs.</p><p class="mt-1 text-sm text-[#9eb7cc]">Check your connection, then try again.</p><button id="retry-load" class="action-blue mt-4 rounded-xl px-4 py-2 font-bold">Try again</button>';
        $("#retry-load").addEventListener("click", initializeDataSdk);
      }, 8000);
      const r = await window.dataSdk.init(handler);
      if (!r.isOk) { clearTimeout(initialLoadTimer); $("#sync-text").textContent = "Offline"; }
    }

    document.addEventListener("DOMContentLoaded", () => {
      lucide.createIcons();
      renderProfile();
      document.querySelectorAll("[data-view]").forEach(b => b.addEventListener("click", () => showView(b.dataset.view)));
      $("#back-to-jobs").addEventListener("click", () => showView("jobs"));
      $("#bell-button").addEventListener("click", () => showView(threadMsgs().some(m => m.role === "admin" && m.status === "Unread") ? "communication" : "jobs"));
      $("#account-btn").addEventListener("click", () => { $("#account-info").textContent = "Signed in as " + me.username + " · " + me.name; $("#account-modal").classList.remove("hidden"); });
      $("#account-close").addEventListener("click", () => $("#account-modal").classList.add("hidden"));
      $("#track-btn").addEventListener("click", () => watchId === null ? startTracking() : stopTracking());
      $("#reroute-btn").addEventListener("click", () => { drawRoute.fitted = false; computeRoute(true); });
      $("#signout-btn").addEventListener("click", async () => { window.dataSdk.stop(); await window.auth.logout(); location.replace("index.php"); });
      $("#pw-form").addEventListener("submit", async ev => {
        ev.preventDefault(); $("#pw-error").classList.add("hidden");
        if ($("#pw-new").value !== $("#pw-new2").value) return showErr("#pw-error", "The new passwords do not match.");
        ev.submitter.disabled = true;
        const r = await window.auth.changePassword($("#pw-current").value, $("#pw-new").value);
        ev.submitter.disabled = false;
        if (!r.isOk) return showErr("#pw-error", r.error || "Could not change the password.");
        ev.target.reset(); $("#account-modal").classList.add("hidden"); showFeedback("Password updated.");
      });

      /* availability */
      $("#availability-button").addEventListener("click", async () => {
        const rec = myRecord(); if (!rec) return;
        const next = rec.status === "Unavailable" ? "Available" : "Unavailable";
        const r = await window.dataSdk.update({...rec, status:next, updated_at:nowIso()});
        if (r.isOk) { showFeedback("Availability set to " + next.toLowerCase() + "."); window.dataSdk.refresh(); } else showFeedback("Could not update availability.", "error");
      });

      /* messaging / calls */
      $("#message-form").addEventListener("submit", async ev => {
        ev.preventDefault();
        const input = $("#message-input"), text = input.value.trim(); if (!text) return;
        const btn = $("#send-message"); btn.disabled = true;
        const r = await window.dataSdk.create({record_type:"message", title:"Technician message", thread_id:threadId(), msg_sender:me.name, msg_text:text, msg_timestamp:nowIso(), msg_type:"message", status:"Unread", role:"technician", assigned_technician:me.name, created_at:nowIso()});
        btn.disabled = false;
        if (r.isOk) { input.value = ""; window.dataSdk.refresh(); } else showFeedback("Could not send the message.", "error");
      });
      $("#start-voice-call").addEventListener("click", () => startCall("voice"));
      $("#start-video-call").addEventListener("click", () => startCall("video"));
      $("#end-call").addEventListener("click", endCall);

      /* job actions */
      $("#start-job").addEventListener("click", e => updateSelected({status:"In progress", workflow_stage: selectedJob().workflow_stage || stages[0]}, e.currentTarget));
      $("#pause-job").addEventListener("click", e => updateSelected({status:"Paused"}, e.currentTarget));
      $("#status-select").addEventListener("change", e => updateSelected({status:e.target.value}, e.target));
      document.querySelectorAll(".workflow-step").forEach(b => b.addEventListener("click", e => updateSelected({workflow_stage:e.currentTarget.dataset.stage}, e.currentTarget)));
      $("#save-job").addEventListener("click", e => updateSelected({status:$("#status-select").value, equipment_used:$("#equipment-input").value.trim(), notes:$("#notes-input").value.trim()}, e.currentTarget));
      $("#report-issue").addEventListener("click", e => {
        const issue = $("#issue-input").value.trim();
        if (!issue) return showFeedback("Add an issue description before reporting.", "error");
        const existing = $("#notes-input").value.trim();
        updateSelected({notes: (existing ? existing + "\n" : "") + "Issue: " + issue}, e.currentTarget);
      });
      $("#upload-photo").addEventListener("click", () => $("#photo-file").click());
      $("#upload-document").addEventListener("click", () => $("#doc-file").click());
      $("#photo-file").addEventListener("change", e => { attachFile(e.target.files[0], $("#upload-photo")); e.target.value = ""; });
      $("#doc-file").addEventListener("change", e => { attachFile(e.target.files[0], $("#upload-document")); e.target.value = ""; });
      $("#capture-signature").addEventListener("click", e => {
        const who = $("#signoff-name").value.trim();
        if (!who) return showFeedback("Enter the name of the person acknowledging the work on site.", "error");
        updateSelected({signature_status: "On-site acknowledgement by " + who + " on " + new Date().toLocaleDateString("en-PH")}, e.currentTarget).then(ok => { if (ok) $("#signoff-name").value = ""; });
      });
      $("#submit-report").addEventListener("click", e => {
        const notes = $("#notes-input").value.trim(), equip = $("#equipment-input").value.trim();
        if (!notes && !equip) return showFeedback("Add technician notes or the equipment used before submitting the report.", "error");
        const btn = e.currentTarget;
        VUI.ask({title:"Submit the completion report?", message:"The job will be marked completed and the customer will be asked to sign off.", confirmLabel:"Submit report", cancelLabel:"Keep editing"}).then(a => {
          if (a.ok) updateSelected({report_submitted:true, workflow_stage:"Completion Report", status:"Completed", equipment_used:equip, notes}, btn);
        });
      });
      boot();
    });
  </script>
 <script src="vtech-ui.js"></script>
 </body>
</html>
